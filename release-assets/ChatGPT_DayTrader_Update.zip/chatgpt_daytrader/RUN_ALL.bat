@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ChatGPT Day Trader - Easy Launch
color 0B
echo.
echo ============================================
echo       CHATGPT DAY TRADER - EASY LAUNCH
echo ============================================
echo.
echo First-time setup may take a few minutes to install packages.
echo Paper trading is the default. No live trading starts by itself.
echo.
set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if defined PYTHON_CMD goto PYTHON_READY
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if defined PYTHON_CMD goto PYTHON_READY
:NOPY
echo Python 3.11+ was not detected.
echo.
where winget >nul 2>nul
if errorlevel 1 goto PYTHON_SITE
choice /C YN /M "Install Python 3.12 automatically with Windows Package Manager"
if errorlevel 2 goto PYTHON_SITE
winget install --id Python.Python.3.12 -e --source winget --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto PYTHON_SITE
echo.
echo Python installed. CLOSE THIS WINDOW, then double-click START_DAYTRADER.bat again.
pause
exit /b 0
:PYTHON_SITE
echo Opening the official Python download page. Install Python 3.11+ and run this again.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1
:PYTHON_READY
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Preparing Python environment...
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 goto FAIL
)
echo [2/3] Checking needed libraries (first run needs internet)...
".venv\Scripts\python.exe" setup_deps.py
if errorlevel 1 goto FAIL
echo [3/3] Opening your trading control panel...
".venv\Scripts\python.exe" launchpad.py
if errorlevel 1 goto FAIL
exit /b 0
:FAIL
echo.
echo Something did not start correctly. The error is shown above.
echo Take a screenshot of THIS WINDOW, hiding any keys, and share it for troubleshooting.
pause
exit /b 1
