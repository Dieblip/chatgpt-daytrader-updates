@echo off
cd /d "%~dp0"
py -3 updater.py --auto
if errorlevel 1 (echo Update check failed; stopping. & pause & exit /b 2)
if not exist .venv\Scripts\python.exe (echo Run START_HERE.bat first. & pause & exit /b 1)
.venv\Scripts\python.exe setup_deps.py
if errorlevel 1 (echo Dependencies could not be installed. & pause & exit /b 1)
echo DRY RUN PAPER MODE: AI decisions but NO broker orders.
.venv\Scripts\python.exe bot.py --dry-run
pause
