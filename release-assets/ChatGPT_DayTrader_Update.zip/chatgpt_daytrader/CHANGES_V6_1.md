# ChatGPT Day Trader v6.1.0 — Paper Trading Transparency Update

## Three improvements

**1. Autonomous PAPER trade verification**
- The paper bot keeps its regular-hours trading logic and hard risk rules; no forced buy/sell orders are added.
- Every 60 seconds it reads Alpaca paper order status, recording new/rejected/canceled/part-filled/filled status transitions without submitting any additional orders.
- Its health indicator distinguishes market closed, entry-window closed, missing market data, AI errors, risk blockers, and stale/stopped processes.
- Entries submitted to Alpaca now explicitly say `SUBMITTED_NOT_FILLED`. A submitted order is never treated as a successful fill.

**2. Explainable AI decision journal**
- Every completed AI signal records BUY/SELL/HOLD, its one-sentence numeric rationale, the indicators available for that symbol, whether a hard-coded rule allowed it, and why an order was rejected.
- In the Streamlit dashboard, see **AI decision log** and export results to CSV.
- Decision logs are in `decisions_paper.jsonl`, stored locally and not bundled into GitHub releases.

**3. Profit / loss / win-rate dashboard**
- The dashboard now displays estimates from completed, recognized Alpaca paper orders, including bracket exits and bot-logged emergency closes.
- Shows completed round trips, win rate excluding flat trades, wins/losses, estimated realized P&L, and a cumulative P&L chart.
- Shows broker order statuses and average fill prices separately from AI instructions.
- Also computes 24/7 local-practice win rate from *simulated* closes, labeled separately from Alpaca paper trading.

## Important limits
- This strategy is **not** proven profitable. A valid HOLD may result in no trades for days.
- Regular Alpaca stock paper trades require the applicable stock-trading session. The 24/7 practice simulator remains separate and does **not** send Alpaca orders.
- Performance figures are *estimates*, not statements or tax records. The broker query includes a rolling 60-day lookback and up to 500 recent orders; earlier history, fees, dividends, partial fills, and manual interventions can make figures incomplete.
- The update does **not** automatically enable live mode, change trading risk limits, or change account API keys.
- During an emergency stop, verify orders and positions directly at Alpaca; an API request does not guarantee liquidation.

## Publish and test the updater
1. Stop all active bot and practice sessions and check Alpaca positions.
2. Create a new **published** GitHub Release at `https://github.com/Dieblip/chatgpt-daytrader-updates/releases/new`.
3. Use tag **v6.1.0** (not the release title). Attach the standalone update asset named **ChatGPT_DayTrader_Update.zip**. Do not attach the full Windows installer ZIP.
4. Publish the release. In your installed bot's GitHub Updates tab, click **Check for Update** and **Install**. It should update to v6.1.0, restart, and retain your `.env` and account history.
5. Click **Instant Practice**, then view dashboard Practice; later use **Paper → Run All** during market hours and review **AI decision log**, **Performance & win rate**, and **Broker orders / fills**.

This release has local automated tests, but actual Alpaca connectivity and live-money execution were not tested in the user's environment.
