@echo off
cd /d "%~dp0"
type nul > STOP.txt
echo EMERGENCY STOP REQUESTED for the running bot (LIVE or PAPER).
echo No new entries. The running bot checks every 15s and tries to cancel
 echo its working orders and flatten its managed positions.
echo This is NOT guaranteed. Independently check your Alpaca broker account.
echo If the bot is OFFLINE, it cannot perform exits.
pause
