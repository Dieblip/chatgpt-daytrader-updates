"""Beginner-friendly local Windows launcher. Only starts PAPER and DRY-RUN modes.

The separate RUN_LIVE.bat + .env acknowledgement remain necessary for live orders.
"""
from __future__ import annotations

import os
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from webbrowser import open as open_url

from dotenv import dotenv_values
from easy_setup_utils import config_is_ready, paper_inputs_valid, save_paper_keys
from updater import UpdateError, available_update, current_version, read_config, save_config

ROOT = Path(__file__).resolve().parent
ALPACA_URL = 'https://app.alpaca.markets/'
OPENAI_KEY_URL = 'https://platform.openai.com/api-keys'
OPENAI_BILLING_URL = 'https://platform.openai.com/settings/organization/billing/overview'
DASHBOARD_URL = 'http://127.0.0.1:8501'


class ControlCenter(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f'ChatGPT Day Trader v{current_version()} — Easy Setup (PAPER MODE)')
        self.geometry('790x800')
        self.minsize(680, 700)
        self.configure(bg='#f3f6fa')
        self._busy = False
        self._controls: list[ttk.Button] = []
        self.style = ttk.Style()
        if 'clam' in self.style.theme_names():
            self.style.theme_use('clam')
        self.style.configure('Title.TLabel', font=('Segoe UI', 20, 'bold'))
        self.style.configure('Step.TLabelframe.Label', font=('Segoe UI', 12, 'bold'))
        self.style.configure('Info.TLabel', font=('Segoe UI', 10))
        self.style.configure('Main.TButton', font=('Segoe UI', 10, 'bold'), padding=(9, 7))
        self.style.configure('Small.TButton', font=('Segoe UI', 9), padding=(7, 4))

        config = dotenv_values(ROOT / '.env') if (ROOT / '.env').exists() else {}
        self.paper_key = tk.StringVar(value=config.get('ALPACA_PAPER_KEY') or '')
        self.paper_secret = tk.StringVar(value=config.get('ALPACA_PAPER_SECRET') or '')
        self.openai_key = tk.StringVar(value=config.get('OPENAI_API_KEY') or '')
        self.max_order = tk.StringVar(value=config.get('MAX_ORDER_DOLLARS') or '1500')
        self.status = tk.StringVar(value='Step 1: Add your API keys. Start in simulated PAPER mode.')
        self.show_secrets = tk.BooleanVar(value=False)
        update_settings = read_config(ROOT)
        self.github_repo = tk.StringVar(value=update_settings['repo'])
        self.auto_updates = tk.BooleanVar(value=update_settings['auto_install'])
        self.update_status = tk.StringVar(value=f'Installed version: v{current_version()}. No trading changes without a published release.')
        self._build()

    def _build(self):
        # The wizard is scrollable on laptop screens; do not clip Start/Stop buttons.
        outer = ttk.Frame(self)
        outer.pack(fill='both', expand=True)
        canvas = tk.Canvas(outer, background='#f3f6fa', highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        canvas.configure(yscrollcommand=scrollbar.set)
        container = ttk.Frame(canvas, padding=18)
        window_id = canvas.create_window((0, 0), window=container, anchor='nw')
        container.bind('<Configure>', lambda _e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window_id, width=e.width))
        self.bind_all('<MouseWheel>', lambda e: canvas.yview_scroll(int(-e.delta / 120), 'units'))
        ttk.Label(container, text='ChatGPT Day Trader', style='Title.TLabel').pack(anchor='w')
        ttk.Label(container, text='SIMPLE CONTROL CENTER  |  Paper = fake money  |  Scroll down for Start buttons',
                  foreground='#166534', font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 12))

        credentials = ttk.LabelFrame(container, text='1  Paste your API keys', padding=12, style='Step.TLabelframe')
        credentials.pack(fill='x', pady=(0, 10))
        self._link(credentials, 'Open Alpaca — choose PAPER Trading and create API keys', ALPACA_URL)
        self._entry(credentials, 'Alpaca PAPER API Key ID', self.paper_key, secret=True)
        self._entry(credentials, 'Alpaca PAPER Secret Key', self.paper_secret, secret=True)
        self._link(credentials, 'Open OpenAI — create an API key', OPENAI_KEY_URL)
        self._entry(credentials, 'OpenAI API Key', self.openai_key, secret=True)
        self._link(credentials, 'OpenAI API billing (separate from ChatGPT subscription)', OPENAI_BILLING_URL)
        ttk.Checkbutton(credentials, text='Show keys on screen', variable=self.show_secrets,
                        command=self._toggle_secrets).pack(anchor='w', pady=(3, 0))

        settings = ttk.LabelFrame(container, text='2  Save settings', padding=12, style='Step.TLabelframe')
        settings.pack(fill='x', pady=(0, 10))
        row = ttk.Frame(settings)
        row.pack(fill='x')
        ttk.Label(row, text='Maximum dollars per order (paper):').pack(side='left')
        ttk.Entry(row, textvariable=self.max_order, width=10).pack(side='left', padx=8)
        ttk.Label(settings, text='Default: $1,500. The bot has additional limits; this is NOT a guarantee against losses.',
                  wraplength=690, foreground='#525b6b').pack(anchor='w', pady=(3, 7))
        controls = ttk.Frame(settings)
        controls.pack(fill='x')
        self._button(controls, 'Save Keys', self._save, left=True)
        self._button(controls, 'Check Connections (read-only)', self._check, left=True)
        ttk.Label(settings, text='Keys are stored locally in a hidden .env file. Never send that file to anyone.',
                  foreground='#525b6b', wraplength=690).pack(anchor='w', pady=(8, 0))

        run = ttk.LabelFrame(container, text='3  Run the bot (paper only)', padding=12, style='Step.TLabelframe')
        run.pack(fill='x', pady=(0, 10))
        controls = ttk.Frame(run)
        controls.pack(fill='x')
        self._button(controls, 'Test — NO orders', lambda: self._launch('DRY_RUN.bat'), left=True)
        self._button(controls, 'Start Auto PAPER Bot', lambda: self._launch('RUN_BOT.bat'), left=True)
        self._button(controls, 'Open Dashboard', lambda: self._launch('DASHBOARD.bat', require_config=False), left=True)
        ttk.Label(run, text='Trading is automatic only while the bot window and your PC remain running. '
                              'During a market closure, it may show little activity.',
                  foreground='#525b6b', wraplength=690).pack(anchor='w', pady=(10, 0))
        ttk.Label(run, text='Close a test before starting the paper bot: click its black window and press Ctrl+C.',
                  foreground='#525b6b', wraplength=690).pack(anchor='w', pady=(5, 0))

        updates = ttk.LabelFrame(container, text='4  GitHub auto-updates (optional)', padding=12,
                                 style='Step.TLabelframe')
        updates.pack(fill='x', pady=(0, 10))
        ttk.Label(updates, text='GitHub repository (public):  OWNER/REPO',
                  font=('Segoe UI', 10)).pack(anchor='w')
        ttk.Entry(updates, textvariable=self.github_repo, width=62).pack(fill='x', pady=(4, 6))
        ttk.Checkbutton(updates, text='Automatically install published updates before starting PAPER mode',
                        variable=self.auto_updates).pack(anchor='w', pady=(1, 5))
        controls = ttk.Frame(updates)
        controls.pack(fill='x')
        self._button(controls, 'Save GitHub Settings', self._save_updates, left=True)
        self._button(controls, 'Check for Update', self._check_update, left=True)
        self._button(controls, 'Install Update', self._install_update, left=True)
        ttk.Label(updates, textvariable=self.update_status, wraplength=685,
                  foreground='#35465c').pack(anchor='w', pady=(5, 0))
        ttk.Label(updates, text='Uses verified ZIP assets from a GitHub Release. The bot must be stopped. '
                           'Your saved keys and trading history are preserved. LIVE starts never auto-update.',
                  wraplength=685, foreground='#525b6b').pack(anchor='w', pady=(5, 0))

        safety = ttk.LabelFrame(container, text='5  Emergency controls / help', padding=12, style='Step.TLabelframe')
        safety.pack(fill='x', pady=(0, 10))
        controls = ttk.Frame(safety)
        controls.pack(fill='x')
        self._button(controls, 'Emergency Stop Request', self._stop, left=True)
        self._button(controls, 'Read Instructions', lambda: self._open_local('READ_ME_FIRST.html'), left=True)
        ttk.Label(safety, text='STOP asks the running bot to stop entries and try to exit. It does NOT guarantee '
                               'orders or positions are closed. Verify directly in Alpaca.',
                  foreground='#991b1b', wraplength=690).pack(anchor='w', pady=(8, 0))

        status = ttk.LabelFrame(container, text='Status', padding=10)
        status.pack(fill='x')
        ttk.Label(status, textvariable=self.status, wraplength=685).pack(anchor='w')
        ttk.Label(container, text='Live trading cannot be started from this control center. '
                                  'It requires separate, explicit advanced setup and has real-loss risk.',
                  foreground='#991b1b', wraplength=710).pack(anchor='w', pady=(9, 0))

    def _entry(self, parent, title, var, secret):
        ttk.Label(parent, text=title).pack(anchor='w', pady=(5, 2))
        entry = ttk.Entry(parent, textvariable=var, show='•' if secret else '', width=75)
        entry.pack(fill='x')
        if secret:
            if not hasattr(self, '_secret_entries'):
                self._secret_entries = []
            self._secret_entries.append(entry)

    def _link(self, parent, text, url):
        label = ttk.Label(parent, text=text + '  ↗', foreground='#1261bb',
                          cursor='hand2', font=('Segoe UI', 9, 'underline'))
        label.pack(anchor='w', pady=(3, 2))
        label.bind('<Button-1>', lambda _event: open_url(url))

    def _toggle_secrets(self):
        for entry in self._secret_entries:
            entry.configure(show='' if self.show_secrets.get() else '•')

    def _button(self, parent, title, callback, *, left=False):
        button = ttk.Button(parent, text=title, command=callback, style='Main.TButton')
        button.pack(side='left' if left else 'top', padx=(0, 7), pady=3)
        self._controls.append(button)
        return button

    def _data(self):
        return (self.paper_key.get(), self.paper_secret.get(),
                self.openai_key.get(), self.max_order.get())

    def _save(self, *, show_message=True):
        try:
            save_paper_keys(ROOT, *self._data())
        except (ValueError, OSError, RuntimeError) as exc:
            messagebox.showerror('Check your settings', str(exc))
            self.status.set('Settings not saved. Fix the message above and retry.')
            return False
        self.status.set('Saved. The paper-only bot can now read your API keys.')
        if show_message:
            messagebox.showinfo('Saved', 'Your PAPER keys were saved locally.\n\n'
                                   'Next: click Check Connections, then Test — NO orders.')
        return True

    def _check(self):
        if not self._save(show_message=False):
            return
        if self._busy:
            return
        self._busy = True
        for button in self._controls:
            button.state(['disabled'])
        self.status.set('Checking PAPER broker and OpenAI credentials (read-only; no trades)...')
        values = self._data()
        thread = threading.Thread(target=self._check_worker, args=(values,), daemon=True)
        thread.start()

    def _check_worker(self, values):
        result = []
        try:
            from alpaca.trading.client import TradingClient
            acct = TradingClient(values[0].strip(), values[1].strip(), paper=True).get_account()
            result.append(f'Alpaca PAPER connection succeeded (equity ${float(acct.equity):,.2f}).')
        except Exception as exc:
            result.append('Alpaca PAPER connection failed. Check your PAPER keys and internet. '
                          f'Error type: {type(exc).__name__}.')
        try:
            from openai import OpenAI
            client = OpenAI(api_key=values[2].strip(), timeout=18.0, max_retries=0)
            client.models.list()  # read-only; checks auth, not entitlement to any particular model
            result.append('OpenAI API connection succeeded. Model access still needs a trading-day dry run.')
        except Exception as exc:
            result.append('OpenAI API connection failed. Check API key, billing and internet. '
                          f'Error type: {type(exc).__name__}.')
        self.after(0, lambda: self._check_finished(result))

    def _check_finished(self, results):
        self._busy = False
        for button in self._controls:
            button.state(['!disabled'])
        self.status.set(' | '.join(results))
        messagebox.showinfo('Connection check (no orders)', '\n\n'.join(results))

    def _launch(self, filename, require_config=True):
        if require_config:
            # Persist any changes in the visible form before starting the next process.
            if not self._save(show_message=False):
                return
        elif not config_is_ready(ROOT):
            messagebox.showwarning('Keys needed', 'Save your keys before opening the dashboard.')
            return
        if (ROOT / 'STOP.txt').exists() and filename != 'DASHBOARD.bat':
            messagebox.showwarning('Emergency stop still active',
                'STOP.txt exists. Do NOT simply erase it if there are active orders/positions. '
                'Check the account on Alpaca, then follow the guide for restarting safely.')
            return
        if (ROOT / '.bot.lock').exists() and filename != 'DASHBOARD.bat':
            messagebox.showwarning('Bot may already be running',
                'A bot process is already running, or a previous run left a lock file. '
                'Stop the old bot before launching another. See READ_ME_FIRST.html.')
            return
        if filename == 'RUN_BOT.bat':
            if not messagebox.askokcancel('Start simulated trading?',
                    'This starts fully automatic PAPER trading with fake money.\n\n'
                    'It does NOT use your real Alpaca account.\n\n'
                    'Continue?'):
                return
        try:
            if os.name != 'nt':
                raise OSError('This control center launches .bat files on Windows only.')
            os.startfile(str(ROOT / filename))  # type: ignore[attr-defined]
        except OSError as exc:
            messagebox.showerror('Could not start', str(exc))
            return
        labels = {'RUN_BOT.bat': 'Paper bot', 'DRY_RUN.bat': 'No-trade test',
                  'DASHBOARD.bat': 'Dashboard'}
        self.status.set(f'{labels.get(filename, filename)} launched in a new window. '
                        'Keep that window open. Check messages there for errors.')

    def _save_updates(self, *, show_message=True):
        try:
            save_config(ROOT, self.github_repo.get(), self.auto_updates.get())
        except (UpdateError, OSError) as exc:
            messagebox.showerror('Invalid GitHub settings', str(exc))
            return False
        self.update_status.set('Saved. Future PAPER launches will check GitHub releases if enabled.')
        if show_message:
            messagebox.showinfo('Update settings saved',
                'The repository settings were saved locally.\n\n'
                'You must publish versioned GitHub Releases with the matching update ZIP.\n'
                'Read PUBLISH_TO_GITHUB.md for the instructions.')
        return True

    def _check_update(self):
        if not self._save_updates(show_message=False):
            return
        repo = self.github_repo.get().strip()
        if not repo:
            messagebox.showinfo('Repository needed',
                'First enter the GitHub repository you will use (OWNER/REPO).\n\n'
                'Read PUBLISH_TO_GITHUB.md to set one up.')
            return
        if self._busy:
            return
        self._busy = True
        for button in self._controls:
            button.state(['disabled'])
        self.update_status.set('Checking latest published GitHub Release (no update installed yet)...')
        threading.Thread(target=self._check_update_worker, args=(repo,), daemon=True).start()

    def _check_update_worker(self, repo):
        try:
            release = available_update(ROOT, repo)
            result = (f'Update available: {release.version}. Click Install Update.' if release
                      else f'You have the latest release for {repo} (installed v{current_version()}).')
        except (UpdateError, OSError) as exc:
            result = f'Could not check GitHub: {exc}'
        self.after(0, lambda: self._check_update_finished(result))

    def _check_update_finished(self, result):
        self._busy = False
        for button in self._controls:
            button.state(['!disabled'])
        self.update_status.set(result)
        messagebox.showinfo('GitHub updater', result)

    def _install_update(self):
        if not self._save_updates(show_message=False):
            return
        if not self.github_repo.get().strip():
            messagebox.showwarning('GitHub repository missing',
                                   'Enter OWNER/REPO and save it before updating.')
            return
        if (ROOT / '.bot.lock').exists():
            messagebox.showwarning('Stop trading first',
                'A bot lock is present. Close all trading windows and check Alpaca '
                'before updating. Do not delete a live lock without investigating.')
            return
        if not messagebox.askokcancel('Install from GitHub?',
                'Close any trading bot or dashboard window before installing.\n\n'
                'Only releases from the GitHub repository you configured will be used. '
                'The ZIP hash must match GitHub. Your .env keys and history are kept.\n\n'
                'The control window will now close, and an updater window will open.'):
            return
        try:
            if os.name != 'nt':
                raise OSError('Updater launcher requires Windows.')
            os.startfile(str(ROOT / 'UPDATE_NOW.bat'))  # type: ignore[attr-defined]
            self.destroy()
        except OSError as exc:
            messagebox.showerror('Could not start updater', str(exc))

    def _open_local(self, filename):
        path = ROOT / filename
        if not path.exists():
            messagebox.showwarning('Guide missing', f'Could not find {filename}.')
            return
        open_url(path.as_uri())

    def _stop(self):
        if not messagebox.askokcancel('Emergency stop',
                'Request an emergency stop for whichever bot is running (PAPER or LIVE)?\n\n'
                'This creates STOP.txt. The bot can act only if it is still running and connected.\n\n'
                'You MUST inspect orders and positions directly in Alpaca. Continue?'):
            return
        (ROOT / 'STOP.txt').write_text('EMERGENCY STOP REQUESTED\n', encoding='utf-8')
        self.status.set('STOP requested. Check your account in Alpaca immediately.')
        messagebox.showwarning('Emergency stop requested',
                'A STOP request was created.\n\n'
                'This is NOT proof that orders or positions are closed. '
                'Open Alpaca and verify them manually, especially if the bot is offline.')


if __name__ == '__main__':
    ControlCenter().mainloop()
