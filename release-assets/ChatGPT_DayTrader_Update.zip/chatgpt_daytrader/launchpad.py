"""V6 beginner-first control panel, reusing the proven v5 trading/practice safety engine.

Every action is local. GitHub Releases can be checked without GitHub sign-in.
Github publishing is optional and uses the official GitHub CLI web login.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from unified_control import (ControlCenter, ALPACA, OPENAI, BILLING, BG, PANEL,
                             TEXT, MUTED, GREEN, ROOT)
from updater import (UpdateError, available_update, current_version,
                     read_config, save_config, fetch_latest, parse_version)
from quick_connect import DEFAULT_REPO, configured, import_old_keys

GITHUB_CLI = 'https://cli.github.com/'


class ConnectionWizard(tk.Toplevel):
    """One screen where a first-time user can get, paste, and save required keys."""
    def __init__(self, parent: 'DayTraderApp'):
        super().__init__(parent)
        self.parent = parent
        self.title('Easy Setup — Connect Your Trading Bot')
        self.geometry('700x675')
        self.minsize(600, 550)
        self.configure(bg=BG)
        self.transient(parent)
        self.keys = {k: tk.StringVar(value=parent.values[k].get()) for k in
                     ('ALPACA_PAPER_KEY', 'ALPACA_PAPER_SECRET', 'OPENAI_API_KEY')}
        outer = ttk.Frame(self, padding=24)
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='Connect your accounts', font=('Segoe UI', 22, 'bold')).pack(anchor='w', pady=(0, 6))
        ttk.Label(outer, text='Three keys, one Save button. Start with fake-money PAPER trading.',
                  style='Muted.TLabel', wraplength=590).pack(anchor='w', pady=(0, 17))
        self._section(outer, 'STEP 1 — Alpaca Paper Account',
                      'Open Alpaca, switch to Paper Trading, then find API Keys.',
                      'Open Alpaca →', ALPACA)
        self._input(outer, 'Paper Key ID', 'ALPACA_PAPER_KEY')
        self._input(outer, 'Paper Secret Key', 'ALPACA_PAPER_SECRET')
        self._section(outer, 'STEP 2 — OpenAI API',
                      'Create a secret API key. The API may require separate paid credits.',
                      'Get OpenAI Key →', OPENAI)
        self._input(outer, 'OpenAI API Key', 'OPENAI_API_KEY')
        ttk.Button(outer, text='Already used an older bot? Import its keys...',
                   command=self._import_old).pack(anchor='w', pady=(20, 10))
        bottom = ttk.Frame(outer)
        bottom.pack(fill='x', pady=(10, 0))
        ttk.Button(bottom, text='SAVE KEYS & TEST CONNECTIONS', style='Run.TButton',
                   command=self._save_test).pack(side='left')
        ttk.Button(bottom, text='Save Keys Only', command=self._save).pack(side='left', padx=10)
        ttk.Button(bottom, text='Skip — Try Demo', command=self.destroy).pack(side='right')
        ttk.Label(outer, text='Keys are saved locally in .env, not uploaded to GitHub. Never share them in screenshots.',
                  style='Muted.TLabel', wraplength=610).pack(anchor='w', pady=(19, 0))
        self.bind('<Escape>', lambda _e: self.destroy())

    def _section(self, root, title, info, action, url):
        row = ttk.Frame(root)
        row.pack(fill='x', pady=(12, 4))
        ttk.Label(row, text=title, font=('Segoe UI', 12, 'bold')).pack(side='left')
        ttk.Button(row, text=action, command=lambda: webbrowser.open(url)).pack(side='right')
        ttk.Label(root, text=info, style='Muted.TLabel', wraplength=575).pack(anchor='w')

    def _input(self, root, label, key):
        ttk.Label(root, text=label).pack(anchor='w', pady=(8, 3))
        field = ttk.Entry(root, textvariable=self.keys[key], show='•', width=70)
        field.pack(fill='x')

    def _import_old(self):
        folder = filedialog.askdirectory(title='Choose your OLD chatgpt_daytrader folder', parent=self)
        if not folder:
            return
        try:
            imported = import_old_keys(Path(folder))
        except ValueError as exc:
            messagebox.showerror('No saved keys found', str(exc), parent=self)
            return
        count = 0
        for k, val in imported.items():
            if k in self.keys:
                self.keys[k].set(val)
                count += 1
            if k in self.parent.values:
                self.parent.values[k].set(val)
        messagebox.showinfo('Keys found', f'Imported {count} paper/OpenAI fields. Click Save Keys to keep them.', parent=self)

    def _save(self):
        for k, v in self.keys.items():
            self.parent.values[k].set(v.get())
        if self.parent._save_keys(quiet=True):
            self.parent._update_setup_status()
            messagebox.showinfo('Keys saved', 'Saved on this PC! You can now check connections or test sample trades.', parent=self)
            self.destroy()
            return True
        return False

    def _save_test(self):
        if not configured({k: v.get() for k, v in self.keys.items()}):
            messagebox.showwarning('Three keys needed', 'Paste both Alpaca PAPER keys and your OpenAI API key first.', parent=self)
            return
        if self._save():
            self.parent.mode.set('paper')
            self.parent._mode_changed()
            self.parent._check_connections()


class DayTraderApp(ControlCenter):
    def __init__(self):
        # Public updater: no GitHub login, repo URL, access token, or manual JSON editing.
        prior = read_config(ROOT)
        if not prior['repo']:
            save_config(ROOT, DEFAULT_REPO, prior['auto_install'])
        self._onboarding_seen = False
        super().__init__()
        self.title(f'ChatGPT Day Trader v{current_version()} — Easy Control Center')
        self.geometry('1010x800')
        self.after(950, self._welcome)
        self.after(1800, self._quiet_update_check)

    def _home(self):
        self._heading(self.home_content, 'Ready in three easy steps',
                      'Connect your accounts, run the instant practice test, then start automatic paper trading.')
        setup = self._panel(self.home_content, 19)
        ttk.Label(setup, text='1  CONNECT ACCOUNTS', style='Panel.TLabel',
                  font=('Segoe UI', 13, 'bold')).pack(anchor='w')
        self.setup_status = tk.StringVar(value='Checking saved account keys...')
        ttk.Label(setup, textvariable=self.setup_status, style='PanelMuted.TLabel',
                  wraplength=820).pack(anchor='w', pady=(5, 8))
        setup_buttons = ttk.Frame(setup, style='Panel.TFrame')
        setup_buttons.pack(fill='x', pady=(2, 4))
        ttk.Button(setup_buttons, text='CONNECT ACCOUNTS', style='Run.TButton',
                   command=self._connect_wizard).pack(side='left', padx=(0, 9))
        ttk.Button(setup_buttons, text='▶  RUN ALL', style='Run.TButton',
                   command=lambda: self._start(dry_run=False)).pack(side='left', padx=(0, 9))
        ttk.Button(setup_buttons, text='INSTANT PRACTICE',
                   command=lambda: self._start_practice('demo')).pack(side='left')
        ttk.Label(setup, text='2  TEST anytime: use INSTANT SAMPLE TRADES (no keys needed).',
                  style='PanelMuted.TLabel').pack(anchor='w', pady=(10, 4))
        ttk.Label(setup, text='3  TRADE: choose Paper, then RUN ALL. AI may legitimately choose HOLD.',
                  style='PanelMuted.TLabel').pack(anchor='w')
        monitor = self._panel(self.home_content, 16)
        ttk.Label(monitor, text='PAPER BOT HEALTH & PERFORMANCE', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        self.paper_health_line = tk.StringVar(value='No paper bot heartbeat yet. Start Paper / Run All to monitor it.')
        ttk.Label(monitor, textvariable=self.paper_health_line, style='PanelMuted.TLabel',
                  wraplength=830).pack(anchor='w', pady=(5, 9))
        actions = ttk.Frame(monitor, style='Panel.TFrame')
        actions.pack(fill='x')
        ttk.Button(actions, text='VIEW PERFORMANCE + WIN RATE',
                   command=lambda: self._open_dashboard('paper')).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='AI DECISIONS + BROKER FILLS',
                   command=lambda: self._open_dashboard('paper')).pack(side='left')
        ttk.Label(monitor, text='Paper fills only; check Alpaca directly for account truth. No forced trades.',
                  style='PanelMuted.TLabel').pack(anchor='w', pady=(9, 0))
        upd = self._panel(self.home_content, 16)
        ttk.Label(upd, text='AUTOMATIC GITHUB UPDATES', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        ttk.Label(upd, text=f'Preconnected to {DEFAULT_REPO} — no GitHub key or sign-in needed.',
                  style='PanelMuted.TLabel').pack(anchor='w', pady=(5, 4))
        ttk.Label(upd, textvariable=self.update_status, style='PanelMuted.TLabel', wraplength=840).pack(anchor='w')
        buttons = ttk.Frame(upd, style='Panel.TFrame')
        buttons.pack(fill='x', pady=(10, 0))
        ttk.Button(buttons, text='CHECK FOR UPDATE', command=self._check_updates).pack(side='left', padx=(0, 8))
        ttk.Button(buttons, text='INSTALL NEW UPDATE', command=self._install_update).pack(side='left', padx=(0, 8))
        ttk.Button(buttons, text='Update Settings', command=lambda: self.tabs.select(self.updates_tab)).pack(side='left')
        super()._home()

    def _keys(self):
        super()._keys()
        ttk.Button(self.keys_content, text='Open Guided Account Setup',
                   command=self._connect_wizard).pack(anchor='w', pady=(15, 0))

    def _updates(self):
        self._heading(self.updates_content, 'Updates — already connected',
                      'No GitHub account or GitHub API token is required to download published updates.')
        top = self._panel(self.updates_content)
        ttk.Label(top, text=f'GITHUB SOURCE: {DEFAULT_REPO}', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        ttk.Label(top, text='Your settings, trading history, and .env are kept when installing an update.',
                  style='PanelMuted.TLabel').pack(anchor='w', pady=(8, 5))
        ttk.Label(top, textvariable=self.update_status, style='PanelMuted.TLabel',
                  wraplength=800).pack(anchor='w', pady=(0, 8))
        row = ttk.Frame(top, style='Panel.TFrame')
        row.pack(fill='x', pady=(9, 9))
        ttk.Button(row, text='CHECK NOW', command=self._check_updates).pack(side='left', padx=(0, 9))
        ttk.Button(row, text='INSTALL AVAILABLE UPDATE', style='Run.TButton',
                   command=self._install_update).pack(side='left', padx=(0, 9))
        ttk.Button(row, text='View GitHub Releases',
                   command=lambda: webbrowser.open('https://github.com/' + self.repo.get() + '/releases')).pack(side='left')
        ttk.Checkbutton(top, text='Automatically install verified updates before PAPER trading (never during LIVE)',
                        variable=self.auto_updates, command=lambda: self._save_github(quiet=True)).pack(anchor='w', pady=(5, 5))
        ttk.Label(top, text='Updating stops the GUI, verifies the ZIP SHA-256 hash and restarts the app. Stop trading and verify brokerage positions first.',
                  style='PanelMuted.TLabel', wraplength=850).pack(anchor='w', pady=(8, 0))
        advanced = self._panel(self.updates_content)
        ttk.Label(advanced, text='OPTIONAL: CHANGE REPOSITORY', style='Panel.TLabel',
                  font=('Segoe UI', 11, 'bold')).pack(anchor='w')
        row2 = ttk.Frame(advanced, style='Panel.TFrame')
        row2.pack(fill='x', pady=8)
        ttk.Entry(row2, textvariable=self.repo, width=54).pack(side='left', fill='x', expand=True, padx=(0, 7))
        ttk.Button(row2, text='Save', command=self._save_github).pack(side='left', padx=(0, 7))
        ttk.Button(row2, text='Use My Default', command=self._reset_repo).pack(side='left')
        pub = self._panel(self.updates_content)
        ttk.Label(pub, text='OPTIONAL: PUBLISH AN UPDATE TO GITHUB', style='Panel.TLabel',
                  font=('Segoe UI', 11, 'bold')).pack(anchor='w')
        ttk.Label(pub, text='Only needed when you are releasing a NEW bot version. Uses GitHub CLI browser sign-in; your Alpaca/OpenAI keys are never published.',
                  style='PanelMuted.TLabel', wraplength=840).pack(anchor='w', pady=(5, 8))
        buttons = ttk.Frame(pub, style='Panel.TFrame')
        buttons.pack(fill='x')
        ttk.Button(buttons, text='1. Install GitHub CLI', command=lambda: webbrowser.open(GITHUB_CLI)).pack(side='left', padx=(0, 7))
        ttk.Button(buttons, text='2. Sign In To Publish', command=self._publisher_login).pack(side='left', padx=(0, 7))
        ttk.Button(buttons, text='3. Choose ZIP & Publish', command=self._publish_zip).pack(side='left', padx=(0, 7))
        ttk.Button(buttons, text='Publish THIS Installed Version', command=self._publish_installed).pack(side='left')
        ttk.Label(pub, text='You do NOT need these publisher steps to receive updates. Never publish an unreviewed bot build.',
                  style='PanelMuted.TLabel', wraplength=820).pack(anchor='w', pady=(9, 0))

    def _refresh(self):
        super()._refresh()
        if not hasattr(self, 'paper_health_line'):
            return
        path = ROOT / 'health_paper.json'
        if not path.is_file():
            self.paper_health_line.set('No paper bot heartbeat yet. Run Paper mode to begin logging; historical practice is separate.')
            return
        try:
            import json
            from datetime import datetime, timezone
            status = json.loads(path.read_text(encoding='utf-8'))
            timestamp = datetime.fromisoformat(status['time'])
            age = (datetime.now(timezone.utc) - timestamp.astimezone(timezone.utc)).total_seconds()
            label = ('STALE (bot may be stopped)' if age > 120 else status.get('status', 'UNKNOWN'))
            info = str(status.get('description', ''))
            self.paper_health_line.set(f'{label} | {info} | Updated {max(0, int(age))}s ago')
        except (OSError, ValueError, KeyError, TypeError):
            self.paper_health_line.set('Could not read paper bot health file. Check Activity & Help for errors.')

    def _reset_repo(self):
        self.repo.set(DEFAULT_REPO)
        self._save_github(quiet=True)
        self._check_updates()

    def _connect_wizard(self):
        if getattr(self, '_wizard', None) and self._wizard.winfo_exists():
            self._wizard.lift()
            return
        self._wizard = ConnectionWizard(self)

    def _update_setup_status(self):
        if configured(self._form_values(), 'paper'):
            self.setup_status.set('Paper account + OpenAI keys saved. Click Check API Connections to verify access (no orders).')
        else:
            self.setup_status.set('Missing one or more paper/OpenAI keys. Click Connect Accounts to enter them.')

    def _welcome(self):
        self._update_setup_status()
        if not configured(self._form_values(), 'paper'):
            self._connect_wizard()

    def _quiet_update_check(self):
        if self._busy:
            self.after(2000, self._quiet_update_check)
            return
        self.update_status.set('Checking GitHub for updates in the background...')
        threading.Thread(target=self._quiet_update_worker, daemon=True).start()

    def _quiet_update_worker(self):
        try:
            found = available_update(ROOT, self.repo.get())
            msg = (f'New version {found.version} is available. Click INSTALL NEW UPDATE.' if found
                   else f'Up to date — v{current_version()}.')
        except UpdateError as exc:
            if 'No published update releases' in str(exc):
                msg = 'GitHub connected; no update releases have been published yet.'
            else:
                msg = f'Update check unavailable: {exc}. You can still use installed version.'
        try:
            self.after(0, lambda: self.update_status.set(msg))
        except RuntimeError:
            pass

    def _update_worker(self, repo):
        try:
            release = available_update(ROOT, repo)
            result = f'New version {release.version} available. Click Install Update.' if release else f'Up to date — v{current_version()}.'
        except (UpdateError, OSError) as exc:
            result = ('GitHub connected, but no update has been published yet.' if
                      'No published update releases' in str(exc) else f'Update check could not finish: {exc}')
        try:
            self.after(0, lambda: self._update_done(result))
        except RuntimeError:
            pass

    def _install_update(self, automatic=False):
        # Never close the GUI unless a *new* release was positively detected.
        if automatic:
            return super()._install_update(automatic=True)
        if self._busy:
            return
        if (ROOT / '.bot.lock').exists() or (ROOT / '.practice.lock').exists() or (self.bot_process and self.bot_process.poll() is None):
            messagebox.showwarning('Stop trading first', 'An active bot or practice session is detected. Stop it and verify your brokerage positions first.')
            return
        self._busy = True
        self.update_status.set('Checking whether a new update is available...')
        threading.Thread(target=self._preinstall_worker, daemon=True).start()

    def _preinstall_worker(self):
        try:
            found = available_update(ROOT, self.repo.get())
            result = ('available', found.version) if found else ('current', '')
        except (UpdateError, OSError) as exc:
            result = ('error', str(exc))
        try:
            self.after(0, lambda: self._preinstall_result(result))
        except RuntimeError:
            pass

    def _preinstall_result(self, result):
        self._busy = False
        if result[0] != 'available':
            message = ('No newer version is published yet.' if result[0] == 'current' or
                       'No published update releases' in result[1] else f'Update check failed: {result[1]}')
            self.update_status.set(message)
            messagebox.showinfo('No update to install', message)
            return
        self.update_status.set(f'Update {result[1]} is available.')
        super()._install_update(automatic=False)

    def _paper_update_done(self, response, dry_run):
        state, detail = response
        if state == 'error' and 'No published update releases' in detail:
            self._busy = False
            self.update_status.set('GitHub connected. No published releases yet; using installed version.')
            self._start_ready(dry_run)
            return
        super()._paper_update_done(response, dry_run)

    def _publisher_login(self):
        from publish_helper import cli_path
        cli = cli_path()
        if not cli:
            messagebox.showinfo('Install GitHub CLI', 'Install GitHub CLI from cli.github.com, then reopen the app.\n\nThis is only needed to PUBLISH new releases.')
            webbrowser.open(GITHUB_CLI)
            return
        if not messagebox.askokcancel('Sign in to GitHub', 'A GitHub sign-in window will open. Finish the browser confirmation there.\n\nNo GitHub token is stored in this trading bot.'):
            return
        flags = subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
        try:
            subprocess.Popen([cli, 'auth', 'login', '--web'], creationflags=flags)
        except OSError as exc:
            messagebox.showerror('GitHub sign-in', f'Could not start GitHub CLI: {type(exc).__name__}')

    def _publish_installed(self):
        from build_release import main as make_release
        from publish_helper import cli_path
        if not cli_path():
            messagebox.showwarning('GitHub CLI required', 'Install GitHub CLI and sign in once before publishing.')
            return
        if (ROOT / '.bot.lock').exists() or (ROOT / '.practice.lock').exists():
            messagebox.showwarning('Trading running', 'Stop trading and verify broker positions before packaging this version.')
            return
        if not messagebox.askyesno('Publish current version?',
                f'Build and PUBLICLY publish this installed version ({current_version()}) to {self.repo.get()}?\n\n'
                'This may cause other users to download executable code. Only publish after reviewing and testing it.'):
            return
        try:
            make_release()  # explicit file allowlist; excludes .env, histories and credentials
        except (OSError, RuntimeError) as exc:
            messagebox.showerror('Could not build release', str(exc))
            return
        archive = ROOT.parent / 'ChatGPT_DayTrader_Update.zip'
        self.update_status.set('Publishing reviewed release through the GitHub CLI...')
        threading.Thread(target=self._publish_worker, args=(archive, self.repo.get()), daemon=True).start()

    def _publish_zip(self):
        from publish_helper import inspect_release_zip, cli_path
        if not cli_path():
            messagebox.showwarning('GitHub CLI required', 'Install GitHub CLI and use Sign In To Publish first.')
            return
        archive = filedialog.askopenfilename(title='Choose the GitHub UPDATE ZIP (never full installer)',
                                              filetypes=[('ZIP archives', '*.zip')], parent=self)
        if not archive:
            return
        try:
            version = inspect_release_zip(Path(archive))
        except Exception as exc:
            messagebox.showerror('Unsafe/invalid update ZIP', f'Archive rejected: {type(exc).__name__}: {exc}')
            return
        if not messagebox.askyesno('PUBLISH PUBLIC UPDATE',
                 f'Publish version {version} as a PUBLIC GitHub release in {self.repo.get()}?\n\n'
                 'Only publish a build that you trust and have tested. This may cause users to install code automatically.'):
            return
        self.update_status.set(f'Publishing v{version} with GitHub CLI...')
        threading.Thread(target=self._publish_worker, args=(Path(archive), self.repo.get()), daemon=True).start()

    def _publish_worker(self, archive, repo):
        from publish_helper import publish
        try:
            result = publish(archive, repo)
            msg = f'Published to GitHub! {result}. Click Check Now to see the new version.'
        except Exception as exc:
            msg = f'Publishing failed: {exc}'
        try:
            self.after(0, lambda: self.update_status.set(msg))
        except RuntimeError:
            pass


if __name__ == '__main__':
    DayTraderApp().mainloop()
