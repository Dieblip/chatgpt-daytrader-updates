"""Local GPT signal trader: autonomous paper mode or *explicitly armed* Alpaca live mode.

NOT investment advice; the signal strategy is experimental. Default mode is paper.
Only a dedicated account with no unrelated/manual holdings should be used.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone, time as dt_time
from pathlib import Path
from zoneinfo import ZoneInfo

from settings import Settings, load_settings
from paper_audit import (fetch_paper_orders, order_rows, read_jsonl,
                         close_order_ids)
from strategy import (AIDecision, RiskLimits, bracket_prices, drawdown_hit,
                      indicators, position_shares, technical_entry_allowed)

ROOT = Path(__file__).resolve().parent
NY = ZoneInfo('America/New_York')
WATCHLIST = ('SPY', 'QQQ', 'IWM', 'XLF', 'XLU')
# Market/kill/flatten checks are more frequent than expensive AI signals.
RISK_CHECK_SECONDS = 15
SIGNAL_SECONDS = 300
STOP_FILE = ROOT / 'STOP.txt'
LOCK = ROOT / '.bot.lock'  # One instance, across paper and live.
LOG = ROOT / 'activity_paper.jsonl'
STATE = ROOT / 'state_paper.json'
DECISIONS = ROOT / 'decisions_paper.jsonl'
HEALTH = ROOT / 'health_paper.json'
ORDER_CACHE = ROOT / 'broker_order_status_paper.json'


def set_mode(mode: str) -> None:
    global LOG, STATE, DECISIONS, HEALTH, ORDER_CACHE
    if mode not in ('paper', 'live'):
        raise ValueError('Invalid mode')
    LOG = ROOT / f'activity_{mode}.jsonl'
    STATE = ROOT / f'state_{mode}.json'
    DECISIONS = ROOT / f'decisions_{mode}.jsonl'
    HEALTH = ROOT / f'health_{mode}.json'
    ORDER_CACHE = ROOT / f'broker_order_status_{mode}.json'


def event(kind: str, message: str, **data) -> None:
    record = {'time': datetime.now(timezone.utc).isoformat(), 'kind': kind,
              'message': message, **data}
    with LOG.open('a', encoding='utf-8') as f:
        f.write(json.dumps(record, default=str) + '\n')
    print(f"[{record['time']}] {kind}: {message}", flush=True)


def health_status(status: str, description: str, **details) -> None:
    """Last observed state, not proof that a trade executed. No credentials stored."""
    if not isinstance(status, str):
        raise TypeError('status must be text')
    previous = {}
    if HEALTH.is_file():
        try:
            previous = json.loads(HEALTH.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            previous = {}
    value = {**previous, 'time': datetime.now(timezone.utc).isoformat(),
             'status': status, 'description': description,
             'mode': 'paper' if HEALTH.name.endswith('_paper.json') else 'live', **details}
    temp = HEALTH.with_suffix('.tmp')
    temp.write_text(json.dumps(value, default=str, indent=2), encoding='utf-8')
    temp.replace(HEALTH)


def decision_journal(action: str, symbol: str, reason: str, outcome: str,
                     features: dict, *, outcome_reason: str = '', **details) -> None:
    """Every AI signal gets exactly one explanatory row (paper mode only)."""
    if not DECISIONS.name.endswith('_paper.jsonl'):
        return
    record = {'time': datetime.now(timezone.utc).isoformat(), 'action': action,
              'symbol': symbol, 'ai_reason': reason, 'outcome': outcome,
              'outcome_reason': outcome_reason, 'features': features.get(symbol, {}),
              **details}
    with DECISIONS.open('a', encoding='utf-8') as output:
        output.write(json.dumps(record, default=str) + '\n')
    health_status('AI_DECISION', f'{action} {symbol}: {outcome} — {outcome_reason or reason}',
                  last_decision=record['time'], last_decision_action=action,
                  last_decision_outcome=outcome)


def reconcile_paper_orders(client) -> None:
    """Read-only broker reconciliation; do not mistake submission for a fill."""
    orders = fetch_paper_orders(client)
    seen = {}
    if ORDER_CACHE.exists():
        try:
            seen = json.loads(ORDER_CACHE.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, OSError):
            event('WARN', 'Could not read order-status cache; rechecking history')
    if not isinstance(seen, dict):
        seen = {}
    exits = close_order_ids(LOG)
    changed = 0
    for row in order_rows(orders, exits):
        key = row['order_id']
        # Include partial filled qty to detect status changes even with same status.
        val = f"{row['status']}:{row['filled_qty']}"
        if seen.get(key) == val:
            continue
        changed += 1
        event('BROKER_ORDER', 'Broker-confirmed order status',
              order_id=key, symbol=row['symbol'], side=row['side'],
              broker_status=row['status'], filled_qty=row['filled_qty'],
              filled_avg_price=row['filled_avg_price'])
        seen[key] = val
    # Keep state bounded, and preserve statuses for orders no longer in 60-day window.
    if changed or not ORDER_CACHE.exists():
        trimmed = dict(list(seen.items())[-1500:])
        temp = ORDER_CACHE.with_suffix('.tmp')
        temp.write_text(json.dumps(trimmed), encoding='utf-8')
        temp.replace(ORDER_CACHE)
    if changed:
        health_status('BROKER_RECONCILED', f'{changed} new broker-order status update(s)',
                      last_order_check=datetime.now(timezone.utc).isoformat())


def save_state(state: dict) -> None:
    temp = STATE.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2), encoding='utf-8')
    temp.replace(STATE)


def read_state() -> dict:
    if not STATE.exists():
        return {'day': '', 'entries': 0, 'risk_locked': False, 'managed_symbols': []}
    # Corrupt state must error, not reset trade counters silently.
    data = json.loads(STATE.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or not isinstance(data.get('managed_symbols'), list):
        raise RuntimeError('Invalid state; refusing to trade until repaired')
    return data


def daily_state(today: str) -> dict:
    state = read_state()
    if state.get('day') != today:
        # Keep owned-symbol tracking across a market day rollover.
        state = {'day': today, 'entries': 0, 'risk_locked': False,
                 'managed_symbols': state.get('managed_symbols', []),
                 'account_id': state.get('account_id')}
        save_state(state)
    return state


def local_now() -> datetime:
    return datetime.now(timezone.utc).astimezone(NY)


def load_clients(settings: Settings):
    from alpaca.trading.client import TradingClient
    from alpaca.data.historical import StockHistoricalDataClient
    from openai import OpenAI
    # Critically, LIVE uses a distinct, deliberately selected client and keys.
    trading = TradingClient(settings.key, settings.secret, paper=not settings.live)
    data = StockHistoricalDataClient(settings.key, settings.secret)
    oa = OpenAI(api_key=settings.openai_key, timeout=40.0, max_retries=1)
    return trading, data, oa


def load_features(client) -> dict:
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
    from alpaca.data.enums import DataFeed

    now = datetime.now(timezone.utc)
    bars = client.get_stock_bars(StockBarsRequest(
        symbol_or_symbols=list(WATCHLIST),
        timeframe=TimeFrame(5, TimeFrameUnit.Minute),
        start=now - timedelta(days=10), end=now-timedelta(minutes=1),
        feed=DataFeed.IEX, limit=10000))
    result = {}
    for symbol in WATCHLIST:
        series = bars.data.get(symbol, [])
        try:
            feature = indicators(series)
            latest = max(series, key=lambda bar: bar.timestamp).timestamp
            age = (now - latest.astimezone(timezone.utc)).total_seconds()
            if age < 0 or age > 15 * 60:
                event('WARN', 'Stale data; skipping symbol', symbol=symbol,
                      age_seconds=round(age))
                continue
            result[symbol] = feature
        except (ValueError, IndexError, KeyError) as exc:
            event('WARN', 'Incomplete market data', symbol=symbol, error=str(exc))
    return result


def ai_decision(client, features: dict, positions: dict, model: str, at_time: datetime | None = None) -> AIDecision:
    payload = {
        'technical_indicators': features,
        'current_managed_holdings': {
            s: {'shares': float(p.qty), 'unrealized_percent': round(float(p.unrealized_plpc)*100, 2)}
            for s, p in positions.items() if s in WATCHLIST},
        'approved_symbols': list(WATCHLIST),
        'time_america_new_york': (at_time or local_now()).astimezone(NY).isoformat(),
    }
    response = client.responses.parse(
        model=model,
        input=[
            {'role': 'system', 'content': (
                'You are a cautious and skeptical intraday ETF technical signal model. '
                'Output exactly one BUY, SELL, or HOLD choice using ONLY the supplied technical indicators. '
                'Never invent market conditions, earnings, real-time price or news. '
                'HOLD is preferable to weak evidence. BUY requires corroborating momentum and trend. '
                'SELL only a supplied held position. For HOLD set symbol to NONE. '
                'You do not set quantities, risk thresholds, or execute trades: hard-coded risk rules do. '
                'In one sentence state specific numeric support for any trade.')},
            {'role': 'user', 'content': json.dumps(payload)},
        ],
        text_format=AIDecision,
        reasoning={'effort': 'low'}, max_output_tokens=1200, store=False)
    if response.status != 'completed' or response.output_parsed is None:
        raise RuntimeError('AI response incomplete; no trade')
    return response.output_parsed


def open_orders(client):
    from alpaca.trading.requests import GetOrdersRequest
    from alpaca.trading.enums import QueryOrderStatus
    return client.get_orders(filter=GetOrdersRequest(status=QueryOrderStatus.OPEN, limit=500))


def today_order_count(client, mode: str, today: str) -> int:
    """Account-side counter survives a lost/restarted local state file."""
    from alpaca.trading.requests import GetOrdersRequest
    from alpaca.trading.enums import QueryOrderStatus
    date_start = datetime.fromisoformat(today).replace(tzinfo=NY).astimezone(timezone.utc)
    orders = client.get_orders(filter=GetOrdersRequest(
        status=QueryOrderStatus.ALL, after=date_start, limit=500))
    prefix = f'gptbot-{mode}-{today}-'
    return len({str(o.client_order_id) for o in orders
                if str(getattr(o, 'client_order_id', '')).startswith(prefix)})


def safe_unwind(client, state: dict, why: str, dry_run: bool) -> None:
    """Cancel pending broker orders, confirm cancellation, then flatten *managed* holdings.

    Don't touch an unrelated symbol/position. Fails closed on cancellation errors.
    An order can fill during cancellation; no API can guarantee perfect flattening.
    """
    symbols = set(state.get('managed_symbols', [])) & set(WATCHLIST)
    if not symbols:
        return
    positions = {p.symbol: p for p in client.get_all_positions()}
    orders = [o for o in open_orders(client) if o.symbol in symbols]
    if dry_run:
        event('DRY_RUN', 'Would cancel managed orders and flatten managed holdings',
              why=why, symbols=sorted(symbols))
        return
    def is_pending_market_sell(order) -> bool:
        # A previous close request may still be working. Don't cancel and reissue it
        # on every risk-check heartbeat (that could create an order race).
        order_type = getattr(order, 'type', '')
        side = getattr(order, 'side', '')
        return (str(getattr(order_type, 'value', order_type)).lower() == 'market'
                and str(getattr(side, 'value', side)).lower() == 'sell')

    closing_symbols = {o.symbol for o in orders if is_pending_market_sell(o)}
    if closing_symbols:
        event('INFO', 'Existing market exit still pending; waiting for broker fill',
              symbols=sorted(closing_symbols))
    had_error = False
    for order in orders:
        if order.symbol in closing_symbols:
            continue
        try:
            client.cancel_order_by_id(order.id)
            event('RISK', 'Requested managed order cancellation',
                  symbol=order.symbol, order_id=str(order.id))
        except Exception as exc:
            had_error = True
            event('ERROR', 'Could not cancel managed order; close paused',
                  symbol=order.symbol, error=str(exc))
    if had_error:
        return
    if any(o.symbol not in closing_symbols for o in orders):
        time.sleep(2)
    unresolved = {o.symbol for o in open_orders(client) if o.symbol in symbols} | closing_symbols
    if unresolved:
        event('WARN', 'Open orders remain; holding additional close requests', symbols=sorted(unresolved))
    # Re-fetch in case stops/targets executed during cancellation.
    positions = {p.symbol: p for p in client.get_all_positions()}
    for symbol in sorted(symbols - unresolved):
        position = positions.get(symbol)
        if position is None or float(position.qty) <= 0:
            continue
        try:
            order = client.close_position(symbol)
            event('RISK', 'Submitted close of managed position', why=why,
                  symbol=symbol, order_id=str(order.id))
        except Exception as exc:
            event('ERROR', 'Close failed; retry will follow', symbol=symbol, error=str(exc))


@dataclass
class Snapshot:
    account: object
    positions: dict
    state: dict
    minutes_to_close: float


def risk_check(client, limits: RiskLimits, dry_run: bool) -> Snapshot | None:
    """Fail-closed monitoring; this runs every 15 seconds, not only on AI intervals."""
    state = daily_state(local_now().date().isoformat())
    clock = client.get_clock()
    if STOP_FILE.exists():
        event('RISK', 'STOP.txt active; no new orders; attempting managed liquidation')
        safe_unwind(client, state, 'emergency stop', dry_run)
        return None
    if not clock.is_open:
        # Market-closed waiting is not an error. Show it once so the GUI's
        # Activity tab explains the lack of stock paper trades.
        if not getattr(risk_check, '_waiting_for_open', False):
            event('WAIT', 'Stock market is CLOSED; broker stock orders cannot fill '
                  'until eligible market hours. Use 24/7 Practice for immediate testing.',
                  next_open=str(getattr(clock, 'next_open', 'unknown')))
        risk_check._waiting_for_open = True
        if HEALTH.name.endswith('_paper.json'):
            health_status('MARKET_CLOSED', 'Waiting for next regular stock-market opening',
                          next_open=str(getattr(clock, 'next_open', 'unknown')))
        return None
    risk_check._waiting_for_open = False
    if HEALTH.name.endswith('_paper.json'):
        health_status('MARKET_OPEN', 'Monitoring Alpaca paper account and risk limits')

    account = client.get_account()
    equity, previous_equity = float(account.equity), float(account.last_equity)
    positions = {p.symbol: p for p in client.get_all_positions()}
    minutes_to_close = (clock.next_close.astimezone(timezone.utc) -
                        datetime.now(timezone.utc)).total_seconds()/60
    if not equity > 0 or not previous_equity > 0:
        event('RISK', 'Account equity invalid; no orders')
        return None

    if drawdown_hit(equity, previous_equity, limits.max_daily_loss_pct):
        state['risk_locked'] = True
        save_state(state)
    if state.get('risk_locked'):
        event('RISK', 'Daily equity drawdown lockout', equity=equity,
              previous_close_equity=previous_equity)
        safe_unwind(client, state, 'daily loss cutoff', dry_run)
        return None
    # Exit well before the close. No close guarantee if offline or broker rejects requests.
    if minutes_to_close <= 25:
        event('RISK', 'End-of-day flattening window', minutes_to_close=round(minutes_to_close, 1))
        safe_unwind(client, state, 'end of day', dry_run)
        return None
    return Snapshot(account, positions, state, minutes_to_close)


def signal_cycle(client, data_client, ai_client, model: str, limits: RiskLimits,
                 snapshot: Snapshot, mode: str, dry_run: bool) -> None:
    from alpaca.trading.enums import OrderSide, OrderClass, TimeInForce
    from alpaca.trading.requests import MarketOrderRequest, TakeProfitRequest, StopLossRequest

    now = local_now()
    if now.time() < dt_time(9, 50) or snapshot.minutes_to_close <= 40:
        if mode == 'paper':
            status = ('BEFORE_ENTRY_WINDOW' if now.time() < dt_time(9, 50) else 'ENTRY_WINDOW_CLOSED')
            health_status(status, 'No entries until 9:50 AM ET or within 40 minutes of close')
        return
    account, positions, state = snapshot.account, snapshot.positions, snapshot.state
    if bool(account.account_blocked) or bool(account.trading_blocked):
        event('RISK', 'Broker account is blocked')
        if mode == 'paper':
            health_status('RISK_BLOCKED', 'Broker account is blocked')
        return
    if any(float(p.qty) < 0 for p in positions.values()):
        event('RISK', 'Unexpected short position; no trades')
        if mode == 'paper':
            health_status('RISK_BLOCKED', 'Unexpected short position on account')
        return

    pending = open_orders(client)
    managed = set(state.get('managed_symbols', [])) & set(WATCHLIST)
    if any(o.symbol not in managed for o in pending):
        event('RISK', 'Unmanaged open broker order; no AI trades')
        if mode == 'paper':
            health_status('RISK_BLOCKED', 'Unmanaged broker order detected; check Alpaca')
        return
    if any(s not in managed for s in positions):
        event('RISK', 'Unmanaged position on account; no AI trades')
        if mode == 'paper':
            health_status('RISK_BLOCKED', 'Unmanaged holdings detected; use a dedicated bot paper account')
        return
    # Calls with unknown orders/positions do not reach the model.
    if mode == 'paper':
        health_status('ANALYZING', 'Fetching five-minute IEX bars and AI signal')
    features = load_features(data_client)
    if not features:
        event('WARN', 'No fresh market data; holding')
        if mode == 'paper':
            health_status('NO_FRESH_DATA', 'Market data unavailable or stale; no order sent')
        return
    try:
        decision = ai_decision(ai_client, features, positions, model)
    except Exception as exc:
        event('ERROR', 'AI unavailable; no trade', error=str(exc))
        if mode == 'paper':
            health_status('AI_ERROR', 'OpenAI signal unavailable; no order sent', last_error=str(exc)[:300])
        return
    symbol = decision.symbol.upper().strip()
    event('AI', f'{decision.action} {symbol}: {decision.reason}')
    def finish(outcome: str, reason: str, **extra) -> None:
        decision_journal(decision.action, symbol, decision.reason, outcome,
                         features, outcome_reason=reason, **extra)
    if decision.action == 'HOLD':
        finish('HOLD', 'AI did not identify a qualified trade')
        return
    if symbol not in WATCHLIST or symbol not in features:
        event('RISK', 'Rejected unapproved/stale symbol', symbol=symbol)
        finish('REJECTED', 'Symbol unapproved or lacks fresh market data')
        return

    if decision.action == 'SELL':
        if symbol not in managed or symbol not in positions or float(positions[symbol].qty) <= 0:
            event('RISK', 'Refused sell of unowned/unmanaged position', symbol=symbol)
            finish('REJECTED', 'No verified bot-managed long position to sell')
            return
        safe_unwind(client, state, 'AI exit signal', dry_run)
        finish('EXIT_REQUESTED' if not dry_run else 'DRY_RUN',
               'Requested managed exit; confirm final fills with Alpaca')
        return

    if decision.action == 'BUY':
        if positions or pending:
            event('RISK', 'Existing position or working order; no new entry')
            finish('REJECTED', 'Already holding a position or working order')
            return
        if state.get('entries', 0) >= limits.max_entries_per_day:
            event('RISK', 'Local daily entry limit reached')
            finish('REJECTED', 'Reached local daily entry cap')
            return
        # A broker-side order count prevents exceeding the cap after a crash or lost state.
        # An API error here must block the trade instead of guessing the count.
        try:
            broker_entries = today_order_count(client, mode, state['day'])
        except Exception as exc:
            event('ERROR', 'Could not verify broker daily order count; blocking entry', error=str(exc))
            finish('REJECTED', 'Could not verify broker-side daily entry count')
            return
        if broker_entries >= limits.max_entries_per_day:
            event('RISK', 'Broker-verified daily entry limit reached')
            finish('REJECTED', 'Reached broker-verified daily entry cap')
            return
        if not technical_entry_allowed(features[symbol]):
            event('RISK', 'Technical entry filter rejected AI BUY', symbol=symbol)
            finish('REJECTED', 'Numeric technical rules did not confirm BUY')
            return
        price = float(features[symbol]['price'])
        shares = position_shares(float(account.equity), float(account.cash), price,
                                 limits.max_position_pct, limits.max_order_dollars)
        if shares < 1:
            event('RISK', 'Cash, position or dollar cap too small for a whole share', symbol=symbol)
            finish('REJECTED', 'Risk budget does not cover one whole share')
            return
        stop, target = bracket_prices(price, limits.stop_loss_pct, limits.take_profit_pct)
        if stop <= 0 or stop >= price or target <= price:
            event('RISK', 'Invalid bracket prices', symbol=symbol)
            finish('REJECTED', 'Stop-loss or take-profit was invalid')
            return
        if dry_run:
            event('DRY_RUN', f'Would {mode}-buy with broker bracket', symbol=symbol,
                  qty=shares, reference_price=price, stop_loss=stop, take_profit=target)
            finish('DRY_RUN', 'Eligible setup; no broker order sent',
                   qty=shares, reference_price=price)
            return
        # Save an attempted entry BEFORE calling broker to prevent duplicate retry on timeout/crash.
        # Entries may be counted even if rejected; that is intentionally fail-safe.
        client_id = f'gptbot-{mode}-{state["day"]}-{symbol}-{int(time.time() * 1000)}'
        state['entries'] = max(int(state.get('entries', 0)), broker_entries) + 1
        state['managed_symbols'] = sorted(managed | {symbol})
        state['last_entry_client_id'] = client_id
        save_state(state)
        try:
            order = client.submit_order(order_data=MarketOrderRequest(
                symbol=symbol, qty=shares, side=OrderSide.BUY,
                time_in_force=TimeInForce.DAY, order_class=OrderClass.BRACKET,
                stop_loss=StopLossRequest(stop_price=stop),
                take_profit=TakeProfitRequest(limit_price=target),
                client_order_id=client_id))
            event('ORDER', f'{mode.upper()} bracket entry submitted', symbol=symbol,
                  qty=shares, reference_price=price, stop_loss=stop,
                  take_profit=target, order_id=str(order.id))
            finish('SUBMITTED_NOT_FILLED',
                   'Alpaca accepted order request; waiting for broker fill confirmation',
                   order_id=str(order.id), qty=shares, reference_price=price)
        except Exception as exc:
            event('ERROR', 'Entry order result uncertain; do NOT retry blindly; inspect broker',
                  symbol=symbol, client_order_id=client_id, error=str(exc))
            finish('SUBMISSION_UNCERTAIN',
                   'Broker API error; check Alpaca before any retry',
                   client_order_id=client_id, error_type=type(exc).__name__)


def main() -> int:
    parser = argparse.ArgumentParser(description='Autonomous ETF bot; PAPER by default')
    parser.add_argument('--live', action='store_true', help='Select real-money Alpaca account')
    parser.add_argument('--confirm-live', action='store_true', help='Second explicit live trading permission')
    parser.add_argument('--once', action='store_true', help='One risk check + one signal cycle')
    parser.add_argument('--dry-run', action='store_true', help='No orders (including no liquidation)')
    args = parser.parse_args()
    try:
        settings = load_settings(ROOT, live=args.live, confirmed=args.confirm_live)
    except RuntimeError as exc:
        print(f'Configuration error: {exc}', file=sys.stderr)
        return 2
    set_mode(settings.mode)
    limits = RiskLimits(max_order_dollars=settings.max_order_dollars)
    try:
        lock_fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        print('Another bot is running or a stale .bot.lock exists; inspect and stop it before proceeding.', file=sys.stderr)
        return 3
    try:
        with os.fdopen(lock_fd, 'w', encoding='utf-8') as f:
            f.write(f'{os.getpid()} {settings.mode}\n')
        trading, data, ai = load_clients(settings)
        # Bind the local state to one brokerage account. Never apply old
        # symbol ownership metadata to a different account's live positions.
        account = trading.get_account()
        broker_account_id = str(account.id)
        state = read_state()
        if state.get('account_id') not in (None, broker_account_id):
            raise RuntimeError('Account ID changed for this mode. Stop and reconcile state/broker positions manually; refusing to trade.')
        if state.get('account_id') is None:
            state['account_id'] = broker_account_id
            save_state(state)
        event('INFO', f'Started {settings.mode.upper()} autonomous mode',
              dry_run=args.dry_run, model=settings.model, watchlist=WATCHLIST,
              max_position_percent=limits.max_position_pct*100,
              max_order_dollars=limits.max_order_dollars)
        next_signal = 0.0
        next_reconciliation = 0.0
        if settings.mode == 'paper':
            health_status('STARTING', 'Connected to paper account; beginning monitoring',
                          account_id=broker_account_id, dry_run=args.dry_run)
        while True:
            try:
                snapshot = risk_check(trading, limits, args.dry_run)
                if settings.mode == 'paper' and time.monotonic() >= next_reconciliation:
                    next_reconciliation = time.monotonic() + 60
                    try:
                        reconcile_paper_orders(trading)
                    except Exception as audit_exc:
                        event('WARN', 'Could not reconcile broker orders; fill status unknown',
                              error=str(audit_exc))
                if STOP_FILE.exists():
                    if args.dry_run:
                        event('INFO', 'Dry-run stop requested; exiting without orders')
                        break
                    # Let the emergency exit finish if broker connectivity is present.
                    state_now = read_state()
                    managed_now = set(state_now.get('managed_symbols', [])) & set(WATCHLIST)
                    outstanding = [o for o in open_orders(trading) if o.symbol in managed_now]
                    holdings = [p for p in trading.get_all_positions() if p.symbol in managed_now
                                and float(p.qty) != 0]
                    if not outstanding and not holdings:
                        event('INFO', 'Emergency exit verified no managed exposure; bot stopping')
                        break
                if snapshot is not None and time.monotonic() >= next_signal:
                    # Schedule next cycle even after model/broker failure to limit retries/cost.
                    next_signal = time.monotonic() + SIGNAL_SECONDS
                    signal_cycle(trading, data, ai, settings.model, limits,
                                 snapshot, settings.mode, args.dry_run)
            except Exception as exc:
                event('ERROR', 'Monitoring/cycle failed; new trades suspended until next check', error=str(exc))
                if settings.mode == 'paper':
                    health_status('ERROR', 'Monitoring check failed; no new orders this cycle',
                                  last_error=str(exc)[:300])
                traceback.print_exc()
            if args.once:
                break
            time.sleep(RISK_CHECK_SECONDS)
    except KeyboardInterrupt:
        event('INFO', 'Program stopped; existing broker orders and positions may remain active')
    except Exception as exc:
        event('ERROR', 'Cannot initialize broker; nothing traded', error=str(exc))
        return 4
    finally:
        LOCK.unlink(missing_ok=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
