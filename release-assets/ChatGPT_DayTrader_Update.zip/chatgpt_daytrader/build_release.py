"""Create a publish-ready GitHub Release ZIP; NEVER package keys or state."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path
from updater import ASSET_NAME, RELEASE_FOLDER, current_version

ROOT = Path(__file__).resolve().parent
# Explicit allowlist is deliberate: never pack .env, .venv, trading state,
# logs, key files, or user-created private data.
RELEASE_FILES = [
    '.gitignore', 'ADVANCED_GUIDE.md', 'CHECK_UPDATES.bat',
    'DASHBOARD.bat', 'DRY_RUN.bat', 'MAKE_RELEASE.bat', 'PUBLISH_TO_GITHUB.md',
    'READ_ME_FIRST.html', 'README.md', 'RUN_BOT.bat', 'RUN_LIVE.bat',
    'SETUP_WINDOWS.bat', 'START_HERE.bat', 'RUN_ALL.bat', 'STOP_BOT.bat', 'UPDATE_NOW.bat',
    'bot.py', 'build_release.py', 'dashboard.py', 'easy_control.py', 'unified_control.py', 'unified_setup.py',
    'launchpad.py', 'quick_connect.py', 'publish_helper.py', 'START_DAYTRADER.bat', 'QUICK_START.txt',
    'easy_setup_utils.py', 'requirements.txt', 'settings.py', 'setup_deps.py',
    'strategy.py', 'practice.py', 'paper_audit.py', 'updater.py', 'version.json',
    'CHANGES_V6_1.md',
    'tests/test_easy_setup.py', 'tests/test_live_safety.py',
    'tests/test_practice.py', 'tests/test_quick_connect_v6.py',
    'tests/test_strategy.py', 'tests/test_unified_setup.py',
    'tests/test_updater.py', 'tests/test_paper_audit.py', 'tests/test_signal_journal.py',
]


def main():
    version = current_version(ROOT)
    target = ROOT.parent / ASSET_NAME
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name in RELEASE_FILES:
            source = ROOT / name
            if not source.is_file() or source.is_symlink():
                raise RuntimeError(f'Cannot build release, missing/unsafe file: {name}')
            output.write(source, f'{RELEASE_FOLDER}/{name}')
    print(f'Created GitHub release asset for v{version}: {target}')
    print('This ZIP contains NO API keys or trading history.')
    print('Upload it as an asset in a GitHub Release with tag v' + version)
    return 0


if __name__ == '__main__':
    sys.exit(main())
