"""Reinstall Python dependencies only if requirements.txt changed."""
import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    req = ROOT / 'requirements.txt'
    marker = ROOT / '.venv' / '.requirements_sha256'
    digest = hashlib.sha256(req.read_bytes()).hexdigest()
    if marker.exists() and marker.read_text(encoding='utf-8').strip() == digest:
        print('Packages are up to date.')
        return 0
    print('Installing/updating required packages...')
    result = subprocess.call([sys.executable, '-m', 'pip', 'install', '-r', str(req)])
    if result != 0:
        print('Package installation failed; no trading process will start.')
        return result
    marker.write_text(digest + '\n', encoding='utf-8')
    return 0


if __name__ == '__main__':
    sys.exit(main())
