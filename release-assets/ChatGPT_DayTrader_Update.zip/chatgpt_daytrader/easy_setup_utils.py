"""Simple, paper-only configuration helpers for the Windows control center.

Never handles live trading configuration; existing live safety gates remain separate.
"""
from __future__ import annotations

from pathlib import Path
from shutil import copyfile

from dotenv import dotenv_values, set_key
from settings import resolve_settings

PAPER_FIELDS = ('ALPACA_PAPER_KEY', 'ALPACA_PAPER_SECRET', 'OPENAI_API_KEY',
                'MAX_ORDER_DOLLARS')


def paper_inputs_valid(paper_key: str, paper_secret: str, openai_key: str,
                       max_order_dollars: str):
    values = {
        'ALPACA_PAPER_KEY': paper_key.strip(),
        'ALPACA_PAPER_SECRET': paper_secret.strip(),
        'OPENAI_API_KEY': openai_key.strip(),
        'MAX_ORDER_DOLLARS': max_order_dollars.strip(),
        'OPENAI_MODEL': 'gpt-6.1-sol',
    }
    if any('\r' in value or '\n' in value for value in values.values()):
        raise ValueError('Keys and dollar limit must be single-line values.')
    try:
        settings = resolve_settings(values, live=False, confirmed=False)
    except RuntimeError as exc:
        msg = str(exc)
        if 'Missing' in msg:
            raise ValueError('Fill in all 3 API key boxes first.') from exc
        if 'MAX_ORDER_DOLLARS' in msg:
            raise ValueError('Enter a maximum per order between $10 and $5,000.') from exc
        raise ValueError(msg) from exc
    return values, settings


def save_paper_keys(root: Path, paper_key: str, paper_secret: str,
                    openai_key: str, max_order_dollars: str):
    """Keep any existing live credentials/ack exactly as they are."""
    values, settings = paper_inputs_valid(paper_key, paper_secret,
                                          openai_key, max_order_dollars)
    env = root / '.env'
    if not env.exists():
        copyfile(root / '.env.example', env)
    for key in PAPER_FIELDS:
        set_key(str(env), key, values[key], quote_mode='always')
    # Re-read to ensure the saved file will resolve in the bot.
    resolve_settings(dotenv_values(env), live=False, confirmed=False)
    return settings


def config_is_ready(root: Path) -> bool:
    env = root / '.env'
    if not env.exists():
        return False
    try:
        resolve_settings(dotenv_values(env), live=False, confirmed=False)
    except RuntimeError:
        return False
    return True
