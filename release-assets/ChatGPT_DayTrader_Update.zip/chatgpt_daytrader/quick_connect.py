"""First-run helpers for a browser-assisted, local-only credential setup.

GitHub release downloads are PUBLIC and need no GitHub authorization.
Trading credentials are never transmitted to GitHub.
"""
from __future__ import annotations

from pathlib import Path
from typing import Mapping
from dotenv import dotenv_values

DEFAULT_REPO = 'Dieblip/chatgpt-daytrader-updates'


def configured(values: Mapping[str, str], mode: str = 'paper') -> bool:
    if mode not in ('paper', 'live'):
        return False
    prefix = 'ALPACA_PAPER_' if mode == 'paper' else 'ALPACA_LIVE_'
    return all(str(values.get(k, '')).strip() for k in
               (prefix + 'KEY', prefix + 'SECRET', 'OPENAI_API_KEY'))


def import_old_keys(folder: Path) -> dict[str, str]:
    """Return only known UI fields; never import live permissions or updater configuration."""
    path = folder / '.env'
    if not path.is_file():
        raise ValueError('No .env file was found in that folder. Choose the old chatgpt_daytrader folder.')
    source = dotenv_values(path)
    from unified_setup import KEYS
    return {key: str(source.get(key, '') or '') for key in KEYS if source.get(key)}


def release_hint(message: str) -> str:
    message = message.lower()
    if '404' in message or 'not found' in message or 'no published release' in message:
        return 'GitHub connected. No published update release yet — your current version can still run.'
    return ''
