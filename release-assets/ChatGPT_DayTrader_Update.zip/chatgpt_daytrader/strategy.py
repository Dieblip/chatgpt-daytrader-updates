"""Pure, testable signal features and position limits. No network operations."""
from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Literal

from pydantic import BaseModel, ConfigDict


class AIDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: Literal["BUY", "SELL", "HOLD"]
    symbol: str
    reason: str


@dataclass(frozen=True)
class RiskLimits:
    max_position_pct: float = 0.05
    max_daily_loss_pct: float = 0.01
    max_entries_per_day: int = 3
    stop_loss_pct: float = 0.008
    take_profit_pct: float = 0.012
    max_order_dollars: float = 1500.0

    def __post_init__(self) -> None:
        if not 0 < self.max_position_pct <= 0.1:
            raise ValueError("max_position_pct must be >0 and <=10%")
        if not 0 < self.max_daily_loss_pct <= 0.03:
            raise ValueError("max_daily_loss_pct must be >0 and <=3%")
        if not 0 <= self.max_entries_per_day <= 5:
            raise ValueError("max_entries_per_day must be 0..5")
        if not 0 < self.stop_loss_pct <= 0.03:
            raise ValueError("stop_loss_pct must be >0 and <=3%")
        if not 0 < self.take_profit_pct <= 0.05:
            raise ValueError("take_profit_pct must be >0 and <=5%")
        if not 10 <= self.max_order_dollars <= 5000:
            raise ValueError("max_order_dollars must be $10..$5000")


def position_shares(equity: float, cash: float, price: float, position_pct: float, max_dollars: float = 1500) -> int:
    """Cash-only whole-share entry. Reserve 5% of quoted cost for movement/fees."""
    if not all(math.isfinite(float(x)) for x in (equity, cash, price, position_pct, max_dollars)):
        return 0
    if equity <= 0 or cash <= 0 or price <= 0 or not (0 < position_pct <= 0.1) or not 10 <= max_dollars <= 5000:
        return 0
    budget = min(equity * position_pct, cash * 0.95, max_dollars)
    return max(0, math.floor(budget / (price * 1.05)))


def drawdown_hit(equity: float, last_equity: float, limit: float) -> bool:
    return last_equity > 0 and equity / last_equity - 1 <= -limit


def ema(prices: list[float], span: int) -> float:
    smoothing = 2 / (span + 1)
    value = prices[0]
    for price in prices[1:]:
        value = smoothing * price + (1 - smoothing) * value
    return value


def rsi(prices: list[float], period: int = 14) -> float:
    if len(prices) <= period:
        raise ValueError("not enough data for RSI")
    deltas = [b-a for a, b in zip(prices[-period-1:-1], prices[-period:])]
    ups = sum(max(0, x) for x in deltas) / period
    downs = sum(max(0, -x) for x in deltas) / period
    if downs == 0:
        return 100.0 if ups > 0 else 50.0
    return 100 - 100 / (1 + ups / downs)


def indicators(bars: list) -> dict:
    """Bars sorted by timestamp oldest first; rejects corrupt/short history."""
    if len(bars) < 35:
        raise ValueError(f"not enough bars ({len(bars)}; need 35)")
    bars = sorted(bars, key=lambda b: b.timestamp)
    prices = [float(b.close) for b in bars]
    if any(not math.isfinite(p) or p <= 0 for p in prices):
        raise ValueError("invalid market price")
    return {
        "price": round(prices[-1], 3),
        "ema9": round(ema(prices, 9), 3),
        "ema21": round(ema(prices, 21), 3),
        "rsi14": round(rsi(prices), 1),
        "return_1h_pct": round((prices[-1] / prices[-13] - 1) * 100, 2),
        "last_bar_utc": bars[-1].timestamp.isoformat(),
        "bars_seen": len(bars),
    }


def bracket_prices(price: float, stop_loss_pct: float, take_profit_pct: float) -> tuple[float, float]:
    if not math.isfinite(price) or price <= 0:
        raise ValueError("invalid price")
    return (round(price * (1-stop_loss_pct), 2),
            round(price * (1+take_profit_pct), 2))


def technical_entry_allowed(feature: dict) -> bool:
    """Deterministic sanity filter; never accept a BUY solely on model preference."""
    try:
        p = float(feature["price"])
        e9 = float(feature["ema9"])
        e21 = float(feature["ema21"])
        r = float(feature["rsi14"])
        momentum = float(feature["return_1h_pct"])
    except (KeyError, TypeError, ValueError):
        return False
    return all(math.isfinite(x) for x in (p,e9,e21,r,momentum)) and p > 0 and p > e9 > e21 and 45 <= r <= 72 and 0 < momentum < 3
