"""Read-only Alpaca PAPER audit: orders, completed round trips, and bot diagnostics.

No order submission functions live here. All calculations are estimates from reported
filled quantities/average prices, not a brokerage statement or tax record.
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

PREFIX = 'gptbot-paper-'
MAX_ORDERS = 500  # Alpaca's endpoint limit. This is a window, not lifetime results.


def field(item: object, name: str, fallback: Any = None) -> Any:
    return item.get(name, fallback) if isinstance(item, dict) else getattr(item, name, fallback)


def enum_name(value: object) -> str:
    return str(getattr(value, 'value', value) or '').lower()


def flatten_orders(orders: list) -> list:
    """Flatten nested Alpaca bracket legs, deduplicating by broker order ID."""
    output, seen = [], set()
    def walk(order: object):
        order_id = str(field(order, 'id') or '')
        if order_id and order_id not in seen:
            seen.add(order_id)
            output.append(order)
        elif not order_id:
            output.append(order)
        for leg in field(order, 'legs') or []:
            walk(leg)
    for order in orders:
        walk(order)
    return output


def fetch_paper_orders(client, lookback_days: int = 60) -> list:
    """READ ONLY. Caller supplies TradingClient(paper=True); never construct live client."""
    from alpaca.trading.requests import GetOrdersRequest
    from alpaca.trading.enums import QueryOrderStatus
    start = datetime.now(timezone.utc) - timedelta(days=lookback_days)
    return client.get_orders(filter=GetOrdersRequest(
        status=QueryOrderStatus.ALL, after=start, limit=MAX_ORDERS, nested=True))


def _when(stamp: object) -> str:
    stamp = stamp or ''
    if isinstance(stamp, datetime):
        return stamp.astimezone(timezone.utc).isoformat()
    return str(stamp)


def known_bot_order_ids(orders: list, close_ids: set[str] | None = None) -> set[str]:
    """Recognize entries and child bracket exits; untagged closes require local log ID."""
    flat = flatten_orders(orders)
    groups = {str(field(o, 'group_id')) for o in flat
              if str(field(o, 'client_order_id', '')).startswith(PREFIX)
              and field(o, 'group_id')}
    accepted = set(close_ids or ())
    for o in flat:
        if str(field(o, 'client_order_id', '')).startswith(PREFIX) or (
                field(o, 'group_id') and str(field(o, 'group_id')) in groups):
            accepted.add(str(field(o, 'id')))
    # Some API variants omit group_id but return nested child orders.
    for top in orders:
        if str(field(top, 'client_order_id', '')).startswith(PREFIX):
            for child in flatten_orders(field(top, 'legs') or []):
                accepted.add(str(field(child, 'id')))
    return accepted


def order_rows(orders: list, close_ids: set[str] | None = None) -> list[dict]:
    permitted = known_bot_order_ids(orders, close_ids)
    rows = []
    for o in flatten_orders(orders):
        if str(field(o, 'id')) not in permitted:
            continue
        rows.append({
            'order_id': str(field(o, 'id') or ''),
            'client_order_id': str(field(o, 'client_order_id') or ''),
            'symbol': str(field(o, 'symbol') or ''),
            'side': enum_name(field(o, 'side')),
            'status': enum_name(field(o, 'status')),
            'qty': str(field(o, 'qty') or ''),
            'filled_qty': str(field(o, 'filled_qty') or '0'),
            'filled_avg_price': str(field(o, 'filled_avg_price') or ''),
            'filled_at': _when(field(o, 'filled_at')),
            'submitted_at': _when(field(o, 'submitted_at')),
        })
    return rows


def _number(value: object) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else 0.0
    except (ValueError, TypeError):
        return 0.0


def trade_performance(orders: list, close_ids: set[str] | None = None) -> dict:
    """Estimate completed round trips using *recognized* filled bot orders only.

    Bracket exits and logged emergency closes are associated with bot entries.
    If history is incomplete, the result intentionally excludes unmatched exits.
    Fees, dividends, corporate actions, and partial fills aren't fully accounted for.
    """
    rows = [r for r in order_rows(orders, close_ids)
            if r['status'] == 'filled' and _number(r['filled_qty']) > 0
            and _number(r['filled_avg_price']) > 0]
    rows.sort(key=lambda r: (r['filled_at'], r['order_id']))
    held: dict[str, dict] = {}
    completed = []
    ignored = 0
    partial = 0
    for r in rows:
        symbol = r['symbol']
        side = r['side']
        qty = _number(r['filled_qty'])
        price = _number(r['filled_avg_price'])
        if side == 'buy':
            # Never attribute manual/unrelated buys to this bot.
            if not r['client_order_id'].startswith(PREFIX):
                continue
            pos = held.setdefault(symbol, {'qty': 0.0, 'cost': 0.0, 'realized': 0.0,
                                           'started': r['filled_at']})
            pos['cost'] += price * qty
            pos['qty'] += qty
        elif side == 'sell':
            pos = held.get(symbol)
            if not pos or pos['qty'] <= 0:
                ignored += 1
                continue
            matched = min(qty, pos['qty'])
            unit_cost = pos['cost'] / pos['qty']
            pos['cost'] -= matched * unit_cost
            pos['qty'] -= matched
            pos['realized'] += (price - unit_cost) * matched
            if qty > matched + 0.000001:
                ignored += 1
            if pos['qty'] <= 0.000001:
                completed.append({'symbol': symbol, 'opened': pos['started'],
                                  'closed': r['filled_at'],
                                  'pnl': round(pos['realized'], 2),
                                  'result': ('WIN' if pos['realized'] > 0.005 else
                                             'LOSS' if pos['realized'] < -0.005 else 'FLAT')})
                held.pop(symbol)
            else:
                partial += 1
    wins = sum(t['result'] == 'WIN' for t in completed)
    losses = sum(t['result'] == 'LOSS' for t in completed)
    flat = len(completed) - wins - losses
    return {
        'completed': completed, 'closed_trades': len(completed),
        'wins': wins, 'losses': losses, 'flat': flat,
        'win_rate': round(wins / (wins + losses) * 100, 1) if wins + losses else None,
        'realized_pnl': round(sum(t['pnl'] for t in completed), 2),
        'open_cycles': len(held), 'unmatched_exits': ignored,
        'partial_exits': partial, 'source_count': len(orders),
        'history_may_be_truncated': len(orders) >= MAX_ORDERS,
    }


def read_jsonl(path: Path, limit: int = 500) -> list[dict]:
    if not path.is_file():
        return []
    out = []
    # Read a bounded tail, avoiding loading massive bot logs into RAM.
    with path.open('rb') as f:
        f.seek(0, 2)
        pos = f.tell()
        data = bytearray()
        while pos > 0 and len(data) < 3_000_000 and data.count(b'\n') <= limit:
            size = min(8192, pos)
            pos -= size
            f.seek(pos)
            data[:0] = f.read(size)
    for line in bytes(data).splitlines()[-limit:]:
        try:
            record = json.loads(line)
            if isinstance(record, dict):
                out.append(record)
        except (ValueError, UnicodeDecodeError):
            continue
    return out


def close_order_ids(activity_file: Path) -> set[str]:
    return {str(e['order_id']) for e in read_jsonl(activity_file, 10000)
            if e.get('message') == 'Submitted close of managed position' and e.get('order_id')}
