# GitHub — easy publisher and updater

**To RECEIVE updates**: Nothing to connect. The V6 GUI already knows `Dieblip/chatgpt-daytrader-updates`. Open the **Updates** tab and press **CHECK NOW**. Published releases are public; no GitHub password, PAT, or CLI required.

**To SEND new updates** directly from the GUI (optional):

1. Install [GitHub CLI](https://cli.github.com/), reopen the app, and select **Updates**.
2. Click **Sign In To Publish**. Follow the official browser login prompt. Do not paste GitHub tokens into the trading bot.
3. Click **Publish THIS Installed Version** to build an allowlisted release ZIP automatically, or **Choose ZIP & Publish** to upload a separately prepared release ZIP.
4. Confirm the version and destination repository. The app publishes a new public GitHub Release and refuses to overwrite an existing version.
5. Other copies of the bot will then detect the new version from GitHub Releases.

If GitHub CLI is unavailable, manually upload an update ZIP with the exact filename `ChatGPT_DayTrader_Update.zip` through GitHub's Releases page, tagging it `vX.Y.Z`, or use the existing repository's Actions upload workflow.

**Crucial:** Never publish `.env`, logs, `.venv`, account data, or any private keys. Update ZIP archives must use the `chatgpt_daytrader/` folder. Release assets are hash-checked; this does **not** authenticate a publisher or guarantee code safety. Review every release before enabling automatic installation.
