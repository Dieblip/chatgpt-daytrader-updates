@echo off
setlocal
cd /d "%~dp0"
py -3 updater.py --check
pause
