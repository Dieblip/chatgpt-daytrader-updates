"""Local monitor. Account/status only; the emergency stop is file-based."""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
import streamlit as st
from dotenv import dotenv_values
from alpaca.trading.client import TradingClient
from paper_audit import (fetch_paper_orders, trade_performance, read_jsonl,
                         close_order_ids, order_rows)

ROOT = Path(__file__).resolve().parent
v = dotenv_values(ROOT / '.env')
st.set_page_config(page_title='ChatGPT Day Trader — Autonomous', page_icon='📈', layout='wide')
st.title('📈 ChatGPT Autonomous Day Trader')
st.caption('Local account monitor. The bot must be started separately on your computer.')
choices = ['paper', 'live', 'practice']
requested = st.query_params.get('account', 'paper')
mode = st.radio('Account to view', choices, index=choices.index(requested) if requested in choices else 0, horizontal=True)
if mode == 'practice':
    st.success('24/7 PRACTICE — LOCAL SIMULATION ONLY. No orders go to Alpaca.')
    st.caption('SCRIPTED DEMO uses made-up prices and no AI; AI REPLAY uses past IEX stock data and real OpenAI decisions. Both simulate assumed fills, not broker fills. Neither proves profitability.')
    practice_file = ROOT / 'practice_state.json'
    if practice_file.exists():
        try:
            state = json.loads(practice_file.read_text(encoding='utf-8'))
            a, b, c, d = st.columns(4)
            a.metric('Practice status', state.get('status', 'UNKNOWN'))
            b.metric('Simulated equity', f"${float(state.get('equity', 0)):,.2f}")
            c.metric('Fake entries', int(state.get('entries', 0)))
            d.metric('Fake closed trades', int(state.get('closed', 0)))
            st.write(f"**Simulated P&L:** ${float(state.get('realized_pnl', 0)):+,.2f}")
            st.write(f"**Test type:** {state.get('kind', 'unknown')}")
            if state.get('position'):
                st.write('**Open simulated position:**', state['position'])
            if state.get('error'):
                st.error(str(state['error']))
            st.caption(str(state.get('note', 'Local demonstration only.')))
        except (ValueError, OSError, KeyError) as exc:
            st.error(f'Practice state could not be read: {exc}')
    else:
        st.info('No practice test has run yet. In the Windows control center, click INSTANT SAMPLE TRADES.')
    if st.button('Stop practice test (no broker orders)'):
        (ROOT / 'PRACTICE_STOP.txt').write_text('STOP PRACTICE\n', encoding='utf-8')
        st.info('Practice stop requested; no brokerage orders exist from this mode.')
    records_file = ROOT / 'practice_trades.jsonl'
    if records_file.exists():
        recs = []
        for line in records_file.read_text(encoding='utf-8').splitlines()[-300:]:
            try:
                recs.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        if recs:
            st.subheader('Assumed fake fills — not Alpaca orders')
            st.dataframe(pd.DataFrame(recs[::-1]), use_container_width=True, hide_index=True)
    logpath = ROOT / 'activity_practice.jsonl'
    if logpath.exists():
        logs = []
        for line in logpath.read_text(encoding='utf-8').splitlines()[-180:]:
            try:
                logs.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        if logs:
            st.subheader('Practice activity')
            df = pd.DataFrame(logs[::-1])
            st.dataframe(df[[x for x in ['time', 'kind', 'message', 'historical_time', 'simulated_pnl', 'error'] if x in df]],
                         use_container_width=True, hide_index=True)
    if records_file.exists():
        fake_closes = [e for e in read_jsonl(records_file, 3000) if e.get('action') == 'SELL']
        if fake_closes:
            wins = sum(float(e.get('realized_pnl', 0)) > 0 for e in fake_closes)
            losses = sum(float(e.get('realized_pnl', 0)) < 0 for e in fake_closes)
            n = wins + losses
            st.metric('Practice win rate (non-flat completed trades)', f'{wins/n*100:.1f}%' if n else 'N/A')
            st.caption('Practice fills are hypothetical and do not predict results or appear in Alpaca.')
    if st.button('Refresh practice results'):
        st.rerun()
    st.stop()

if mode == 'live':
    st.error('LIVE VIEW: these are REAL brokerage balances. Viewing them does not start the bot.')
    key, secret = v.get('ALPACA_LIVE_KEY'), v.get('ALPACA_LIVE_SECRET')
else:
    st.info('PAPER VIEW: simulated account and simulated trades.')
    key, secret = v.get('ALPACA_PAPER_KEY'), v.get('ALPACA_PAPER_SECRET')

cols = st.columns(4)
cols[0].metric('Selected broker', f'Alpaca {mode.upper()}')
cols[1].metric('Max position', '5% equity')
cols[2].metric('Daily equity cutoff', '1%')
cols[3].metric('Maximum entries', '3 per day')

if (ROOT / '.bot.lock').exists():
    st.write(f"**Bot lock present:** {(ROOT / '.bot.lock').read_text(encoding='utf-8').strip()}")
else:
    st.write('**Bot appears stopped** (verify in Windows Task Manager).')

if (ROOT / 'STOP.txt').exists():
    st.error('STOP.txt is active. New entries are disabled. Running bot attempts to cancel and exit managed positions.')
else:
    if st.button('🚨 EMERGENCY STOP — stop entries and request exit', type='primary'):
        (ROOT / 'STOP.txt').write_text('EMERGENCY STOP REQUESTED\n', encoding='utf-8')
        st.error('STOP.txt written. Check Alpaca directly to confirm order cancellation and position closing.')
st.caption('STOP is global for whichever bot is active and is checked about every 15 seconds. If the bot or Internet is down, it cannot place closing orders.')

client = None
account = None
if key and secret:
    try:
        client = TradingClient(key, secret, paper=(mode == 'paper'))
        acct = client.get_account()
        positions = client.get_all_positions()
        a, b, c = st.columns(3)
        a.metric(f'{mode.title()} equity', f'${float(acct.equity):,.2f}')
        b.metric(f'{mode.title()} cash', f'${float(acct.cash):,.2f}')
        c.metric('Open positions', len(positions))
        if positions:
            st.subheader('Account positions')
            st.dataframe(pd.DataFrame([{
                'Symbol': p.symbol, 'Shares': float(p.qty),
                'Avg entry': float(p.avg_entry_price),
                'Unrealized P&L': float(p.unrealized_pl),
            } for p in positions]), use_container_width=True, hide_index=True)
    except Exception as exc:
        st.warning(f'Broker status unavailable: {exc}')
else:
    st.info(f'Add {mode.upper()} keys to .env to display this brokerage account.')

statepath = ROOT / f'state_{mode}.json'
if statepath.exists():
    try:
        state = json.loads(statepath.read_text(encoding='utf-8'))
        c1, c2, c3 = st.columns(3)
        c1.metric('Bot entries today', int(state.get('entries', 0)))
        c2.metric('Risk-locked today', 'YES' if state.get('risk_locked') else 'NO')
        c3.metric('Managed symbols', ', '.join(state.get('managed_symbols', [])) or 'None')
    except Exception:
        st.warning('Bot state could not be decoded; bot should fail closed.')

if mode == 'paper':
    st.header('Paper trading: live health, AI explanations, and results')
    st.caption('These are read-only views of the PAPER broker account. AI signals are not broker fills.')
    health_file = ROOT / 'health_paper.json'
    if health_file.exists():
        try:
            health = json.loads(health_file.read_text(encoding='utf-8'))
            age = (pd.Timestamp.now(tz='UTC') - pd.to_datetime(health['time'], utc=True)).total_seconds()
            latest = f"{health.get('status','UNKNOWN')} — {health.get('description','')}"
            if age > 120:
                st.warning(f'STALE heartbeat ({age:.0f} seconds old): {latest}. Check the bot process.')
            else:
                st.info(f'Bot health: {latest} (checked {age:.0f}s ago)')
        except (ValueError, OSError, KeyError, TypeError):
            st.warning('Bot health information could not be read.')
    else:
        st.info('No paper bot heartbeat yet. Start the bot on the Home screen.')

    decisions_tab, performance_tab, orders_tab = st.tabs(
        ['AI decision log', 'Performance & win rate', 'Broker orders / fills'])
    with decisions_tab:
        decisions = read_jsonl(ROOT / 'decisions_paper.jsonl', 1000)
        if decisions:
            entries = []
            for item in reversed(decisions):
                f = item.get('features') or {}
                entries.append({
                    'Time (UTC)': item.get('time'), 'AI action': item.get('action'),
                    'Symbol': item.get('symbol'), 'Why AI chose it': item.get('ai_reason'),
                    'Bot result': item.get('outcome'), 'Bot rule / next step': item.get('outcome_reason'),
                    'Price': f.get('price'), 'RSI': f.get('rsi14'),
                    'EMA9': f.get('ema9'), 'EMA21': f.get('ema21'),
                    '1h return %': f.get('return_1h_pct'),
                    'Broker order ID': item.get('order_id'),
                })
            table = pd.DataFrame(entries)
            st.dataframe(table, use_container_width=True, hide_index=True)
            st.download_button('Export AI decisions (CSV)', table.to_csv(index=False).encode(),
                               file_name='paper_ai_decisions.csv', mime='text/csv')
            st.caption('SUBMITTED_NOT_FILLED means Alpaca accepted a request, not that it executed. Check Broker orders.')
        else:
            st.info('No AI signals logged yet. Regular-market entries are evaluated after 9:50 AM ET. Check bot health above.')

    paper_orders = []
    order_error = None
    if client is not None:
        try:
            paper_orders = fetch_paper_orders(client)
        except Exception as exc:
            order_error = f'Could not retrieve paper orders: {type(exc).__name__} — {exc}'
    close_ids = close_order_ids(ROOT / 'activity_paper.jsonl')
    with performance_tab:
        if order_error:
            st.error(order_error)
        elif client is None:
            st.info('Connect your PAPER Alpaca keys to show real paper fills.')
        else:
            perf = trade_performance(paper_orders, close_ids)
            a, b, c, d = st.columns(4)
            a.metric('Estimated completed-trade P&L', f"${perf['realized_pnl']:+,.2f}")
            b.metric('Completed round trips', perf['closed_trades'])
            c.metric('Win rate', f"{perf['win_rate']:.1f}%" if perf['win_rate'] is not None else 'N/A')
            d.metric('Wins / Losses', f"{perf['wins']} / {perf['losses']}")
            st.caption('Based on up to 500 recent Alpaca PAPER orders from the last 60 days, when available. '
                       'Only recognized, completed bot entries/exits are counted. This is an ESTIMATE: '
                       'fees, dividends, partial executions and older orders may be omitted. '
                       'Win rate excludes flat trades and open positions. Confirm actual performance in Alpaca.')
            if perf['history_may_be_truncated']:
                st.warning('Order history reached the 500-order API limit. Results may be incomplete.')
            if perf['open_cycles'] or perf['unmatched_exits']:
                st.warning('Some bot positions or exit fills could not be fully matched. '
                           f"Open cycles: {perf['open_cycles']}; unmatched exits: {perf['unmatched_exits']}.")
            closed = perf['completed']
            if closed:
                tradedf = pd.DataFrame(closed)
                tradedf['Cumulative estimated P&L'] = tradedf['pnl'].cumsum()
                st.line_chart(tradedf.set_index('closed')['Cumulative estimated P&L'])
                st.dataframe(tradedf.iloc[::-1], use_container_width=True, hide_index=True)
            else:
                st.info('No matched, completed paper round trips yet. Submitted orders and open positions do not count as wins.')
            if account is not None:
                st.caption(f"Broker-reported paper account equity: ${float(account.equity):,.2f}. "
                           f"Previous closing equity: ${float(account.last_equity):,.2f}.")
    with orders_tab:
        if order_error:
            st.error(order_error)
        elif client is None:
            st.info('Connect your PAPER Alpaca keys to show broker order confirmations.')
        else:
            rows = order_rows(paper_orders, close_ids)
            if rows:
                st.dataframe(pd.DataFrame(rows[::-1]), use_container_width=True, hide_index=True)
            else:
                st.info('No matched bot-submitted orders yet. AI HOLDs and 24/7 local practice never create broker orders.')
            st.caption('An order is executed only if Alpaca reports a fill. Submitted/accepted orders are NOT fills.')

logpath = ROOT / f'activity_{mode}.jsonl'
if not logpath.exists():
    st.warning('No mode-specific activity yet. Start the bot and refresh.')
    st.stop()
records = []
for line in logpath.read_text(encoding='utf-8').splitlines()[-1000:]:
    try:
        records.append(json.loads(line))
    except json.JSONDecodeError:
        pass
if not records:
    st.stop()

df = pd.DataFrame(records)
df['time_et'] = pd.to_datetime(df['time'], utc=True).dt.tz_convert('America/New_York')
df = df.iloc[::-1].reset_index(drop=True)
st.button('Refresh')
st.subheader('Recent activity')
fields = [c for c in ['time_et', 'kind', 'message', 'symbol', 'qty', 'reference_price',
                      'stop_loss', 'take_profit', 'order_id', 'error'] if c in df.columns]
st.dataframe(df[fields].head(250), use_container_width=True, hide_index=True)
st.caption('This is a log, NOT an audited P&L report. Verify order fills, fees, cash, and risk in Alpaca.')
