@echo off
setlocal
cd /d "%~dp0"
title ChatGPT Day Trader - Safe GitHub Update
color 0B
echo.
echo === DAY TRADER UPDATE ===
echo Stop trading and verify your broker positions before installing.
timeout /t 3 /nobreak >nul
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" updater.py --install
) else (
    py -3 updater.py --install
)
if errorlevel 1 goto FAIL
echo.
echo Update check complete. Reopening the trading control center...
start "" "%~dp0START_DAYTRADER.bat"
exit /b 0
:FAIL
echo Update failed. Your existing app may still be usable.
echo Do NOT trade live until you've checked the error above.
pause
exit /b 1
