"""Deliberate, auditable separation of paper and real-money credentials."""
from __future__ import annotations
from dataclasses import dataclass
import os
from pathlib import Path
from typing import Mapping
from dotenv import dotenv_values

LIVE_ACK = 'I_UNDERSTAND_REAL_MONEY_CAN_BE_LOST'

@dataclass(frozen=True)
class Settings:
    mode: str
    key: str
    secret: str
    openai_key: str
    model: str
    max_order_dollars: float

    @property
    def live(self) -> bool:
        return self.mode == 'live'


def resolve_settings(values: Mapping[str, str | None], *, live: bool, confirmed: bool) -> Settings:
    """Fail closed. Running `--live` alone or adding live keys is not enough."""
    def get(name: str, default: str = '') -> str:
        return (values.get(name) or default).strip()

    mode = 'live' if live else 'paper'
    if live:
        if not confirmed or get('LIVE_TRADING_ENABLED') != LIVE_ACK:
            raise RuntimeError('LIVE DISABLED. Both --confirm-live and the explicit .env LIVE_TRADING_ENABLED acknowledgement are required.')
        key, secret = get('ALPACA_LIVE_KEY'), get('ALPACA_LIVE_SECRET')
        if key and (key == get('ALPACA_PAPER_KEY') or secret == get('ALPACA_PAPER_SECRET')):
            raise RuntimeError('Paper and live API credentials must be different.')
    else:
        key, secret = get('ALPACA_PAPER_KEY'), get('ALPACA_PAPER_SECRET')

    if not key or not secret or not get('OPENAI_API_KEY'):
        raise RuntimeError(f'Missing {mode} broker credentials or OPENAI_API_KEY in .env')

    try:
        dollars = float(get('MAX_ORDER_DOLLARS', '1500'))
    except ValueError as exc:
        raise RuntimeError('MAX_ORDER_DOLLARS must be a number') from exc
    if not (10 <= dollars <= 5000):
        raise RuntimeError('MAX_ORDER_DOLLARS must be between $10 and $5000')

    return Settings(mode=mode, key=key, secret=secret,
                    openai_key=get('OPENAI_API_KEY'),
                    model=get('OPENAI_MODEL', 'gpt-6.1-sol'),
                    max_order_dollars=dollars)


def load_settings(root: Path, *, live: bool, confirmed: bool) -> Settings:
    env_path = root / '.env'
    if not env_path.is_file():
        raise RuntimeError(f'Missing {env_path.name}; run SETUP_WINDOWS.bat then fill in .env')
    values = dict(dotenv_values(env_path))
    # Per-process live permission from the unified GUI. A saved key alone can
    # never activate real trades, and the command-line confirmation still applies.
    if os.environ.get('LIVE_TRADING_ENABLED') == LIVE_ACK:
        values['LIVE_TRADING_ENABLED'] = LIVE_ACK
    return resolve_settings(values, live=live, confirmed=confirmed)
