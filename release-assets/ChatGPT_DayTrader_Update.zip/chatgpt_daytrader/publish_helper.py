"""Optional *publisher* functionality for owner-authenticated GitHub CLI users.

The updater/downloader itself never needs a GitHub login.
Release ZIPs are validated before passing them to gh release create.
"""
from __future__ import annotations

import hashlib
import shutil
import subprocess
import tempfile
from pathlib import Path

from updater import (ASSET_NAME, Release, UpdateError, MAX_DOWNLOAD,
                     _stage_zip, current_version, normalized_repo, parse_version)


def inspect_release_zip(archive: Path) -> str:
    archive = Path(archive)
    if archive.name != ASSET_NAME:
        raise UpdateError(f'The release ZIP must be named exactly {ASSET_NAME}.')
    if not archive.is_file() or not (100 <= archive.stat().st_size <= MAX_DOWNLOAD):
        raise UpdateError('Choose a valid update ZIP smaller than 25 MB.')
    with tempfile.TemporaryDirectory(prefix='daytrader-inspect-') as tmp:
        import zipfile
        with zipfile.ZipFile(archive) as z:
            version_file = z.read('chatgpt_daytrader/version.json')
        import json
        version = str(json.loads(version_file).get('version', ''))
        parse_version(version)
        release = Release('owner/repo', 'v' + version, 'https://github.com/owner/repo',
                          hashlib.sha256(archive.read_bytes()).hexdigest(), archive.stat().st_size)
        _stage_zip(archive, Path(tmp), release)
    return version


def cli_path() -> str | None:
    return shutil.which('gh')


def publication_command(archive: Path, repo: str) -> list[str]:
    """Create a new tag/release; never overwrite any release or tag."""
    gh = cli_path()
    if not gh:
        raise UpdateError('GitHub CLI is not installed. Use the Install GitHub CLI link first.')
    repo = normalized_repo(repo)
    version = inspect_release_zip(archive)
    return [gh, 'release', 'create', 'v' + version, str(archive), '--repo', repo,
            '--title', f'ChatGPT Day Trader v{version}',
            '--notes', 'Verified application update. Keep your bot stopped during installation. Test paper trading before using live mode.',
            '--latest']


def publish(archive: Path, repo: str) -> str:
    args = publication_command(archive, repo)
    # No shell and no GitHub token in command line; GitHub CLI handles browser auth.
    process = subprocess.run(args, capture_output=True, text=True, timeout=120)
    if process.returncode != 0:
        raise UpdateError('GitHub rejected this release. Check GitHub CLI sign-in, repository permissions, and whether the version already exists.')
    return process.stdout.strip()
