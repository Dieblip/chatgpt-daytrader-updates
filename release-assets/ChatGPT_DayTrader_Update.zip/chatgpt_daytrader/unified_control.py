"""One-click desktop control center for the experimental day trader.

Runs locally. The default is paper. A selected LIVE run requires a typed,
per-launch confirmation, separate live credentials, and explicit CLI flags.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import tkinter as tk
import webbrowser
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, scrolledtext, simpledialog, ttk

from unified_setup import bot_argv, child_environment, load_form, save_form, validate_selected_mode
from updater import UpdateError, available_update, current_version, read_config, save_config

ROOT = Path(__file__).resolve().parent
ALPACA = 'https://app.alpaca.markets/'
OPENAI = 'https://platform.openai.com/api-keys'
BILLING = 'https://platform.openai.com/settings/organization/billing/overview'
GITHUB = 'https://github.com/new'
DASHBOARD = 'http://127.0.0.1:8501'

BG = '#0e1523'
PANEL = '#172238'
TEXT = '#edf4ff'
MUTED = '#a7b6cb'
BLUE = '#6da9ff'
GREEN = '#68d3a3'
RED = '#ff7b88'


class ConfirmLive(tk.Toplevel):
    def __init__(self, parent: tk.Tk):
        super().__init__(parent)
        self.confirmed = False
        self.title('CONFIRM REAL-MONEY TRADING')
        self.geometry('515x325')
        self.resizable(False, False)
        self.configure(bg=BG)
        self.transient(parent)
        self.grab_set()
        tk.Label(self, text='LIVE TRADING — REAL MONEY', bg=BG, fg=RED,
                 font=('Segoe UI', 16, 'bold')).pack(anchor='w', padx=22, pady=(20, 8))
        text = ('The AI can submit REAL trades repeatedly without asking again.\n'
                'Trading can lose your entire allocated balance. Stop orders\n'
                'can slip; offline bots cannot exit positions. This trading\n'
                'strategy has NOT been validated as profitable.\n\n'
                'To enable live trading for THIS RUN, type: START LIVE')
        tk.Label(self, text=text, justify='left', bg=BG, fg=TEXT,
                 font=('Segoe UI', 10)).pack(anchor='w', padx=22)
        self.phrase = tk.StringVar()
        field = ttk.Entry(self, textvariable=self.phrase, width=35)
        field.pack(anchor='w', padx=22, pady=12)
        field.focus_set()
        line = ttk.Frame(self)
        line.pack(fill='x', padx=22, pady=(4, 0))
        ttk.Button(line, text='CANCEL', command=self.destroy).pack(side='right', padx=(8, 0))
        ttk.Button(line, text='I ACCEPT — START LIVE', command=self.accept).pack(side='right')
        self.bind('<Return>', lambda _: self.accept())
        self.bind('<Escape>', lambda _: self.destroy())

    def accept(self):
        if self.phrase.get() != 'START LIVE':
            messagebox.showerror('Confirmation required', 'Type START LIVE exactly.', parent=self)
            return
        self.confirmed = True
        self.destroy()


class ControlCenter(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f'ChatGPT Day Trader v{current_version()} — One-Click Control Center')
        self.geometry('1010x775')
        self.minsize(850, 680)
        self.configure(bg=BG)
        self.mode = tk.StringVar(value='paper')  # NEVER persist a prior LIVE choice
        self.values = {k: tk.StringVar(value=v) for k, v in load_form(ROOT).items()}
        update = read_config(ROOT)
        self.repo = tk.StringVar(value=update['repo'])
        self.auto_updates = tk.BooleanVar(value=update['auto_install'])
        self.secret_visible = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='Ready. Enter keys on the API Keys tab, then click Run All.')
        self.run_status = tk.StringVar(value='STOPPED')
        self.account_status = tk.StringVar(value='Account: not checked')
        self.update_status = tk.StringVar(value='Configure a GitHub repository to check for releases.')
        self.bot_process: subprocess.Popen | None = None
        self.dashboard_process: subprocess.Popen | None = None
        self.active_mode = 'paper'
        self.log_mode = 'paper'
        self._busy = False
        self._secret_widgets: list[ttk.Entry] = []
        self._build_styles()
        self._build()
        self.after(800, self._refresh)
        self.protocol('WM_DELETE_WINDOW', self._close)

    def _build_styles(self):
        style = ttk.Style(self)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.', background=BG, foreground=TEXT, font=('Segoe UI', 10))
        style.configure('TFrame', background=BG)
        style.configure('Panel.TFrame', background=PANEL)
        style.configure('TLabel', background=BG, foreground=TEXT)
        style.configure('Panel.TLabel', background=PANEL, foreground=TEXT)
        style.configure('Muted.TLabel', background=BG, foreground=MUTED)
        style.configure('PanelMuted.TLabel', background=PANEL, foreground=MUTED)
        style.configure('TNotebook', background=BG, borderwidth=0)
        style.configure('TNotebook.Tab', padding=(21, 12), background=PANEL,
                        foreground=MUTED, font=('Segoe UI', 10, 'bold'))
        style.map('TNotebook.Tab', background=[('selected', '#294468')],
                  foreground=[('selected', '#ffffff')])
        style.configure('TEntry', padding=(8, 7), fieldbackground='#f1f6ff', foreground='#0d1625')
        style.configure('TButton', font=('Segoe UI', 10, 'bold'), padding=(13, 9),
                        background='#294468', foreground=TEXT)
        style.map('TButton', background=[('active', '#386296')])
        style.configure('Run.TButton', padding=(20, 13), background='#117d65',
                        foreground='white', font=('Segoe UI', 12, 'bold'))
        style.map('Run.TButton', background=[('active', '#0f9d7e')])
        style.configure('Danger.TButton', background='#923c4a', foreground='white')
        style.map('Danger.TButton', background=[('active', '#bd4454')])
        style.configure('TRadiobutton', background=PANEL, foreground=TEXT)
        style.map('TRadiobutton', background=[('active', PANEL)])
        style.configure('TCheckbutton', background=PANEL, foreground=TEXT)
        style.map('TCheckbutton', background=[('active', PANEL)])

    def _build(self):
        head = ttk.Frame(self, padding=(24, 18))
        head.pack(fill='x')
        ttk.Label(head, text='◈  CHATGPT DAY TRADER',
                  font=('Segoe UI', 21, 'bold')).pack(side='left')
        ttk.Label(head, text=f'v{current_version()}    •    WINDOWS CONTROL CENTER',
                  style='Muted.TLabel').pack(side='right')

        selection = ttk.Frame(self, style='Panel.TFrame', padding=(22, 14))
        selection.pack(fill='x', padx=22, pady=(0, 14))
        ttk.Label(selection, text='TRADING MODE', style='Panel.TLabel',
                  font=('Segoe UI', 10, 'bold')).pack(side='left', padx=(0, 18))
        ttk.Radiobutton(selection, text='PAPER (fake money)', variable=self.mode,
                        value='paper', command=self._mode_changed).pack(side='left', padx=(0, 20))
        ttk.Radiobutton(selection, text='LIVE (real money)', variable=self.mode,
                        value='live', command=self._mode_changed).pack(side='left')
        self.mode_badge = tk.Label(selection, text='PAPER MODE · SAFE TO TEST',
                                   bg='#164937', fg='#b8f5db',
                                   font=('Segoe UI', 10, 'bold'), padx=12, pady=5)
        self.mode_badge.pack(side='right')

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill='both', expand=True, padx=22)
        self.overview = ttk.Frame(self.tabs, padding=20)
        self.keys_tab = ttk.Frame(self.tabs, padding=20)
        self.safety_tab = ttk.Frame(self.tabs, padding=20)
        self.updates_tab = ttk.Frame(self.tabs, padding=20)
        self.activity_tab = ttk.Frame(self.tabs, padding=20)
        for tab, label in [(self.overview, 'Home / Run All'), (self.keys_tab, 'API Keys'),
                           (self.safety_tab, 'Risk Settings'), (self.updates_tab, 'GitHub Updates'),
                           (self.activity_tab, 'Activity & Help')]:
            self.tabs.add(tab, text=label)
        self.home_content = self._scrollable(self.overview)
        self.keys_content = self._scrollable(self.keys_tab)
        self.safety_content = self._scrollable(self.safety_tab)
        self.updates_content = self._scrollable(self.updates_tab)
        self.activity_content = self._scrollable(self.activity_tab)
        self._home()
        self._keys()
        self._safety()
        self._updates()
        self._activity()

        footer = ttk.Frame(self, padding=(24, 10))
        footer.pack(fill='x')
        ttk.Label(footer, textvariable=self.status, foreground=GREEN,
                  wraplength=950).pack(anchor='w')
        ttk.Label(footer, text='Experimental bot. Local tests do not establish profitability, broker connectivity, or guaranteed execution.',
                  style='Muted.TLabel').pack(anchor='w', pady=(3, 0))

    def _scrollable(self, tab):
        canvas = tk.Canvas(tab, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(tab, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        content = ttk.Frame(canvas, padding=(18, 15))
        win = canvas.create_window((0, 0), window=content, anchor='nw')
        content.bind('<Configure>', lambda _event: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda event: canvas.itemconfigure(win, width=event.width))
        canvas.bind('<MouseWheel>', lambda event: canvas.yview_scroll(-int(event.delta / 120), 'units'))
        content.bind('<MouseWheel>', lambda event: canvas.yview_scroll(-int(event.delta / 120), 'units'))
        return content

    def _heading(self, parent, title, subtitle):
        ttk.Label(parent, text=title, font=('Segoe UI', 18, 'bold')).pack(anchor='w', pady=(2, 4))
        ttk.Label(parent, text=subtitle, style='Muted.TLabel',
                  wraplength=890).pack(anchor='w', pady=(0, 18))

    def _panel(self, parent, pad=18):
        frame = ttk.Frame(parent, style='Panel.TFrame', padding=pad)
        frame.pack(fill='x', pady=(0, 12))
        return frame

    def _link(self, parent, label, url):
        button = ttk.Button(parent, text=label, command=lambda: webbrowser.open(url))
        button.pack(side='left', padx=(0, 9), pady=(6, 0))

    def _home(self):
        self._heading(self.home_content, 'Everything in one place',
                      'Choose Paper or Live above. Enter your keys once, then launch the bot and dashboard together.')
        panel = self._panel(self.home_content, 21)
        ttk.Label(panel, text='AUTOMATED TRADING', style='Panel.TLabel',
                  font=('Segoe UI', 13, 'bold')).pack(anchor='w')
        ttk.Label(panel, text='Runs selected trading mode, monitors the market, and opens the account dashboard.',
                  style='PanelMuted.TLabel').pack(anchor='w', pady=(5, 16))
        buttons = ttk.Frame(panel, style='Panel.TFrame')
        buttons.pack(fill='x')
        ttk.Button(buttons, text='▶  RUN ALL — START BOT + DASHBOARD', style='Run.TButton',
                   command=lambda: self._start(dry_run=False)).pack(side='left', padx=(0, 10))
        ttk.Button(buttons, text='Test first (NO orders)',
                   command=lambda: self._start(dry_run=True)).pack(side='left')
        btn2 = ttk.Frame(panel, style='Panel.TFrame')
        btn2.pack(fill='x', pady=(16, 0))
        ttk.Button(btn2, text='Open Dashboard', command=self._open_dashboard).pack(side='left', padx=(0, 9))
        ttk.Button(btn2, text='Check API Connections', command=self._check_connections).pack(side='left', padx=(0, 9))
        ttk.Button(btn2, text='Enter / Edit Keys', command=lambda: self.tabs.select(self.keys_tab)).pack(side='left')

        practice = self._panel(self.home_content, 21)
        ttk.Label(practice, text='24/7 PRACTICE — EVEN WHEN MARKETS ARE CLOSED',
                  style='Panel.TLabel', font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        ttk.Label(practice, text='LOCAL simulated fills only. These trades do NOT appear in your Alpaca account.',
                  style='PanelMuted.TLabel', wraplength=800).pack(anchor='w', pady=(5, 13))
        practice_buttons = ttk.Frame(practice, style='Panel.TFrame')
        practice_buttons.pack(fill='x')
        ttk.Button(practice_buttons, text='▶  INSTANT SAMPLE TRADES (NO KEYS)',
                   style='Run.TButton', command=lambda: self._start_practice('demo')).pack(side='left', padx=(0, 10))
        ttk.Button(practice_buttons, text='AI HISTORICAL REPLAY (PAPER KEYS)',
                   command=lambda: self._start_practice('replay')).pack(side='left')
        ttk.Label(practice, text='Sample trades are scripted, not AI decisions. Replay uses past stock prices + real AI calls; HOLD may mean no trades and API use may cost money.',
                  style='PanelMuted.TLabel', wraplength=850).pack(anchor='w', pady=(12, 0))

        panel2 = self._panel(self.home_content)
        ttk.Label(panel2, text='BOT STATUS', style='PanelMuted.TLabel',
                  font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        ttk.Label(panel2, textvariable=self.run_status, style='Panel.TLabel',
                  font=('Segoe UI', 15, 'bold')).pack(anchor='w', pady=(4, 5))
        ttk.Label(panel2, textvariable=self.account_status, style='PanelMuted.TLabel').pack(anchor='w')
        controls = ttk.Frame(panel2, style='Panel.TFrame')
        controls.pack(fill='x', pady=(13, 0))
        ttk.Button(controls, text='🚨 EMERGENCY STOP / EXIT REQUEST', style='Danger.TButton',
                   command=self._emergency_stop).pack(side='left', padx=(0, 9))
        ttk.Button(controls, text='Stop Local Bot Process', command=self._stop_process).pack(side='left', padx=(0, 9))
        ttk.Button(controls, text='Clear Stop After Verification', command=self._clear_stop).pack(side='left')
        ttk.Label(panel2, text='Emergency stop only works while the bot can reach Alpaca. Verify all orders and positions in Alpaca directly.',
                  style='PanelMuted.TLabel', wraplength=890).pack(anchor='w', pady=(12, 0))

    def _key_entry(self, parent, label, key, secret=True):
        ttk.Label(parent, text=label, style='Panel.TLabel').pack(anchor='w', pady=(8, 3))
        row = ttk.Frame(parent, style='Panel.TFrame')
        row.pack(fill='x')
        field = ttk.Entry(row, textvariable=self.values[key], show='•' if secret else '')
        field.pack(side='left', fill='x', expand=True)
        if secret:
            self._secret_widgets.append(field)

    def _keys(self):
        self._heading(self.keys_content, 'API Keys — save once',
                      'All keys remain on your PC in the .env configuration file. Do not share that file or screenshots showing keys.')
        group = self._panel(self.keys_content, 15)
        ttk.Label(group, text='Alpaca PAPER (simulated money)', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        self._key_entry(group, 'Paper API Key ID', 'ALPACA_PAPER_KEY')
        self._key_entry(group, 'Paper Secret Key', 'ALPACA_PAPER_SECRET')
        group2 = self._panel(self.keys_content, 15)
        ttk.Label(group2, text='Alpaca LIVE (real money; optional)', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        self._key_entry(group2, 'Live API Key ID', 'ALPACA_LIVE_KEY')
        self._key_entry(group2, 'Live Secret Key', 'ALPACA_LIVE_SECRET')
        group3 = self._panel(self.keys_content, 15)
        ttk.Label(group3, text='OpenAI API', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        self._key_entry(group3, 'OpenAI API Key', 'OPENAI_API_KEY')
        actions = ttk.Frame(self.keys_content)
        actions.pack(fill='x', pady=(1, 3))
        ttk.Checkbutton(actions, text='Show API keys', variable=self.secret_visible,
                        command=self._show_keys).pack(side='left', padx=(0, 14))
        ttk.Button(actions, text='Save All Keys', command=self._save_keys).pack(side='left', padx=(0, 9))
        ttk.Button(actions, text='Test Connections (no orders)',
                   command=self._check_connections).pack(side='left')
        links = ttk.Frame(self.keys_content)
        links.pack(fill='x')
        self._link(links, 'Get Alpaca Keys', ALPACA)
        self._link(links, 'Get OpenAI Key', OPENAI)
        self._link(links, 'OpenAI API Billing', BILLING)

    def _safety(self):
        self._heading(self.safety_content, 'Trade settings and guardrails',
                      'Edit the order dollar limit and model. Other safety limits are fixed in code, not decided by the AI.')
        p = self._panel(self.safety_content)
        ttk.Label(p, text='OpenAI model ID', style='Panel.TLabel').pack(anchor='w')
        ttk.Entry(p, textvariable=self.values['OPENAI_MODEL'], width=36).pack(anchor='w', pady=(5, 15))
        ttk.Label(p, text='Maximum dollars per order ($10–$5,000)', style='Panel.TLabel').pack(anchor='w')
        ttk.Entry(p, textvariable=self.values['MAX_ORDER_DOLLARS'], width=20).pack(anchor='w', pady=(5, 15))
        ttk.Button(p, text='Save Settings', command=self._save_keys).pack(anchor='w')
        p2 = self._panel(self.safety_content)
        ttk.Label(p2, text='AUTOMATIC RISK LIMITS', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w', pady=(0, 9))
        for item in ['At most 5% of account equity per entry',
                     'At most 3 new entries per trading day',
                     'Daily equity drawdown guard: 1% (not a guaranteed loss cap)',
                     'Broker-side protective bracket orders when supported',
                     'Attempts end-of-day flattening before market close',
                     'Only preapproved liquid ETFs; never shorts or options']:
            ttk.Label(p2, text='•  ' + item, style='PanelMuted.TLabel').pack(anchor='w', pady=3)
        ttk.Label(self.safety_content, text='LIVE is selected at the top, never automatically. Every LIVE start needs the typed START LIVE phrase. '
                                    'The model and order limit apply to both modes.',
                  foreground=RED, wraplength=880).pack(anchor='w', pady=(6, 0))

    def _updates(self):
        self._heading(self.updates_content, 'Automatic GitHub Updates',
                      'Updates use published GitHub Releases, not random branch downloads. Your .env keys and activity are not included in releases.')
        p = self._panel(self.updates_content)
        ttk.Label(p, text='GitHub repository (OWNER/REPO)', style='Panel.TLabel').pack(anchor='w')
        ttk.Entry(p, textvariable=self.repo, width=68).pack(fill='x', pady=(8, 10))
        ttk.Checkbutton(p, text='Auto-install published releases before PAPER trading (restart required)',
                        variable=self.auto_updates).pack(anchor='w', pady=(0, 12))
        row = ttk.Frame(p, style='Panel.TFrame')
        row.pack(fill='x')
        ttk.Button(row, text='Save GitHub Settings', command=self._save_github).pack(side='left', padx=(0, 9))
        ttk.Button(row, text='Check for Updates', command=self._check_updates).pack(side='left', padx=(0, 9))
        ttk.Button(row, text='Install Update', command=self._install_update).pack(side='left')
        ttk.Label(p, textvariable=self.update_status, style='PanelMuted.TLabel',
                  wraplength=850).pack(anchor='w', pady=(13, 0))
        p2 = self._panel(self.updates_content)
        ttk.Label(p2, text='How publishing works', style='Panel.TLabel',
                  font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        for step in ['1. Create a public GitHub repo (only once).',
                     '2. Enter its OWNER/REPO name above and save.',
                     '3. For each update, upload the signed-by-GitHub SHA-256-digested release ZIP as a new Release asset.',
                     '4. The bot checks for updates on startup; never update during active trading.']:
            ttk.Label(p2, text=step, style='PanelMuted.TLabel',
                      wraplength=850).pack(anchor='w', pady=5)
        links = ttk.Frame(self.updates_content)
        links.pack(fill='x')
        self._link(links, 'Create GitHub Repository', GITHUB)
        ttk.Button(links, text='Full Publishing Guide',
                   command=lambda: webbrowser.open((ROOT / 'PUBLISH_TO_GITHUB.md').as_uri())).pack(side='left', pady=6)

    def _activity(self):
        self._heading(self.activity_content, 'Activity and troubleshooting',
                      'Recent bot output appears here. Trades and fills must always be verified with the broker.')
        row = ttk.Frame(self.activity_content)
        row.pack(fill='x', pady=(0, 10))
        ttk.Button(row, text='Refresh Activity', command=self._load_activity).pack(side='left', padx=(0, 9))
        ttk.Button(row, text='View Practice Log', command=self._view_practice_log).pack(side='left', padx=(0, 9))
        ttk.Button(row, text='Open Alpaca Account', command=lambda: webbrowser.open(ALPACA)).pack(side='left', padx=(0, 9))
        ttk.Button(row, text='Read Setup Guide',
                   command=lambda: webbrowser.open((ROOT / 'READ_ME_FIRST.html').as_uri())).pack(side='left')
        self.console = scrolledtext.ScrolledText(self.activity_content, height=19, bg='#0b1220',
                                                fg='#e0edfd', insertbackground='white',
                                                font=('Consolas', 10), wrap='word', relief='flat')
        self.console.pack(fill='both', expand=True)
        self.console.insert('end', 'Recent activity will appear here after you start the bot.\n')
        self.console.configure(state='disabled')
        ttk.Label(self.activity_content,
                  text='Closing this window does NOT necessarily cancel pending broker orders. Use emergency stop and verify in Alpaca.',
                  foreground=RED, wraplength=880).pack(anchor='w', pady=(11, 0))

    def _view_practice_log(self):
        self.log_mode = 'practice'
        self._load_activity()

    def _mode_changed(self):
        live = self.mode.get() == 'live'
        self.mode_badge.configure(text=('LIVE · REAL MONEY AT RISK' if live else 'PAPER MODE · SAFE TO TEST'),
                                  bg=('#723541' if live else '#164937'),
                                  fg=('#fff4f4' if live else '#b8f5db'))
        self.status.set('LIVE selected. Real orders require separate live keys and typed confirmation.' if live
                        else 'PAPER selected. All orders are simulated.')
        self.account_status.set('Account: not checked')
        self.log_mode = self.mode.get()
        self._load_activity()

    def _show_keys(self):
        for field in self._secret_widgets:
            field.configure(show='' if self.secret_visible.get() else '•')

    def _form_values(self):
        return {key: value.get() for key, value in self.values.items()}

    def _save_keys(self, quiet=False):
        try:
            save_form(ROOT, self._form_values())
        except (ValueError, OSError) as exc:
            messagebox.showerror('Could not save settings', str(exc))
            return False
        self.status.set('Saved all keys and settings to .env locally. Live activation remains OFF by default.')
        if not quiet:
            messagebox.showinfo('Saved', 'Your API keys are saved locally.\n\nNext: Check API Connections or Run All.')
        return True

    def _validate_start(self):
        try:
            validate_selected_mode(self._form_values(), self.mode.get())
        except ValueError as exc:
            messagebox.showerror('API keys needed', f'{exc}\n\nOpen the API Keys tab to correct the fields.')
            self.tabs.select(self.keys_tab)
            return False
        return self._save_keys(quiet=True)

    def _spawn(self, argv, log_file, env=None):
        flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        output = open(ROOT / log_file, 'a', encoding='utf-8')
        try:
            process = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output,
                                       stderr=subprocess.STDOUT, creationflags=flags)
        finally:
            output.close()
        return process

    def _start_practice(self, kind: str):
        """Isolated local simulator; never starts bot.py or uses TradingClient."""
        self.mode.set('paper')  # Practice must never look or behave like LIVE.
        self._mode_changed()
        if (self.bot_process and self.bot_process.poll() is None) or (ROOT / '.bot.lock').exists():
            messagebox.showwarning('Another run is active',
                'Stop and verify any active broker bot before starting practice mode.')
            return
        if (ROOT / '.practice.lock').exists():
            messagebox.showwarning('Practice already running',
                'A practice test may be active. Check Activity before restarting it.')
            return
        if kind == 'replay':
            try:
                validate_selected_mode(self._form_values(), 'paper')
            except ValueError as exc:
                messagebox.showerror('Paper keys needed for replay',
                    str(exc) + '\n\nUse Instant Sample Trades instead for testing without keys.')
                self.tabs.select(self.keys_tab)
                return
            if not self._save_keys(quiet=True):
                return
            if not messagebox.askokcancel('AI historical replay',
                    'This will read PAST stock data using Alpaca PAPER keys and call the OpenAI API. '
                    'OpenAI API calls can cost money. All fills stay LOCAL; no broker orders are placed.\n\nContinue?'):
                return
        try:
            (ROOT / 'PRACTICE_STOP.txt').unlink(missing_ok=True)
            self.bot_process = self._spawn([sys.executable, 'practice.py',
                                           '--demo' if kind == 'demo' else '--replay'],
                                           'bot_console_practice.log', child_environment('paper'))
        except OSError as exc:
            messagebox.showerror('Practice launch failed', str(exc))
            return
        self.active_mode = 'practice'
        self.log_mode = 'practice'
        self.run_status.set('PRACTICE RUNNING — LOCAL SIMULATION ONLY')
        self.status.set('Practice started. No Alpaca orders will be sent. Watch Activity & Help or the PRACTICE dashboard tab.')
        self._open_dashboard('practice')
        self._load_activity()

    def _start(self, dry_run):
        if self.bot_process and self.bot_process.poll() is None:
            messagebox.showwarning('Already running', 'A bot is already running from this window.')
            return
        if (ROOT / '.practice.lock').exists():
            messagebox.showwarning('Practice is active', 'Stop the practice session before starting broker paper/live trading.')
            return
        if (ROOT / '.bot.lock').exists():
            messagebox.showwarning('Possible active bot', 'The bot lock file exists. Check whether a bot is running.\n\n'
                                   'Do not delete the lock without investigating active positions.')
            return
        if (ROOT / 'STOP.txt').exists():
            messagebox.showwarning('Emergency stop active', 'An emergency stop request is still active.\n\n'
                                   'Verify broker orders and positions before clearing it on Home.')
            return
        if not self._validate_start():
            return
        if self.mode.get() == 'paper':
            try:
                update = read_config(ROOT)
            except UpdateError as exc:
                self.status.set(f'GitHub config invalid: {exc}. Correct settings on Updates tab.')
                self.tabs.select(self.updates_tab)
                return
            if update['repo'] and update['auto_install']:
                if self._busy:
                    return
                self._busy = True
                self.status.set('Checking trusted GitHub Releases before paper trading...')
                threading.Thread(target=self._paper_update_worker,
                                 args=(update['repo'], dry_run), daemon=True).start()
                return
        self._start_ready(dry_run)

    def _paper_update_worker(self, repo, dry_run):
        try:
            release = available_update(ROOT, repo)
            response = ('update', release.version) if release else ('current', '')
        except (UpdateError, OSError) as exc:
            response = ('error', str(exc))
        try:
            self.after(0, lambda: self._paper_update_done(response, dry_run))
        except RuntimeError:
            pass

    def _paper_update_done(self, response, dry_run):
        self._busy = False
        state, detail = response
        if state == 'update':
            self.update_status.set(f'New release {detail} found; installing before PAPER mode.')
            self.status.set('Updating now. Reopen RUN_ALL.bat afterward and click Run All.')
            self._install_update(automatic=True)
            return
        if state == 'error':
            self.update_status.set(f'Could not check for updates: {detail}')
            if not messagebox.askyesno('GitHub check unavailable',
                    f'Update check failed: {detail}\n\n'
                    'Start the existing PAPER bot without an update?'):
                return
        self._start_ready(dry_run)

    def _start_ready(self, dry_run):
        mode = self.mode.get()
        if (ROOT / '.bot.lock').exists() or (ROOT / 'STOP.txt').exists():
            messagebox.showwarning('Trading blocked', 'A bot lock or stop request is now present. Investigate first.')
            return
        if mode == 'live':
            if not dry_run:
                modal = ConfirmLive(self)
                self.wait_window(modal)
                if not modal.confirmed:
                    self.status.set('Live start canceled. No bot launched.')
                    return
            else:
                if not messagebox.askokcancel('LIVE account data test',
                                              'This is a DRY RUN against your LIVE account: it submits NO orders. Continue?'):
                    return
        else:
            if not dry_run and not messagebox.askokcancel('Start automatic PAPER trading?',
                    'This will submit simulated orders without asking you for approval each time.\n\nContinue?'):
                return
        argv = bot_argv(sys.executable, mode, dry_run)
        try:
            self.bot_process = self._spawn(argv, f'bot_console_{mode}.log', child_environment(mode))
        except OSError as exc:
            messagebox.showerror('Launch failed', str(exc))
            return
        self.active_mode = mode
        self.log_mode = mode
        self.run_status.set(f'STARTED {mode.upper()} {"DRY RUN" if dry_run else "AUTO TRADING"}  ·  PID {self.bot_process.pid}')
        self.status.set(f'{mode.upper()} bot started. Trading will occur only during eligible market hours.')
        self._open_dashboard(mode)
        self._load_activity()

    def _open_dashboard(self, account=None):
        if self.dashboard_process is None or self.dashboard_process.poll() is not None:
            try:
                self.dashboard_process = self._spawn([
                    sys.executable, '-m', 'streamlit', 'run', 'dashboard.py',
                    '--server.address', '127.0.0.1', '--server.port', '8501',
                    '--server.headless', 'true', '--browser.gatherUsageStats', 'false'],
                    'dashboard_console.log')
            except OSError as exc:
                messagebox.showwarning('Dashboard', f'Could not start dashboard: {exc}')
                return
        selected = account or (self.log_mode if self.log_mode in ('paper', 'live', 'practice') else 'paper')
        self.after(1700, lambda: webbrowser.open(DASHBOARD + '?account=' + selected))

    def _emergency_stop(self):
        if self.active_mode == 'practice' and self.bot_process and self.bot_process.poll() is None:
            (ROOT / 'PRACTICE_STOP.txt').write_text('STOP PRACTICE\n', encoding='utf-8')
            self.status.set('Practice stop requested. No broker trades were submitted.')
            messagebox.showinfo('Practice stop', 'Practice is stopping. No Alpaca orders exist from practice mode.')
            return
        if not messagebox.askyesno('EMERGENCY STOP — check your broker',
                 'Request a GLOBAL stop of all new entries and attempts to cancel/close bot-managed trades?\n\n'
                 'This is NOT proof that positions are closed. The bot must be online and connected.\n'
                 'Check orders and holdings directly in Alpaca immediately.'):
            return
        (ROOT / 'STOP.txt').write_text('EMERGENCY STOP REQUESTED\n', encoding='utf-8')
        self.status.set('EMERGENCY STOP REQUESTED. Verify orders and holdings in Alpaca.')
        messagebox.showwarning('Stop requested', 'STOP.txt created. The running bot checks about every 15 seconds.\n\n'
                               'VERIFY ACTUAL ORDERS AND POSITIONS IN ALPACA. The bot cannot exit when offline.')

    def _stop_process(self):
        p = self.bot_process
        if self.active_mode == 'practice' and p and p.poll() is None:
            (ROOT / 'PRACTICE_STOP.txt').write_text('STOP PRACTICE\n', encoding='utf-8')
            messagebox.showinfo('Stopping practice', 'Practice stop requested. No broker orders exist from this simulator.')
            return
        if not p or p.poll() is not None:
            messagebox.showinfo('No managed process', 'This GUI has no active local bot process to stop.')
            return
        if not (ROOT / 'STOP.txt').exists():
            messagebox.showwarning('Use emergency stop first',
                'Emergency stop must be requested first. The bot may have open orders and positions.\n\n'
                'Verify in Alpaca before stopping the monitoring process.')
            return
        if not messagebox.askyesno('Stop local monitoring process?',
                'Have you independently verified in Alpaca that orders and positions are handled?\n\n'
                'Stopping the process cannot cancel orders or close positions afterward.'):
            return
        try:
            p.terminate()
            p.wait(timeout=7)
            lock = ROOT / '.bot.lock'
            if lock.exists() and lock.read_text(encoding='utf-8').split()[0] == str(p.pid):
                lock.unlink()  # only if THIS child's PID is definitively exited
        except (OSError, ValueError, IndexError, subprocess.TimeoutExpired) as exc:
            messagebox.showwarning('Verify process and lock',
                                   f'Could not confirm the process stopped cleanly: {type(exc).__name__}. '
                                   'Inspect Task Manager and Alpaca before restarting.')
            return
        self.bot_process = None
        self.status.set('Local bot stopped. STOP.txt remains active until broker verification.')

    def _clear_stop(self):
        if (ROOT / '.bot.lock').exists() or (ROOT / '.practice.lock').exists() or (self.bot_process and self.bot_process.poll() is None):
            messagebox.showwarning('Still running', 'The bot appears to be running. Stop it and confirm broker status first.')
            return
        if not (ROOT / 'STOP.txt').exists():
            messagebox.showinfo('No stop request', 'There is no STOP.txt to clear.')
            return
        prompt = simpledialog.askstring('Verify broker first',
                        'After checking current orders and positions on Alpaca, type VERIFIED BROKER below:')
        if prompt != 'VERIFIED BROKER':
            return
        (ROOT / 'STOP.txt').unlink(missing_ok=True)
        self.status.set('Stop request cleared after user confirmation. Paper remains the default mode.')

    def _check_connections(self):
        if self._busy or not self._validate_start():
            return
        self._busy = True
        mode = self.mode.get()
        self.account_status.set(f'Checking {mode.upper()} credentials... no orders will be placed.')
        values = self._form_values()
        threading.Thread(target=self._connection_worker, args=(mode, values), daemon=True).start()

    def _connection_worker(self, mode, values):
        result = []
        try:
            from alpaca.trading.client import TradingClient
            key = values[f'ALPACA_{mode.upper()}_KEY'].strip()
            sec = values[f'ALPACA_{mode.upper()}_SECRET'].strip()
            account = TradingClient(key, sec, paper=(mode == 'paper')).get_account()
            result.append(f'{mode.upper()} Alpaca connected. Equity ${float(account.equity):,.2f}.')
        except Exception as exc:
            result.append(f'Alpaca connection failed: {type(exc).__name__}. Check the keys, account, and network.')
        try:
            from openai import OpenAI
            client = OpenAI(api_key=values['OPENAI_API_KEY'].strip(), timeout=15, max_retries=0)
            client.models.list()
            result.append('OpenAI API connected (model access not yet verified).')
        except Exception as exc:
            result.append(f'OpenAI connection failed: {type(exc).__name__}. Check your key and API billing.')
        try:
            self.after(0, lambda: self._connection_done(result))
        except RuntimeError:
            pass

    def _connection_done(self, result):
        self._busy = False
        self.account_status.set('  |  '.join(result))
        messagebox.showinfo('Connection check — NO orders', '\n\n'.join(result))

    def _save_github(self, quiet=False):
        try:
            save_config(ROOT, self.repo.get(), self.auto_updates.get())
        except (UpdateError, OSError) as exc:
            messagebox.showerror('GitHub settings', str(exc))
            return False
        self.update_status.set('GitHub settings saved. Public GitHub Releases required for updates.')
        if not quiet:
            messagebox.showinfo('Saved', 'GitHub repository saved. Publish a Release ZIP as shown in the guide.')
        return True

    def _check_updates(self):
        if self._busy or not self._save_github(quiet=True):
            return
        if not self.repo.get().strip():
            messagebox.showinfo('Repository required', 'Enter your public GitHub repo as OWNER/REPO.')
            return
        self._busy = True
        self.update_status.set('Checking GitHub releases...')
        threading.Thread(target=self._update_worker, args=(self.repo.get().strip(),), daemon=True).start()

    def _update_worker(self, repo):
        try:
            release = available_update(ROOT, repo)
            result = f'New version {release.version} available. Click Install Update.' if release else 'No newer published release found.'
        except (UpdateError, OSError) as exc:
            result = f'Update check failed: {exc}'
        try:
            self.after(0, lambda: self._update_done(result))
        except RuntimeError:
            pass

    def _update_done(self, result):
        self._busy = False
        self.update_status.set(result)
        messagebox.showinfo('GitHub update check', result)

    def _install_update(self, automatic=False):
        if not self._save_github(quiet=True) or not self.repo.get().strip():
            messagebox.showwarning('Repo required', 'Enter OWNER/REPO first.')
            return
        if (ROOT / '.bot.lock').exists() or (ROOT / '.practice.lock').exists() or (self.bot_process and self.bot_process.poll() is None):
            messagebox.showwarning('Trading running', 'Stop trading and verify Alpaca before updating.')
            return
        if not automatic and not messagebox.askyesno('Install published release?',
                'This closes the control window and starts the verified GitHub Release updater.\n'
                'Your keys, settings and logs are preserved.\n\nContinue?'):
            return
        if self.dashboard_process and self.dashboard_process.poll() is None:
            self.dashboard_process.terminate()
        try:
            if os.name != 'nt':
                raise OSError('GitHub updater launcher is for Windows.')
            os.startfile(str(ROOT / 'UPDATE_NOW.bat'))  # type: ignore[attr-defined]
            self.destroy()
        except OSError as exc:
            messagebox.showerror('Updater', str(exc))

    def _load_activity(self):
        if not hasattr(self, 'console'):
            return
        mode = self.log_mode
        log = ROOT / f'bot_console_{mode}.log'
        audit = ROOT / f'activity_{mode}.jsonl'
        lines = []
        if log.exists():
            lines.extend(log.read_text(encoding='utf-8', errors='replace').splitlines()[-80:])
        if not lines and audit.exists():
            for raw in audit.read_text(encoding='utf-8', errors='replace').splitlines()[-70:]:
                try:
                    data = json.loads(raw)
                    lines.append(f"{data.get('time', '')}  {data.get('kind', '')}: {data.get('message', '')}")
                except json.JSONDecodeError:
                    continue
        if not lines:
            lines = ['No activity yet. Normal broker trades need market hours; 24/7 practice can run anytime.']
        self.console.configure(state='normal')
        self.console.delete('1.0', 'end')
        self.console.insert('end', '\n'.join(lines[-80:]))
        self.console.see('end')
        self.console.configure(state='disabled')

    def _refresh(self):
        if not self.winfo_exists():
            return
        if self.bot_process and self.bot_process.poll() is not None:
            code = self.bot_process.returncode
            self.bot_process = None
            if self.active_mode == 'practice':
                self.run_status.set(f'PRACTICE FINISHED (exit code {code})')
                self.status.set('Practice completed. Open the Practice tab in the dashboard and check activity for results.')
            else:
                self.run_status.set(f'STOPPED (last process exit code {code})')
                self.status.set('Bot process has exited. Check Activity & Help for errors.')
            self._load_activity()
        elif self.bot_process:
            self.run_status.set(f'RUNNING · {self.active_mode.upper()} · PID {self.bot_process.pid}')
        elif (ROOT / '.bot.lock').exists() or (ROOT / '.practice.lock').exists():
            self.run_status.set('POSSIBLE BOT RUNNING (external process / lock detected)')
        else:
            self.run_status.set('STOPPED  ·  No trading process detected')
        self.after(2500, self._refresh)

    def _close(self):
        if self.bot_process and self.bot_process.poll() is None:
            if not messagebox.askyesno('Bot is still running',
                    'The bot/test may CONTINUE running if you close this window.\n\n'
                    'Do you want to close the control panel anyway?\n'
                    'You can reopen RUN_ALL.bat to monitor it later.'):
                return
        self.destroy()


if __name__ == '__main__':
    ControlCenter().mainloop()
