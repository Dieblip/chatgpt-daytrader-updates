> **v5:** Use `RUN_ALL.bat` and `unified_control.py` for the supported one-window GUI. The archived commands below are for advanced/manual operation.

# ChatGPT Autonomous Day Trader — Windows (paper + opt-in real-money mode)

**Version 2: autonomous execution is implemented. PAPER is the default. LIVE is a deliberate opt-in.**

This bot calls the OpenAI API (`gpt-6.1-sol` by default) for BUY/SELL/HOLD decisions about liquid US ETFs. The Python program — **not the ChatGPT chat window** — independently applies hard risk filters and sends orders to Alpaca. Once started, no per-trade approval is required.

**THIS IS EXPERIMENTAL AND NOT A PROFITABLE/VALIDATED STRATEGY.** Actual trades can lose money, even with limits. The bot is not guaranteed to exit near the close or at a stop price. The OpenAI API cannot guarantee predictive accuracy. Keep any money needed for living expenses out of automated trading. Do not run without first auditing, backtesting, paper-testing and understanding the risks. You are responsible for monitoring it.

## Requirements

- Windows 10/11, Python 3.11+ (check **Add Python to PATH**), Internet connection, computer running and awake for the entire US trading day.
- An [Alpaca](https://app.alpaca.markets/) brokerage account with paper-trading access; for **live mode**, a separate live trading API key pair and funded live account.
- An [OpenAI API key](https://platform.openai.com/api-keys) with API billing enabled. ChatGPT Plus/Pro subscriptions do **not** include OpenAI API charges.
- A **dedicated** Alpaca account for this bot, without manually opened holdings or outside orders. It must not manage positions belonging to other strategies.

## Quick setup (PAPER only at first)

1. Unzip the folder. Double-click **SETUP_WINDOWS.bat**. This installs packages and creates `.env` if it is missing.
2. Edit `.env` in Notepad; set `ALPACA_PAPER_KEY`, `ALPACA_PAPER_SECRET`, and `OPENAI_API_KEY`.
3. Double-click **DRY_RUN.bat**. This calls the AI but does **not** send any orders, including risk/exit orders. Check `activity_paper.jsonl`.
4. Stop the dry run with **Ctrl+C**. Run **RUN_BOT.bat** for *automatic simulated paper entries and exits*.
5. Open **DASHBOARD.bat** for the local Streamlit monitor (`http://127.0.0.1:8501`). It shows logs, live or paper account balances, and an emergency-stop request. Trading remains a separate command-line process.
6. Paper-test across many sessions, including market-open delays, early closes, broker outages, reboots and reconnection. Only then consider live mode. Neither one week nor a profitable paper streak proves an edge.

## LIVE: enabling fully autonomous real-money trading

**WARNING: Once LIVE starts, real-money orders can execute with no additional approval.**

1. Confirm Alpaca permits the trading behavior you intend for your specific account. FINRA's intraday margin framework has a brokerage transition period; old PDT-related requirements may still apply at some firms. Cash settlement constraints also matter.
2. Add your **different** real-money credentials to `.env`:

   `ALPACA_LIVE_KEY=...`  
   `ALPACA_LIVE_SECRET=...`

3. Change the `.env` line to this **exact** acknowledgement:

   `LIVE_TRADING_ENABLED=I_UNDERSTAND_REAL_MONEY_CAN_BE_LOST`

4. Double-click **RUN_LIVE.bat**. It asks you to type `I ACCEPT REAL MONEY LOSSES` before it invokes `python bot.py --live --confirm-live`. Both the explicit command flags **and** the exact `.env` acknowledgement are required. Entering live keys alone never enables live orders.
5. If you want a one-time non-trading validation on the real account, run:

   `.venv\Scripts\python.exe bot.py --live --confirm-live --once --dry-run`

   This still requires explicit live mode acknowledgment, but **does not place orders**.

**Never** share `.env`, API keys or account IDs. Do not put `.env` into a public GitHub repository. The sample zip has **no** real credentials. `RUN_BOT.bat` always uses paper only. The bot won't run when your PC is off/asleep; this package does not install a cloud server or unattended Windows startup service.

## Current strategy and hard risk rules

| Feature | Default / behavior |
|---|---|
| Products | Long-only shares of `SPY`, `QQQ`, `IWM`, `XLF`, `XLU` |
| Signal model | OpenAI `gpt-6.1-sol`, decisions every ~5 min while running |
| Data | Alpaca free-tier IEX 5-minute bars; may not reflect the whole US market |
| AI authority | Propose BUY/SELL/HOLD only — no authority to alter risk limits or submit orders directly |
| Technical guardrail | For BUY, price > EMA9 > EMA21, RSI 45–72, 1-hour momentum between 0 and 3% |
| Order size | Whole shares, max **5% equity**, max **$1,500 order notional** by default, and cash-funded only; no leverage/shorting |
| Dollar cap setting | `MAX_ORDER_DOLLARS` in `.env`; upper software cap **$5,000**, lower cap $10 |
| Daily entry cap | **3** attempts; persisted state + broker orders used to prevent duplicates |
| Equity drawdown | **1%** relative to Alpaca prior-session account equity triggers daily lockout and a best-effort flatten |
| Protective orders | Alpaca bracket with ~**0.8% stop loss** and ~**1.2% take-profit** based on latest bar, not guaranteed fill prices |
| Hours | Enters after 9:50 a.m. ET and stops new entries >40 min before actual session close |
| End-of-day exit | Tries to flatten managed positions starting **25 minutes before broker-reported close**; repeats checks every 15 seconds |
| Exposure | At most one brokerage position / managed strategy position at a time; no trading if unknown positions or orders exist |
| Exit behavior | AI can choose to sell. Before market-closing an AI-managed bracket position, bot cancels its working orders and confirms they are no longer open. It will not repeatedly cancel its own pending market-exit order. |
| Separation | Separate `activity_paper.jsonl` / `activity_live.jsonl` and `state_paper.json` / `state_live.json`; state bound to brokerage account ID |

**More limits:** The signal service may be unavailable, market data may be incomplete, fills can be slow, broker cancellations can race with fills, stop orders can execute at much worse prices, and API/Internet/computer outages can strand open positions. Risk checks every 15 seconds are **not real-time guarantees**. A 1% lockout cannot guarantee losses will stay below 1%. The bot logs failures rather than knowingly bypassing risk checks. Nothing here limits catastrophic market loss.

The signal logic has **not** been backtested or empirically shown to outperform passive investing; it should be treated as a learning prototype, **not a set-and-forget wealth generator**.

## Stopping the bot / emergency

- **Ctrl+C:** Stops the bot program but **does not** cancel or exit any existing positions. An Alpaca bracket order may remain active.
- **STOP_BOT.bat** or the dashboard button: creates `STOP.txt`. The running bot notices within about 15 seconds, blocks new trades and tries to cancel and exit only bot-managed positions. It does not assume positions have filled or exited until broker confirms. The same STOP applies to either mode.
- **If the bot is crashed/offline, manual broker intervention is required.** Log in to Alpaca directly, inspect active orders and positions, cancel/close manually as appropriate. A text file cannot reach Alpaca when the program is offline.
- To resume after checking the account and dealing with any remaining orders, manually delete `STOP.txt`; then restart the bot. Remove a stale `.bot.lock` **only if you verified the previous bot process is no longer running**.
- **If changing Alpaca accounts, do not blindly reuse an existing state file.** Bot detects account ID mismatch and refuses to trade. Inspect broker orders/positions first; an incorrect state migration could cause unsafe position management.

## Validation and development

Run the unit tests:

` .venv\Scripts\python.exe -m unittest discover -s tests -v `

All tests are local and use mocks. They cover configuration gates, order caps, technical BUY filter, managed-position cancellation / close behavior, existing pending market exits, and emergency stop behavior. **Unit tests are not broker integration tests.** Alpaca live brokerage access, real market feeds, execution/recovery, fees, latency, broker permissions, P&L and Windows runner scripts were **not** verified end to end here.

## References

- [Alpaca Python trading client (paper and live modes)](https://alpaca.markets/sdks/python/api_reference/trading/trading-client.html)
- [Alpaca bracket order behavior](https://docs.alpaca.markets/us/docs/orders-at-alpaca)
- [OpenAI structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Investor.gov: intraday margin rule transition / PDT](https://www.investor.gov/introduction-investing/investing-basics/glossary/pattern-day-trader)
