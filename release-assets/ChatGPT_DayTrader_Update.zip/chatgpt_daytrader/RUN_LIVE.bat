@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Run SETUP_WINDOWS.bat first. & pause & exit /b 1)
echo.
echo  *************************************************************
echo  WARNING: LIVE AUTONOMOUS TRADING WITH REAL MONEY
 echo  Potential real losses. An AI strategy has no proven edge.
echo  No guaranteed stop-loss fills or guaranteed end-of-day exit.
echo  LIVE MODE NEVER INSTALLS GITHUB UPDATES AUTOMATICALLY.
echo  This will run WITHOUT APPROVING EACH TRADE.
echo  *************************************************************
echo.
set /p CONFIRM=To start, type exactly I ACCEPT REAL MONEY LOSSES : 
if /I NOT "%CONFIRM%"=="I ACCEPT REAL MONEY LOSSES" (echo Confirmation failed; live bot NOT started. & pause & exit /b 2)
.venv\Scripts\python.exe bot.py --live --confirm-live
pause
