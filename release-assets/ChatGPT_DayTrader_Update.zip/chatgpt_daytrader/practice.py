"""LOCAL, 24/7 simulated trade testing. NEVER submits Alpaca orders.

--demo: scripted, synthetic prices, no keys needed. Proves simulator plumbing.
--replay: latest complete historical session, GPT decisions & same entry filters.

Neither mode is an Alpaca paper-trading account; executions appear only in
practice_state.json, practice_trades.jsonl and activity_practice.jsonl.
"""
from __future__ import annotations

import argparse
from bisect import bisect_right
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from zoneinfo import ZoneInfo
import json
import math
import os
import sys
import time

from strategy import RiskLimits, bracket_prices, drawdown_hit, indicators, position_shares, technical_entry_allowed

ROOT = Path(__file__).resolve().parent
NY = ZoneInfo('America/New_York')
STATE = ROOT / 'practice_state.json'
LOG = ROOT / 'activity_practice.jsonl'
TRADES = ROOT / 'practice_trades.jsonl'
LOCK = ROOT / '.practice.lock'
STOP = ROOT / 'PRACTICE_STOP.txt'
STARTING_BALANCE = 100_000.0


def log(kind: str, message: str, **details):
    record = {'time': datetime.now(timezone.utc).isoformat(), 'kind': kind,
              'message': message, **details}
    with LOG.open('a', encoding='utf-8') as f:
        f.write(json.dumps(record, default=str) + '\n')
    print(f"{record['time']}  {kind}: {message}", flush=True)


def record_trade(**fields):
    record = {'time': datetime.now(timezone.utc).isoformat(), **fields}
    with TRADES.open('a', encoding='utf-8') as f:
        f.write(json.dumps(record, default=str) + '\n')


def write_state(data: dict):
    temp = STATE.with_suffix('.json.tmp')
    temp.write_text(json.dumps(data, indent=2, default=str), encoding='utf-8')
    temp.replace(STATE)


@dataclass(frozen=True)
class Bar:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float


class PracticePortfolio:
    """Cash-only, one-position, next-bar-open execution with OHLC bracket tests.

    All fills are ASSUMPTIONS, not broker fills. If both stop and target were
    touched in one bar, use the worse stop outcome. No commissions/slippage.
    """
    def __init__(self, mode: str, initial_cash: float = STARTING_BALANCE,
                 max_order_dollars: float = 1500.0):
        self.mode = mode
        self.cash = initial_cash
        self.start_equity = initial_cash
        self.limits = RiskLimits(max_order_dollars=max_order_dollars)
        self.position: dict | None = None
        self.pending: tuple[str, str] | None = None
        self.last_prices: dict[str, float] = {}
        self.entries = 0
        self.closed = 0
        self.gross_pnl = 0.0
        self.locked = False
        self.last_time = ''
        self.status = 'RUNNING'

    def equity(self) -> float:
        return self.cash + (self.position['qty'] * self.last_prices.get(
            self.position['symbol'], self.position['price']) if self.position else 0)

    def snapshot(self) -> dict:
        return {
            'kind': self.mode, 'status': self.status,
            'cash': round(self.cash, 2), 'equity': round(self.equity(), 2),
            'starting_balance': round(self.start_equity, 2),
            'realized_pnl': round(self.gross_pnl, 2), 'entries': self.entries,
            'closed': self.closed, 'position': self.position, 'pending': self.pending,
            'risk_locked': self.locked, 'market_time_replayed': self.last_time,
            'note': 'LOCAL SIMULATION ONLY. Not submitted to Alpaca or a real broker. No execution slippage or fees modeled.',
        }

    def save(self):
        write_state(self.snapshot())

    def queue(self, action: str, symbol: str) -> bool:
        if self.locked or self.pending is not None:
            return False
        if action == 'BUY' and self.position is None and self.entries < self.limits.max_entries_per_day:
            self.pending = ('BUY', symbol)
            log('SIGNAL', f'Queued fake BUY {symbol} for next historical bar open')
            return True
        if action == 'SELL' and self.position and self.position['symbol'] == symbol:
            self.pending = ('SELL', symbol)
            log('SIGNAL', f'Queued fake SELL {symbol} for next historical bar open')
            return True
        return False

    def _exit(self, symbol: str, price: float, reason: str, t: datetime):
        if self.position is None or self.position['symbol'] != symbol:
            return
        held = self.position
        qty = held['qty']
        realized = (price - held['price']) * qty
        self.cash += price * qty
        self.gross_pnl += realized
        self.closed += 1
        log('FILL', f'FAKE SELL {qty} {symbol} @ ${price:.2f} ({reason}), P&L ${realized:+.2f}',
            symbol=symbol, qty=qty, assumed_price=price, simulated_pnl=round(realized, 2))
        record_trade(mode=self.mode, action='SELL', symbol=symbol, qty=qty,
                     assumed_price=price, realized_pnl=round(realized, 2), reason=reason,
                     historical_time=t.isoformat(), simulated=True)
        self.position = None
        self.pending = None

    def step(self, bars: dict[str, Bar], t: datetime):
        self.last_time = t.isoformat()
        # Fills queued after the previous close at the next bar's open.
        if self.pending:
            action, symbol = self.pending
            if symbol in bars:
                b = bars[symbol]
                if action == 'SELL':
                    self._exit(symbol, b.open, 'AI or scripted signal', t)
                elif action == 'BUY' and self.position is None and not self.locked:
                    qty = position_shares(self.equity(), self.cash, b.open,
                                          self.limits.max_position_pct,
                                          self.limits.max_order_dollars)
                    if qty > 0:
                        stop, target = bracket_prices(b.open, self.limits.stop_loss_pct,
                                                      self.limits.take_profit_pct)
                        self.cash -= qty * b.open
                        self.position = {'symbol': symbol, 'qty': qty, 'price': b.open,
                                         'stop': stop, 'target': target}
                        self.entries += 1
                        log('FILL', f'FAKE BUY {qty} {symbol} @ ${b.open:.2f}',
                            symbol=symbol, qty=qty, assumed_price=b.open)
                        record_trade(mode=self.mode, action='BUY', symbol=symbol, qty=qty,
                                     assumed_price=b.open, historical_time=t.isoformat(), simulated=True)
                    else:
                        log('RISK', 'Fake BUY refused by position limit / available cash')
                    self.pending = None
        # If bar high/low visits both exit levels, assume stop happens first.
        if self.position:
            symbol = self.position['symbol']
            if symbol in bars:
                b = bars[symbol]
                stop, target = self.position['stop'], self.position['target']
                if b.open <= stop:
                    self._exit(symbol, b.open, 'gap below stop (simulated)', t)
                elif b.low <= stop:
                    self._exit(symbol, stop, 'stop loss (simulated)', t)
                elif b.open >= target:
                    self._exit(symbol, b.open, 'gap above target (simulated)', t)
                elif b.high >= target:
                    self._exit(symbol, target, 'take profit (simulated)', t)
        for symbol, bar in bars.items():
            self.last_prices[symbol] = bar.close
        if not self.locked and drawdown_hit(self.equity(), self.start_equity,
                                            self.limits.max_daily_loss_pct):
            self.locked = True
            self.pending = None
            log('RISK', 'Simulation daily loss lockout triggered')
            if self.position:
                symbol = self.position['symbol']
                self.queue_flatten(symbol)
        self.save()

    def queue_flatten(self, symbol: str):
        if self.position and self.position['symbol'] == symbol:
            self.pending = ('SELL', symbol)

    def finish(self, bars: dict[str, Bar], t: datetime):
        if self.position:
            symbol = self.position['symbol']
            # Forced closing-price fill is an optimistic modeling assumption.
            self._exit(symbol, bars[symbol].close, 'end of historical session (assumed close)', t)
        self.pending = None
        self.status = 'FINISHED'
        self.last_time = t.isoformat()
        self.save()
        log('DONE', f'{self.mode.upper()} finished. {self.entries} fake entries, '
            f'{self.closed} fake exits. Simulated net P&L ${self.gross_pnl:+.2f}. '
            'No orders submitted to Alpaca.')


def demo():
    """Guaranteed scripted buy/exit smoke test. Never contacts any API."""
    p = PracticePortfolio('demo')
    log('START', 'SCRIPTED DEMO — made-up historical-style prices; no AI and NO broker orders')
    t = datetime(2026, 10, 30, 14, 0, tzinfo=timezone.utc)
    p.queue('BUY', 'SPY')
    candles = [
        Bar(t, 100, 100.5, 99.9, 100.3),
        Bar(t+timedelta(minutes=5), 100.3, 101.75, 100.2, 101.3),
        Bar(t+timedelta(minutes=10), 101.3, 101.4, 100.9, 101.0),
        Bar(t+timedelta(minutes=15), 101.0, 101.4, 100.95, 101.2),
        Bar(t+timedelta(minutes=20), 101.2, 101.3, 100.1, 100.5),
    ]
    for i, candle in enumerate(candles):
        if STOP.exists():
            p.status = 'STOPPED'
            p.save()
            log('STOP', 'User stopped practice mode; no broker orders exist')
            return
        if i == 3:
            p.queue('BUY', 'SPY')
        p.step({'SPY': candle}, candle.timestamp)
        time.sleep(0.35)
    p.finish({'SPY': candles[-1]}, candles[-1].timestamp)


def historical_bars(paper_key: str, paper_secret: str):
    """Read-only historical data. There is no TradingClient in this module."""
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
    from alpaca.data.enums import DataFeed
    from bot import WATCHLIST
    client = StockHistoricalDataClient(paper_key, paper_secret)
    end = datetime.now(timezone.utc)-timedelta(minutes=20)
    start = end-timedelta(days=24)
    response = client.get_stock_bars(StockBarsRequest(
        symbol_or_symbols=list(WATCHLIST),
        timeframe=TimeFrame(5, TimeFrameUnit.Minute), start=start, end=end,
        feed=DataFeed.IEX, limit=10000))
    by_symbol = {}
    for symbol in WATCHLIST:
        bars = [Bar(b.timestamp.astimezone(timezone.utc), float(b.open),
                    float(b.high), float(b.low), float(b.close))
                for b in response.data.get(symbol, [])]
        bars.sort(key=lambda b: b.timestamp)
        by_symbol[symbol] = bars
    if len(by_symbol['SPY']) < 85:
        raise RuntimeError('Not enough SPY historical bars from Alpaca IEX feed.')
    # Only use a completed previous session; never pretend today's partial
    # regular market session is a complete replay.
    sessions = {}
    for b in by_symbol['SPY']:
        local = b.timestamp.astimezone(NY)
        if (local.hour, local.minute) >= (9, 30) and (local.hour, local.minute) < (16, 0):
            sessions.setdefault(local.date(), []).append(b)
    eligible = [d for d, candles in sessions.items()
                if len(candles) >= 55 and
                max(x.timestamp.astimezone(NY).hour*60 + x.timestamp.astimezone(NY).minute
                    for x in candles) >= 15*60+35]
    if not eligible:
        raise RuntimeError('No completed session with sufficient historical bars. Try a prior weekday.')
    session = max(eligible)
    return by_symbol, sessions[session], session


def replay():
    from dotenv import dotenv_values
    from bot import WATCHLIST, ai_decision
    values = dotenv_values(ROOT / '.env')
    paper_key = (values.get('ALPACA_PAPER_KEY') or '').strip()
    paper_secret = (values.get('ALPACA_PAPER_SECRET') or '').strip()
    oa_key = (values.get('OPENAI_API_KEY') or '').strip()
    if not paper_key or not paper_secret or not oa_key:
        raise RuntimeError('AI Replay requires both Alpaca PAPER data keys and an OpenAI API key. Open API Keys and Save All Keys.')
    from openai import OpenAI
    model = (values.get('OPENAI_MODEL') or 'gpt-6.1-sol').strip()
    max_dollars = float(values.get('MAX_ORDER_DOLLARS') or 1500)
    bars_by_symbol, session_bars, session = historical_bars(paper_key, paper_secret)
    p = PracticePortfolio('ai_replay', max_order_dollars=max_dollars)
    log('START', f'AI historical replay {session} (IEX five-minute bars); '
        'NO live price stream; NO Alpaca order submissions; model calls incur API charges.',
        model=model, session=str(session))
    ai = OpenAI(api_key=oa_key, timeout=40.0, max_retries=1)
    timestamps = {s: [b.timestamp for b in bs] for s, bs in bars_by_symbol.items()}
    next_ai_minute = 0
    latest = {}
    ai_calls = 0
    for candle in session_bars:
        if STOP.exists():
            p.status = 'STOPPED'
            p.save()
            log('STOP', 'Practice replay stopped. No broker orders were placed.')
            return
        t = candle.timestamp
        latest = {'SPY': candle}
        features = {}
        for symbol in WATCHLIST:
            bars = bars_by_symbol[symbol]
            j = bisect_right(timestamps[symbol], t)
            if j < 36:
                continue
            most_recent = bars[j-1]
            if (t-most_recent.timestamp).total_seconds() > 15*60:
                continue
            current = bars[j-1]
            if current.timestamp == t:
                latest[symbol] = current
            try:
                features[symbol] = indicators(bars[:j])
            except (ValueError, IndexError):
                continue
        p.step(latest, t)
        local = t.astimezone(NY)
        minutes = local.hour*60 + local.minute
        if not features or minutes < 10*60+5 or minutes > 15*60+10 or minutes < next_ai_minute:
            continue
        next_ai_minute = minutes + 30
        sim_positions = {}
        if p.position:
            pos = p.position
            marked = latest.get(pos['symbol'])
            sim_positions[pos['symbol']] = SimpleNamespace(
                qty=pos['qty'], unrealized_plpc=(marked.close/pos['price']-1) if marked else 0)
        try:
            decision = ai_decision(ai, features, sim_positions, model, at_time=t)
        except Exception as exc:
            p.status = 'ERROR'
            p.save()
            log('ERROR', f'AI replay could not request a decision: {type(exc).__name__}: {exc}')
            return
        ai_calls += 1
        symbol = decision.symbol.upper().strip()
        log('AI', f'REPLAY {decision.action} {symbol}: {decision.reason}',
            historical_time=t.isoformat())
        if decision.action == 'BUY' and symbol in features:
            if technical_entry_allowed(features[symbol]):
                p.queue('BUY', symbol)
            else:
                log('RISK', f'Entry rejected by technical filter for {symbol}')
        elif decision.action == 'SELL' and p.position and symbol == p.position['symbol']:
            p.queue('SELL', symbol)
        p.save()
    if not latest:
        raise RuntimeError('Historical session contains no usable candles.')
    last_t = session_bars[-1].timestamp
    end_bars = {s: bs[bisect_right(timestamps[s], last_t)-1] for s, bs in bars_by_symbol.items()
                if bisect_right(timestamps[s], last_t) > 0}
    p.finish(end_bars, last_t)
    if not p.entries:
        log('INFO', f'AI issued {ai_calls} decisions but no entries passed the entry filter. '
            'That is a valid HOLD result, not a simulator failure. Click Instant Sample Trade to verify fills.')


def main():
    parser = argparse.ArgumentParser(description='24/7 LOCAL practice test; NO Alpaca orders')
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--demo', action='store_true', help='Synthetic scripted sample fills, no keys')
    modes.add_argument('--replay', action='store_true', help='AI + actual past stock bars; NO Alpaca trades')
    args = parser.parse_args()
    if LOCK.exists():
        print('Another practice test may be running. Please investigate before retrying.', file=sys.stderr)
        return 3
    fd = None
    try:
        fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(str(os.getpid()))
        fd = None
        STOP.unlink(missing_ok=True)  # only practice stop; never alter real trading STOP.txt
        if args.demo:
            demo()
        else:
            replay()
        return 0
    except Exception as exc:
        log('ERROR', f'Practice test failed: {type(exc).__name__}: {exc}')
        write_state({'kind': 'demo' if args.demo else 'ai_replay', 'status':'ERROR', 'error':str(exc),
                     'note':'No Alpaca orders were submitted by practice mode.'})
        return 1
    finally:
        if fd is not None:
            os.close(fd)
        LOCK.unlink(missing_ok=True)


if __name__ == '__main__':
    sys.exit(main())
