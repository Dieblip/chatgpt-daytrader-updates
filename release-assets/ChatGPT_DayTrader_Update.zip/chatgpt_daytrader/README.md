# ChatGPT Day Trader V6.1 — Paper Trading Insights & Automatic Updates

This is an experimental Windows day-trading **prototype**, not a guaranteed profitable strategy. The app connects to Alpaca and the OpenAI API, can trade autonomously while running, and has a separate 24/7 *local* practice simulator.

## New in V6.1.0 — three paper-trading improvements

- **Paper broker confirmations:** The bot checks paper order statuses about once per minute. **Submitted is not filled.** The GUI home panel shows a last-seen bot health signal (and warns if it gets stale). No new orders are placed by the status checker.
- **Detailed AI reasoning:** The dashboard's **AI decision log** explains every completed BUY/SELL/HOLD signal, the indicators supplied, and why a trade was allowed or rejected. CSV export is available.
- **Performance dashboard:** **Performance & win rate** and **Broker orders / fills** tabs use read-only Alpaca paper API calls to calculate *estimated* completed-trade P&L, round trips, and wins/losses. This is not a broker statement, includes only recognized bot trades over a limited order-history window, and can miss fees/partial fills. Real and local-practice results remain distinctly labeled.

See `CHANGES_V6_1.md` for the update test and important limitations.

## Fast setup

1. **Extract the full Windows ZIP**, open its `chatgpt_daytrader` folder, and double-click **`START_DAYTRADER.bat`**. If Python 3.11+ isn't installed, the launcher can offer to install Python 3.12 using Windows Package Manager. Reopen the launcher after Python installs. The first run may install packages.
2. The **Connect Accounts** wizard opens automatically. Get two Alpaca **PAPER** keys from [Alpaca](https://app.alpaca.markets/) and one OpenAI API key from [OpenAI](https://platform.openai.com/api-keys). OpenAI API use may require separate billing.
3. Paste the keys into the wizard and click **SAVE KEYS & TEST CONNECTIONS**. Keys save to local `.env`; there is no manual `.env` editing or GitHub login to receive updates.
4. Click **INSTANT SAMPLE TRADES** to test immediately without keys. These local scripted practice fills **never appear in Alpaca**.
5. For actual Alpaca paper trades, choose **Paper** and click **RUN ALL**. It runs during eligible U.S. stock-market hours; a valid HOLD decision may mean zero trades. A historical AI replay is also available for after-hours testing.

**Already used an older version?** In the wizard select **Import its keys** and choose your OLD `chatgpt_daytrader` folder. The app reads its `.env`, copies supported fields, but *never* copies live-start authorizations.

## GitHub updates — already connected

The update repository is preconfigured to `Dieblip/chatgpt-daytrader-updates`, so there is **no GitHub username, token, or URL to enter** to receive public releases.

The app checks for updates shortly after opening. On **Updates**, choose **CHECK NOW** to check, or **INSTALL AVAILABLE UPDATE** to install an actually newer published release. Verified SHA-256 asset downloads are used; old program files are restored on most installation failures. Your `.env`, trading history, and settings are preserved. The GUI closes for the update and reopens after success. Auto-install of newer releases happens only before a **Paper** run when the checkbox is enabled, never during live trading. If no release has been published, the app continues to run normally.

**Publishing future versions:** Updates don't publish themselves. The optional **Publish** area in the Updates tab uses the official GitHub CLI and browser login (`gh auth login --web`). After signing in once, use **Publish THIS Installed Version** or **Choose ZIP & Publish**. This requires permission to publish releases in your GitHub repository. You do *not* need GitHub CLI to receive releases.

## What live mode means

- **Live = real money and real orders.** Live credentials are separate from Paper, and the GUI requires the exact typed phrase `START LIVE` for **each live run**. Merely selecting Live does not start trading.
- The preexisting prototype limits orders to up to 5% of account equity and a $1,500 default per-order dollar cap (configurable $10–$5,000), up to three new entries/day, and an equity drawdown guard. Protective stops may fail to fill at the expected price; the daily cutoff is not guaranteed.
- Do not use live mode until broker connectivity, failure recovery, order handling, backtesting and paper results have been independently reviewed. This version has **not** demonstrated profitability or been tested with live broker orders on your PC.
- The bot runs only while your PC/connection and its process remain working. An emergency stop is a **request**, not proof that a broker canceled or liquidated positions. Verify directly in Alpaca.

## Security & troubleshooting

Never post API keys, your `.env`, or screenshots containing secrets. The public GitHub update repository should contain only reviewed code and update assets—not account files. A GitHub release's published SHA-256 digest verifies downloaded bytes but **does not prove the publisher is trustworthy**; only enable auto-install from a repository you control and trust.

If startup fails, reopen `START_DAYTRADER.bat` and read the console. For bot errors, select **Activity & Help** inside the GUI. The dashboard runs locally at `http://127.0.0.1:8501`. After any update, inspect configuration and practice test before starting automatic trading.

Additional advanced notes are in `ADVANCED_GUIDE.md`. Local unit tests cover core logic but are not a substitute for real brokerage API integration testing.
