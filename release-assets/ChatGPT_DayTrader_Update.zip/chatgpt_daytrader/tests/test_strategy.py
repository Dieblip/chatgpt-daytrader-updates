import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from strategy import RiskLimits, bracket_prices, drawdown_hit, indicators, position_shares, rsi


class RiskTest(unittest.TestCase):
    def test_limits(self):
        self.assertRaises(ValueError, RiskLimits, max_position_pct=.5)
        self.assertRaises(ValueError, RiskLimits, max_daily_loss_pct=.1)

    def test_cash_only_sizing(self):
        self.assertEqual(position_shares(10000, 10000, 100, .05), 4)
        self.assertEqual(position_shares(10000, 20, 100, .05), 0)
        self.assertEqual(position_shares(10000, 10000, 0, .05), 0)

    def test_cutoff(self):
        self.assertTrue(drawdown_hit(9900, 10000, .01))
        self.assertFalse(drawdown_hit(9950, 10000, .01))

    def test_bracket(self):
        self.assertEqual(bracket_prices(100, .008, .012), (99.2, 101.2))

    def test_indicators(self):
        start = datetime(2026, 10, 1, tzinfo=timezone.utc)
        bars = [SimpleNamespace(timestamp=start + timedelta(minutes=i*5), close=100+i*.1)
                for i in range(50)]
        result = indicators(bars)
        self.assertEqual(result['price'], 104.9)
        self.assertGreater(result['ema9'], result['ema21'])
        self.assertEqual(result['rsi14'], 100)
        self.assertRaises(ValueError, indicators, bars[:4])
        self.assertEqual(rsi([100]*16), 50)


if __name__ == '__main__':
    unittest.main()
