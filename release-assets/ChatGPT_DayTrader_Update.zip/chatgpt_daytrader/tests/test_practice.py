"""Offline tests for the two local 24/7 simulation features."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import json

import pytest

import practice
import updater


def candle(t, op=100, hi=101, lo=99.5, cl=100.1):
    return practice.Bar(t, op, hi, lo, cl)


def test_sample_demo_always_produces_two_fake_entries_and_exits(tmp_path, monkeypatch):
    monkeypatch.setattr(practice, 'STATE', tmp_path/'practice_state.json')
    monkeypatch.setattr(practice, 'LOG', tmp_path/'activity_practice.jsonl')
    monkeypatch.setattr(practice, 'TRADES', tmp_path/'practice_trades.jsonl')
    monkeypatch.setattr(practice, 'STOP', tmp_path/'PRACTICE_STOP.txt')
    monkeypatch.setattr(practice.time, 'sleep', lambda *_: None)
    practice.demo()
    state = json.loads(practice.STATE.read_text())
    assert state['status'] == 'FINISHED'
    assert state['entries'] == 2
    assert state['closed'] == 2
    trades = [json.loads(row) for row in practice.TRADES.read_text().splitlines()]
    assert [x['action'] for x in trades] == ['BUY', 'SELL', 'BUY', 'SELL']
    assert all(x['simulated'] is True for x in trades)
    assert 'No orders submitted to Alpaca' in practice.LOG.read_text()


def test_open_next_bar_not_current_bar(tmp_path, monkeypatch):
    monkeypatch.setattr(practice, 'STATE', tmp_path/'practice_state.json')
    monkeypatch.setattr(practice, 'LOG', tmp_path/'activity_practice.jsonl')
    monkeypatch.setattr(practice, 'TRADES', tmp_path/'practice_trades.jsonl')
    p = practice.PracticePortfolio('demo')
    t = datetime(2026, 1, 5, 15, 0, tzinfo=timezone.utc)
    p.step({'SPY': candle(t)}, t)
    assert p.queue('BUY', 'SPY')
    assert p.entries == 0
    later = t + timedelta(minutes=5)
    p.step({'SPY': candle(later, 101, 101.2, 100.9, 101)}, later)
    assert p.entries == 1
    assert p.position['price'] == 101


def test_when_stop_and_target_touched_assume_stop_first(tmp_path, monkeypatch):
    monkeypatch.setattr(practice, 'STATE', tmp_path/'practice_state.json')
    monkeypatch.setattr(practice, 'LOG', tmp_path/'activity_practice.jsonl')
    monkeypatch.setattr(practice, 'TRADES', tmp_path/'practice_trades.jsonl')
    p = practice.PracticePortfolio('demo')
    t = datetime(2026, 1, 5, 15, 0, tzinfo=timezone.utc)
    p.queue('BUY', 'SPY')
    p.step({'SPY': candle(t, 100, 100.1, 99.9, 100)}, t)
    p.step({'SPY': candle(t+timedelta(minutes=5), 100, 102, 99.1, 101)},
           t+timedelta(minutes=5))
    assert p.position is None
    assert p.gross_pnl < 0
    sell = json.loads(practice.TRADES.read_text().splitlines()[-1])
    assert sell['reason'] == 'stop loss (simulated)'


def test_entry_limit_and_position_size_cannot_be_overridden(tmp_path, monkeypatch):
    monkeypatch.setattr(practice, 'STATE', tmp_path/'practice_state.json')
    monkeypatch.setattr(practice, 'LOG', tmp_path/'activity_practice.jsonl')
    monkeypatch.setattr(practice, 'TRADES', tmp_path/'practice_trades.jsonl')
    p = practice.PracticePortfolio('demo')
    p.entries = p.limits.max_entries_per_day
    assert not p.queue('BUY', 'SPY')
    p.entries = 0
    t = datetime(2026, 1, 5, 15, 0, tzinfo=timezone.utc)
    assert p.queue('BUY', 'SPY')
    p.step({'SPY': candle(t, 100, 100.2, 99.9, 100.1)}, t)
    assert p.position['qty'] * p.position['price'] <= p.limits.max_order_dollars
    assert p.position['qty'] * p.position['price'] <= p.equity()*p.limits.max_position_pct
    assert not p.queue('BUY', 'QQQ')


def test_replay_missing_keys_fails_before_network(tmp_path, monkeypatch):
    monkeypatch.setattr(practice, 'ROOT', tmp_path)
    with pytest.raises(RuntimeError, match='PAPER data keys'):
        practice.replay()


def test_user_can_stop_scripted_demo_without_orders(tmp_path, monkeypatch):
    monkeypatch.setattr(practice, 'STATE', tmp_path/'practice_state.json')
    monkeypatch.setattr(practice, 'LOG', tmp_path/'activity_practice.jsonl')
    monkeypatch.setattr(practice, 'TRADES', tmp_path/'practice_trades.jsonl')
    monkeypatch.setattr(practice, 'STOP', tmp_path/'PRACTICE_STOP.txt')
    practice.STOP.write_text('STOP PRACTICE\n')
    practice.demo()
    state = json.loads(practice.STATE.read_text())
    assert state['status'] == 'STOPPED'
    assert not practice.TRADES.exists()


def test_update_refuses_during_active_practice(tmp_path):
    (tmp_path/'.practice.lock').write_text('123')
    with pytest.raises(updater.UpdateError, match='practice simulator'):
        updater._bot_not_running(tmp_path)


def test_update_rejects_replacing_practice_state():
    with pytest.raises(updater.UpdateError, match='protected'):
        updater._safe_relative('chatgpt_daytrader/practice_state.json')
