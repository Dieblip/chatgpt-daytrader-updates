from pathlib import Path
from urllib.error import HTTPError
from unittest.mock import patch

import pytest

import quick_connect
import updater
from publish_helper import inspect_release_zip, publication_command


def test_paper_configuration_requires_three_keys():
    values = {'ALPACA_PAPER_KEY': 'paper', 'ALPACA_PAPER_SECRET': 'secret', 'OPENAI_API_KEY': 'oa'}
    assert quick_connect.configured(values)
    assert not quick_connect.configured({**values, 'OPENAI_API_KEY': ''})
    assert not quick_connect.configured(values, 'live')
    assert not quick_connect.configured(values, 'unknown')


def test_import_keys_excludes_live_permission(tmp_path: Path):
    (tmp_path / '.env').write_text('ALPACA_PAPER_KEY="abc"\nOPENAI_API_KEY="xyz"\nLIVE_TRADING_ENABLED=YES\n')
    got = quick_connect.import_old_keys(tmp_path)
    assert got == {'ALPACA_PAPER_KEY': 'abc', 'OPENAI_API_KEY': 'xyz'}
    assert 'LIVE_TRADING_ENABLED' not in got


def test_import_error_friendly(tmp_path: Path):
    with pytest.raises(ValueError, match='No .env file'):
        quick_connect.import_old_keys(tmp_path)


def test_github_404_without_releases_message():
    err = HTTPError('https://api.github.com/repos/x/y/releases/latest', 404, 'Not Found', {}, None)
    with patch('urllib.request.urlopen', side_effect=err):
        with pytest.raises(updater.UpdateError, match='No published update releases'):
            updater.fetch_latest('x/y')


def test_reject_wrong_named_zip(tmp_path):
    path = tmp_path / 'wrong.zip'
    path.write_bytes(b'a' * 100)
    with pytest.raises(updater.UpdateError, match='named exactly'):
        inspect_release_zip(path)


def test_unknown_gh_is_descriptive(tmp_path):
    path = tmp_path / updater.ASSET_NAME
    path.write_bytes(b'hello')
    with patch('publish_helper.cli_path', return_value=None):
        with pytest.raises(updater.UpdateError, match='not installed'):
            publication_command(path, 'user/repo')
