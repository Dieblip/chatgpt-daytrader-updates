import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from settings import LIVE_ACK, resolve_settings
from strategy import position_shares, technical_entry_allowed
import bot


class LiveSettingsTest(unittest.TestCase):
    BASE = {
        'ALPACA_PAPER_KEY': 'paper-key', 'ALPACA_PAPER_SECRET': 'paper-secret',
        'ALPACA_LIVE_KEY': 'live-key', 'ALPACA_LIVE_SECRET': 'live-secret',
        'OPENAI_API_KEY': 'openai-key', 'OPENAI_MODEL': 'gpt-6.1-sol',
        'LIVE_TRADING_ENABLED': 'NO', 'MAX_ORDER_DOLLARS': '1500',
    }

    def test_default_is_paper_even_with_live_credentials(self):
        self.assertEqual(resolve_settings(self.BASE, live=False, confirmed=False).mode, 'paper')

    def test_live_requires_both_intent_and_ack(self):
        v = dict(self.BASE)
        self.assertRaisesRegex(RuntimeError, 'LIVE DISABLED', resolve_settings,
                               v, live=True, confirmed=True)
        v['LIVE_TRADING_ENABLED'] = LIVE_ACK
        self.assertRaisesRegex(RuntimeError, 'LIVE DISABLED', resolve_settings,
                               v, live=True, confirmed=False)
        s = resolve_settings(v, live=True, confirmed=True)
        self.assertTrue(s.live)
        self.assertEqual(s.key, 'live-key')

    def test_live_keys_cannot_equal_paper(self):
        v = dict(self.BASE, LIVE_TRADING_ENABLED=LIVE_ACK, ALPACA_LIVE_KEY='paper-key')
        self.assertRaisesRegex(RuntimeError, 'different', resolve_settings,
                               v, live=True, confirmed=True)

    def test_absolute_order_cap(self):
        self.assertEqual(position_shares(100_000, 100_000, 100, 0.05, 500), 4)
        self.assertRaisesRegex(RuntimeError, 'MAX_ORDER_DOLLARS', resolve_settings,
                               dict(self.BASE, MAX_ORDER_DOLLARS='10000'), live=False, confirmed=False)

    def test_hard_filter(self):
        self.assertTrue(technical_entry_allowed({
            'price': 100, 'ema9': 99, 'ema21': 98, 'rsi14': 57,
            'return_1h_pct': 0.6}))
        self.assertFalse(technical_entry_allowed({
            'price': 100, 'ema9': 101, 'ema21': 102, 'rsi14': 57,
            'return_1h_pct': 0.6}))
        self.assertFalse(technical_entry_allowed({
            'price': 100, 'ema9': 99, 'ema21': 98, 'rsi14': 95,
            'return_1h_pct': 0.6}))


class EmergencyTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.original_log = bot.LOG
        self.original_state = bot.STATE
        self.original_stop = bot.STOP_FILE
        bot.LOG = Path(self.temp.name) / 'activity_test.jsonl'
        bot.STATE = Path(self.temp.name) / 'state_test.json'
        bot.STOP_FILE = Path(self.temp.name) / 'STOP.txt'

    def tearDown(self):
        bot.LOG = self.original_log
        bot.STATE = self.original_state
        bot.STOP_FILE = self.original_stop
        self.temp.cleanup()

    def test_cancel_pending_buy_even_without_a_position(self):
        trading = MagicMock()
        trading.get_all_positions.return_value = []
        pending_buy = SimpleNamespace(symbol='SPY', id='abc123', type='market', side='buy')
        with patch.object(bot, 'open_orders', side_effect=[[pending_buy], []]), patch.object(bot.time, 'sleep'):
            bot.safe_unwind(trading, {'managed_symbols': ['SPY']}, 'emergency', False)
        trading.cancel_order_by_id.assert_called_once_with('abc123')
        trading.close_position.assert_not_called()

    def test_close_managed_position_only_after_order_cancellation(self):
        trading = MagicMock()
        position = SimpleNamespace(symbol='SPY', qty='3')
        trading.get_all_positions.return_value = [position]
        trading.close_position.return_value = SimpleNamespace(id='close-id')
        stop = SimpleNamespace(symbol='SPY', id='stop-id', type='stop', side='sell')
        with patch.object(bot, 'open_orders', side_effect=[[stop], []]), patch.object(bot.time, 'sleep'):
            bot.safe_unwind(trading, {'managed_symbols': ['SPY']}, 'daily cutoff', False)
        trading.cancel_order_by_id.assert_called_once_with('stop-id')
        trading.close_position.assert_called_once_with('SPY')

    def test_never_close_unmanaged_holding(self):
        trading = MagicMock()
        trading.get_all_positions.return_value = [SimpleNamespace(symbol='QQQ', qty='5')]
        with patch.object(bot, 'open_orders', return_value=[]):
            bot.safe_unwind(trading, {'managed_symbols': ['SPY']}, 'stop', False)
        trading.close_position.assert_not_called()

    def test_pending_market_exit_is_not_canceled_or_duplicated(self):
        trading = MagicMock()
        trading.get_all_positions.return_value = [SimpleNamespace(symbol='SPY', qty='2')]
        pending_close = SimpleNamespace(symbol='SPY', id='close-id', type='market', side='sell')
        with patch.object(bot, 'open_orders', side_effect=[[pending_close], [pending_close]]):
            bot.safe_unwind(trading, {'managed_symbols': ['SPY']}, 'stop', False)
        trading.cancel_order_by_id.assert_not_called()
        trading.close_position.assert_not_called()

    def test_stop_prevents_any_new_signal(self):
        bot.STOP_FILE.write_text('STOP\n')
        trading = MagicMock()
        trading.get_clock.return_value = SimpleNamespace(is_open=True)
        with patch.object(bot, 'safe_unwind') as unwind:
            s = bot.risk_check(trading, bot.RiskLimits(), dry_run=False)
        self.assertIsNone(s)
        unwind.assert_called_once()
        trading.get_account.assert_not_called()

    def test_state_corruption_raises_not_resets(self):
        bot.STATE.write_text('{ bad json', encoding='utf-8')
        with self.assertRaises(ValueError):
            bot.read_state()


if __name__ == '__main__':
    unittest.main()
