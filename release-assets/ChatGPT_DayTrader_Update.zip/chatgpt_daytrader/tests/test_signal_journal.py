from datetime import datetime
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import MagicMock

import bot
from strategy import AIDecision, RiskLimits


def fake_alpaca_modules(monkeypatch):
    import sys
    alp = ModuleType('alpaca')
    tra = ModuleType('alpaca.trading')
    enums = ModuleType('alpaca.trading.enums')
    req = ModuleType('alpaca.trading.requests')
    enums.OrderSide = SimpleNamespace(BUY='buy')
    enums.OrderClass = SimpleNamespace(BRACKET='bracket')
    enums.TimeInForce = SimpleNamespace(DAY='day')
    class Request:
        def __init__(self, **kw):
            self.data = kw
    req.MarketOrderRequest = Request
    req.StopLossRequest = Request
    req.TakeProfitRequest = Request
    for name, mod in (('alpaca',alp), ('alpaca.trading',tra),
                      ('alpaca.trading.enums',enums),('alpaca.trading.requests',req)):
        monkeypatch.setitem(sys.modules, name, mod)


def configure(tmp_path, monkeypatch):
    fake_alpaca_modules(monkeypatch)
    for key, filename in [('LOG','activity_paper.jsonl'),('STATE','state_paper.json'),
                          ('DECISIONS','decisions_paper.jsonl'),('HEALTH','health_paper.json')]:
        monkeypatch.setattr(bot, key, tmp_path / filename)
    monkeypatch.setattr(bot, 'local_now', lambda: datetime.fromisoformat('2026-11-10T10:35:00-05:00'))
    feature = {'SPY': {'price': 100, 'ema9': 99, 'ema21': 98, 'rsi14': 55,
                       'return_1h_pct': 1, 'last_bar_utc': '2026-11-10T15:30:00Z', 'bars_seen': 100}}
    monkeypatch.setattr(bot, 'load_features', lambda c: feature)
    monkeypatch.setattr(bot, 'open_orders', lambda c: [])
    monkeypatch.setattr(bot, 'today_order_count', lambda client, mode, date: 0)
    account = SimpleNamespace(account_blocked=False, trading_blocked=False,
                              equity='100000', cash='100000')
    state = {'day':'2026-11-10','entries':0,'managed_symbols':[], 'risk_locked':False}
    snapshot = bot.Snapshot(account, {}, state, 240)
    return feature, snapshot


def test_ai_hold_produces_explanation_but_never_broker_order(tmp_path, monkeypatch):
    configure(tmp_path, monkeypatch)
    trading = MagicMock()
    monkeypatch.setattr(bot, 'ai_decision', lambda *a, **kw: AIDecision(
        action='HOLD',symbol='NONE',reason='Trend insufficient'))
    bot.signal_cycle(trading, object(), object(), 'model', RiskLimits(),
                     bot.Snapshot(SimpleNamespace(account_blocked=False,
                                      trading_blocked=False,equity='100000',cash='100000'),
                                  {},{'day':'2026-11-10','entries':0,'managed_symbols':[]},240), 'paper',False)
    items = list(bot.DECISIONS.read_text().splitlines())
    assert len(items) == 1
    assert 'HOLD' in items[0]
    trading.submit_order.assert_not_called()


def test_filter_rejection_recorded_with_reason(tmp_path, monkeypatch):
    _, snapshot = configure(tmp_path,monkeypatch)
    monkeypatch.setattr(bot, 'load_features', lambda c: {'SPY': {
        'price':100, 'ema9':101, 'ema21':102, 'rsi14':90, 'return_1h_pct':-1}})
    monkeypatch.setattr(bot, 'ai_decision', lambda *a, **kw: AIDecision(
        action='BUY',symbol='SPY',reason='Misread uptrend'))
    trading = MagicMock()
    bot.signal_cycle(trading, object(), object(), 'model', RiskLimits(), snapshot, 'paper',False)
    assert 'Technical' not in bot.DECISIONS.read_text() or 'Numeric technical rules' in bot.DECISIONS.read_text()
    assert 'REJECTED' in bot.DECISIONS.read_text()
    trading.submit_order.assert_not_called()


def test_paper_buy_logs_submitted_not_fill(tmp_path,monkeypatch):
    _, snapshot = configure(tmp_path,monkeypatch)
    monkeypatch.setattr(bot, 'ai_decision', lambda *a, **kw: AIDecision(
        action='BUY',symbol='SPY',reason='EMA and RSI align'))
    trading = MagicMock()
    trading.submit_order.return_value.id = 'paper-order-123'
    bot.signal_cycle(trading, object(), object(), 'model', RiskLimits(), snapshot, 'paper', False)
    trading.submit_order.assert_called_once()
    assert 'SUBMITTED_NOT_FILLED' in bot.DECISIONS.read_text()
    assert 'paper-order-123' in bot.DECISIONS.read_text()


def test_live_mode_does_not_write_paper_journal(tmp_path,monkeypatch):
    configure(tmp_path,monkeypatch)
    monkeypatch.setattr(bot, 'DECISIONS', tmp_path / 'decisions_live.jsonl')
    bot.decision_journal('HOLD','NONE','no signal','HOLD',{},outcome_reason='Nothing to do')
    assert not bot.DECISIONS.exists()
