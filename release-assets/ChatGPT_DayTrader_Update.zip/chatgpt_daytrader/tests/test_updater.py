"""Offline tests; no requests to GitHub or brokerage APIs."""
import hashlib
import io
import json
import os
import stat
import zipfile
from pathlib import Path

import pytest

import updater


def sample_root(tmp_path):
    root = tmp_path / 'bot'
    root.mkdir()
    (root / 'version.json').write_text('{"version": "4.0.0"}', encoding='utf-8')
    (root / 'README.md').write_text('OLD README', encoding='utf-8')
    (root / 'bot.py').write_text('OLD BOT', encoding='utf-8')
    (root / '.env').write_text('OPENAI_API_KEY=SECRET_VALUE\n', encoding='utf-8')
    (root / 'activity.jsonl').write_text('old history\n', encoding='utf-8')
    (root / 'STOP.txt').write_text('STOP requested\n', encoding='utf-8')
    (root / '.venv').mkdir()
    (root / '.venv' / 'do_not_delete').write_text('venv')
    updater.save_config(root, 'Owner/repo', True)
    return root


def make_zip(path, version='4.0.1', extra=None):
    files = {
        'README.md': 'NEW README',
        'bot.py': 'NEW BOT',
        'updater.py': '# updater',
        'START_HERE.bat': '@echo off',
        'RUN_ALL.bat': '@echo off',
        'unified_control.py': '# GUI controller',
        'unified_setup.py': '# GUI settings',
        'requirements.txt': 'pytest\n',
        'version.json': json.dumps({'version': version}),
    }
    files.update(extra or {})
    with zipfile.ZipFile(path, 'w') as output:
        for name, data in files.items():
            output.writestr(f'chatgpt_daytrader/{name}', data)
    return files


def release_for(path, version='v4.0.1'):
    data = path.read_bytes()
    return updater.Release('Owner/repo', version,
                           'https://github.com/Owner/repo/releases/download/' + version + '/' + updater.ASSET_NAME,
                           hashlib.sha256(data).hexdigest(), len(data))


def test_repo_validation_and_version():
    assert updater.normalized_repo('https://github.com/a-user/a.repo') == 'a-user/a.repo'
    assert updater.parse_version('v4.0.1') > updater.parse_version('4.0.0')
    for value in ('not-a-repo', 'https://evil.com/owner/repo', '../../abc', 'owner/repo/other'):
        with pytest.raises(updater.UpdateError):
            updater.normalized_repo(value)


def test_update_preserves_secrets_history_and_user_config(tmp_path, monkeypatch):
    root = sample_root(tmp_path)
    source = tmp_path / 'good.zip'
    make_zip(source)
    release = release_for(source)
    monkeypatch.setattr(updater, '_download', lambda _release, dest: dest.write_bytes(source.read_bytes()))
    updater.install_release(release, root)
    assert (root / 'README.md').read_text() == 'NEW README'
    assert (root / 'bot.py').read_text() == 'NEW BOT'
    assert updater.current_version(root) == '4.0.1'
    assert 'SECRET_VALUE' in (root / '.env').read_text()
    assert (root / 'activity.jsonl').read_text() == 'old history\n'
    assert (root / 'STOP.txt').read_text() == 'STOP requested\n'
    assert (root / '.venv' / 'do_not_delete').read_text() == 'venv'
    assert updater.read_config(root) == {'repo': 'Owner/repo', 'auto_install': True}
    assert '4.0.1' in (root / 'update_history.jsonl').read_text()


def test_running_bot_blocks_all_installation(tmp_path, monkeypatch):
    root = sample_root(tmp_path)
    (root / '.bot.lock').write_text('1234')
    archive = tmp_path / 'good.zip'
    make_zip(archive)
    monkeypatch.setattr(updater, '_download', lambda _release, dest: dest.write_bytes(archive.read_bytes()))
    with pytest.raises(updater.UpdateError, match='still be running'):
        updater.install_release(release_for(archive), root)
    assert (root / 'bot.py').read_text() == 'OLD BOT'


@pytest.mark.parametrize('name', ['../outside.txt', '.env', 'state.json', '.venv/pip.exe',
                                   'STOP.txt', 'x/../../evil', 'update_config.json'])
def test_rejects_protected_and_traversal_zip_files(tmp_path, name):
    archive = tmp_path / 'bad.zip'
    make_zip(archive, extra={name: 'UNSAFE'})
    with pytest.raises(updater.UpdateError):
        updater._stage_zip(archive, tmp_path / 'stage', release_for(archive))


def test_wrong_release_version_rejected(tmp_path):
    archive = tmp_path / 'badver.zip'
    make_zip(archive, version='4.0.2')
    with pytest.raises(updater.UpdateError, match='does not match'):
        updater._stage_zip(archive, tmp_path / 'stage', release_for(archive, 'v4.0.1'))


def test_symlink_inside_zip_rejected(tmp_path):
    archive = tmp_path / 'symlink.zip'
    make_zip(archive)
    with zipfile.ZipFile(archive, 'a') as output:
        info = zipfile.ZipInfo('chatgpt_daytrader/evil_link')
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        output.writestr(info, '/etc/passwd')
    with pytest.raises(updater.UpdateError, match='symbolic links'):
        updater._stage_zip(archive, tmp_path / 'stage', release_for(archive))


def test_install_rolls_back_if_replacement_fails(tmp_path, monkeypatch):
    root = sample_root(tmp_path)
    staged = tmp_path / 'stage'
    staged.mkdir()
    (staged / 'README.md').write_text('NEW README')
    (staged / 'bot.py').write_text('NEW BOT')
    real_replace = updater.os.replace
    triggered = {'value': False}

    def fail_once(src, dst):
        if Path(dst) == root / 'bot.py' and not triggered['value']:
            triggered['value'] = True
            raise OSError('antivirus denied access')
        return real_replace(src, dst)

    monkeypatch.setattr(updater.os, 'replace', fail_once)
    with pytest.raises(updater.UpdateError, match='restored'):
        updater._install_staged(root, staged, [Path('README.md'), Path('bot.py')])
    assert (root / 'README.md').read_text() == 'OLD README'
    assert (root / 'bot.py').read_text() == 'OLD BOT'


def test_release_metadata_requires_sha256_and_trusted_github_url(monkeypatch):
    metadata = {'tag_name': 'v4.0.1', 'assets': [{
        'name': updater.ASSET_NAME, 'browser_download_url':
        'https://github.com/owner/repo/releases/download/v4.0.1/' + updater.ASSET_NAME,
        'digest': 'sha256:' + 'a' * 64, 'size': 123,
    }]}
    monkeypatch.setattr(updater, '_github_json', lambda _url: metadata)
    assert updater.fetch_latest('owner/repo').digest == 'a' * 64
    metadata['assets'][0]['digest'] = ''
    with pytest.raises(updater.UpdateError, match='SHA-256'):
        updater.fetch_latest('owner/repo')


def test_config_defaults_and_customization(tmp_path):
    assert updater.read_config(tmp_path) == {'repo': '', 'auto_install': True}
    updater.save_config(tmp_path, 'https://github.com/example/bot', False)
    assert updater.read_config(tmp_path) == {'repo': 'example/bot', 'auto_install': False}


def test_bad_latest_tag_uses_newest_valid_published_release(monkeypatch):
    good = {'tag_name': 'v6.0.1', 'assets': [{
        'name': updater.ASSET_NAME,
        'browser_download_url': 'https://github.com/owner/repo/releases/download/v6.0.1/' + updater.ASSET_NAME,
        'digest': 'sha256:' + 'a' * 64, 'size': 456,
    }]}
    old = dict(good, tag_name='v5.1.0')
    def mock_github(url):
        if url.endswith('/releases/latest'):
            return {'tag_name': 'v6', 'assets': []}
        assert url.endswith('/releases?per_page=30')
        return [{'tag_name': 'v6', 'assets': []}, old, good,
                {'tag_name': 'v7.0.0', 'prerelease': True, 'assets': []}]
    monkeypatch.setattr(updater, '_github_json', mock_github)
    assert updater.fetch_latest('owner/repo').version == 'v6.0.1'


def test_bad_latest_tag_without_compatible_releases_is_actionable(monkeypatch):
    monkeypatch.setattr(updater, '_github_json', lambda url:
                        {'tag_name': 'my-update'} if url.endswith('/releases/latest')
                        else [{'tag_name': 'v6.0'}])
    with pytest.raises(updater.UpdateError, match='Publish a release tagged v6.0.1'):
        updater.fetch_latest('owner/repo')


def test_bad_latest_asset_is_not_silently_skipped(monkeypatch):
    monkeypatch.setattr(updater, '_github_json', lambda url: {
        'tag_name': 'v6.0.1', 'assets': [{
            'name': updater.ASSET_NAME,
            'browser_download_url': 'https://github.com/owner/repo/releases/download/v6.0.1/' + updater.ASSET_NAME,
            'digest': None, 'size': 123,
        }]})
    with pytest.raises(updater.UpdateError, match='SHA-256'):
        updater.fetch_latest('owner/repo')
