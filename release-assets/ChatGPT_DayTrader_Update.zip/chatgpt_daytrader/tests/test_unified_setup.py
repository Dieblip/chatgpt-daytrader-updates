"""Fast offline tests: no calls to Alpaca, OpenAI or GitHub."""
import os
from pathlib import Path

import pytest
from dotenv import dotenv_values

from settings import LIVE_ACK, load_settings
from unified_setup import bot_argv, child_environment, load_form, save_form, validate_selected_mode


def sample_root(tmp_path: Path):
    (tmp_path / '.env.example').write_text('LIVE_TRADING_ENABLED=NO\nOTHER_SETTING=preserve\n', encoding='utf-8')
    return tmp_path


def sample_form():
    return {
        'ALPACA_PAPER_KEY': 'paper_ID',
        'ALPACA_PAPER_SECRET': 'paper_secret',
        'ALPACA_LIVE_KEY': 'live_ID',
        'ALPACA_LIVE_SECRET': 'live_secret',
        'OPENAI_API_KEY': 'openai_secret',
        'OPENAI_MODEL': 'gpt-6.1-sol',
        'MAX_ORDER_DOLLARS': '500',
    }


def test_load_default_paper_and_model(tmp_path):
    sample_root(tmp_path)
    loaded = load_form(tmp_path)
    assert loaded['ALPACA_LIVE_KEY'] == ''
    assert loaded['OPENAI_MODEL'] == 'gpt-6.1-sol'
    assert loaded['MAX_ORDER_DOLLARS'] == '1500'


def test_save_all_keys_and_preserve_other_settings(tmp_path):
    sample_root(tmp_path)
    save_form(tmp_path, sample_form())
    saved = dotenv_values(tmp_path / '.env')
    assert saved['ALPACA_PAPER_KEY'] == 'paper_ID'
    assert saved['ALPACA_LIVE_KEY'] == 'live_ID'
    assert saved['OPENAI_API_KEY'] == 'openai_secret'
    assert saved['OTHER_SETTING'] == 'preserve'
    assert saved['LIVE_TRADING_ENABLED'] == 'NO'
    assert load_form(tmp_path)['MAX_ORDER_DOLLARS'] == '500'


def test_save_clears_old_persistent_live_ack(tmp_path):
    root = sample_root(tmp_path)
    (root / '.env').write_text('LIVE_TRADING_ENABLED=' + LIVE_ACK + '\n')
    save_form(root, sample_form())
    assert dotenv_values(root / '.env')['LIVE_TRADING_ENABLED'] == 'NO'


def test_selected_mode_validated_separately():
    form = sample_form()
    validate_selected_mode(form, 'paper')
    validate_selected_mode(form, 'live')
    form['ALPACA_LIVE_KEY'] = ''
    with pytest.raises(ValueError, match='LIVE Alpaca'):
        validate_selected_mode(form, 'live')
    validate_selected_mode(form, 'paper')


def test_reject_shared_keys_and_invalid_order_limit():
    form = sample_form()
    form['ALPACA_LIVE_KEY'] = 'paper_ID'
    with pytest.raises(ValueError, match='different'):
        validate_selected_mode(form, 'live')
    form['MAX_ORDER_DOLLARS'] = '90000000'
    with pytest.raises(ValueError, match='between'):
        validate_selected_mode(form, 'paper')


def test_model_and_newline_rejected():
    form = sample_form()
    form['OPENAI_MODEL'] = 'good\nMALICIOUS=1'
    with pytest.raises(ValueError, match='newlines'):
        validate_selected_mode(form, 'paper')


def test_live_requires_explicit_mode_and_per_process_permission(tmp_path, monkeypatch):
    root = sample_root(tmp_path)
    save_form(root, sample_form())
    with pytest.raises(RuntimeError, match='LIVE DISABLED'):
        load_settings(root, live=True, confirmed=True)
    monkeypatch.setenv('LIVE_TRADING_ENABLED', LIVE_ACK)
    assert load_settings(root, live=True, confirmed=True).live
    assert not load_settings(root, live=False, confirmed=False).live
    assert child_environment('live')['LIVE_TRADING_ENABLED'] == LIVE_ACK
    assert 'LIVE_TRADING_ENABLED' not in child_environment('paper')
    assert '--live' not in bot_argv('python', 'paper')
    assert bot_argv('python', 'live') == ['python', 'bot.py', '--live', '--confirm-live']
    assert '--dry-run' in bot_argv('python', 'live', dry_run=True)


def test_liveness_not_enabled_by_saved_live_credentials(tmp_path):
    root = sample_root(tmp_path)
    save_form(root, sample_form())
    assert load_settings(root, live=False, confirmed=False).mode == 'paper'
