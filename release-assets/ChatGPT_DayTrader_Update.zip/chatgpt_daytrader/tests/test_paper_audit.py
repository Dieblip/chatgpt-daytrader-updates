"""No network/broker keys needed. Real broker responses are mocked."""
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from types import SimpleNamespace as Obj
from unittest.mock import MagicMock

import pytest

import paper_audit as pa
import bot


def order(ident, side, qty, price, when, *, client='', group=None, status='filled', legs=None):
    return Obj(id=ident, side=side, symbol='SPY', filled_qty=str(qty),
               filled_avg_price=str(price), filled_at=when, submitted_at=when,
               client_order_id=client, group_id=group, status=status, legs=legs or [], qty=str(qty))


def sample_filled_bracket(pnl=10):
    now = datetime(2026, 11, 2, 15, 0, tzinfo=timezone.utc)
    buy = order('entry1', 'buy', 2, 100, now, client='gptbot-paper-2026-11-02-SPY-123', group='b1')
    sell = order('exit1', 'sell', 2, 100+pnl/2, now+timedelta(minutes=10), group='b1')
    buy.legs = [sell]
    return [buy]


def test_nested_bracket_fill_counts_as_one_completed_trade():
    orders = sample_filled_bracket(pnl=10)
    outcome = pa.trade_performance(orders)
    assert outcome['closed_trades'] == 1
    assert outcome['wins'] == 1
    assert outcome['win_rate'] == 100.0
    assert outcome['realized_pnl'] == 10.0
    assert len(pa.order_rows(orders)) == 2


def test_no_win_rate_for_submitted_or_canceled_orders():
    buy = sample_filled_bracket()[0]
    buy.status = 'new'
    buy.legs[0].status = 'canceled'
    p = pa.trade_performance([buy])
    assert p['closed_trades'] == 0 and p['win_rate'] is None and p['realized_pnl'] == 0


def test_losing_and_flat_round_trips():
    first = sample_filled_bracket(pnl=-10)
    other = sample_filled_bracket(pnl=0)
    other[0].id, other[0].group_id, other[0].symbol = 'entry2', 'b2', 'QQQ'
    other[0].legs[0].id, other[0].legs[0].group_id, other[0].legs[0].symbol = 'exit2', 'b2', 'QQQ'
    other[0].client_order_id = 'gptbot-paper-2026-11-02-QQQ-999'
    r = pa.trade_performance(first + other)
    assert r['wins'] == 0 and r['losses'] == 1 and r['flat'] == 1
    assert r['win_rate'] == 0 and r['realized_pnl'] == -10


def test_dedupe_flatten_prevents_double_counting_bracket_leg():
    parent = sample_filled_bracket()[0]
    r = pa.trade_performance([parent, parent.legs[0]])
    assert r['closed_trades'] == 1 and r['realized_pnl'] == 10


def test_partial_exit_does_not_count_win_until_flat():
    when = datetime(2026, 11, 2, 15, 0, tzinfo=timezone.utc)
    entry = order('b', 'buy', 3, 100, when, group='grp', client='gptbot-paper-2026-11-02-SPY-100')
    sell1 = order('e1', 'sell', 1, 101, when+timedelta(minutes=1), group='grp')
    p = pa.trade_performance([entry, sell1])
    assert p['closed_trades'] == 0 and p['open_cycles'] == 1 and p['partial_exits'] == 1
    sell2 = order('e2', 'sell', 2, 105, when+timedelta(minutes=2), group='grp')
    p = pa.trade_performance([entry, sell1, sell2])
    assert p['closed_trades'] == 1 and p['realized_pnl'] == 11


def test_manual_orders_are_not_counted_as_bot_entries():
    when = datetime(2026, 11, 2, 15, 0, tzinfo=timezone.utc)
    manual = order('b', 'buy', 3, 100, when, client='manual-order')
    exit_ = order('s', 'sell', 3, 120, when+timedelta(minutes=1), group='other')
    perf = pa.trade_performance([manual, exit_])
    assert perf['closed_trades'] == 0


def test_emergency_close_id_can_be_correlated():
    when = datetime(2026, 11, 2, 15, 0, tzinfo=timezone.utc)
    entry = order('b', 'buy', 1, 100, when, client='gptbot-paper-2026-11-02-SPY-100')
    close = order('s', 'sell', 1, 99, when+timedelta(minutes=2), client='alpaca-close')
    assert pa.trade_performance([entry, close])['closed_trades'] == 0
    perf = pa.trade_performance([entry, close], {'s'})
    assert perf['losses'] == 1 and perf['realized_pnl'] == -1


def test_read_only_reconciliation_only_emits_when_broker_status_changes(tmp_path, monkeypatch):
    entry = sample_filled_bracket()[0]
    monkeypatch.setattr(bot, 'LOG', tmp_path / 'activity_paper.jsonl')
    monkeypatch.setattr(bot, 'ORDER_CACHE', tmp_path / 'broker_order_status_paper.json')
    monkeypatch.setattr(bot, 'HEALTH', tmp_path / 'health_paper.json')
    monkeypatch.setattr(bot, 'fetch_paper_orders', lambda client: [entry])
    dummy = MagicMock()
    bot.reconcile_paper_orders(dummy)
    first = pa.read_jsonl(bot.LOG)
    assert len(first) == 2
    bot.reconcile_paper_orders(dummy)
    assert len(pa.read_jsonl(bot.LOG)) == len(first)
    entry.legs[0].status = 'canceled'
    bot.reconcile_paper_orders(dummy)
    assert len(pa.read_jsonl(bot.LOG)) == len(first) + 1
    dummy.submit_order.assert_not_called()
    dummy.close_position.assert_not_called()


def test_decision_journal_logs_numbers_and_rejected_reason(tmp_path, monkeypatch):
    monkeypatch.setattr(bot, 'DECISIONS', tmp_path / 'decisions_paper.jsonl')
    monkeypatch.setattr(bot, 'HEALTH', tmp_path / 'health_paper.json')
    bot.decision_journal('BUY', 'SPY', 'Uptrend', 'REJECTED',
                         {'SPY': {'price': 100, 'rsi14': 63}},
                         outcome_reason='Entry filter failed')
    d = pa.read_jsonl(bot.DECISIONS)[0]
    assert d['features']['rsi14'] == 63
    assert d['outcome'] == 'REJECTED'
    assert d['outcome_reason'] == 'Entry filter failed'
    assert json.loads(bot.HEALTH.read_text())['status'] == 'AI_DECISION'


def test_lookback_limit_warning():
    when = datetime(2026, 11, 2, 15, 0, tzinfo=timezone.utc)
    orders = [order(f'x{i}', 'buy', 1, 100, when) for i in range(500)]
    p = pa.trade_performance(orders)
    assert p['history_may_be_truncated'] is True
