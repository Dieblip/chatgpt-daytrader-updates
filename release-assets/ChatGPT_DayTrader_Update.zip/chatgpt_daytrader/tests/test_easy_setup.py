import tempfile
import unittest
from pathlib import Path

from dotenv import dotenv_values
from easy_setup_utils import config_is_ready, paper_inputs_valid, save_paper_keys


class EasySetupTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        (self.root / '.env.example').write_text(
            'ALPACA_PAPER_KEY=\nALPACA_PAPER_SECRET=\nALPACA_LIVE_KEY=\nALPACA_LIVE_SECRET=\n'
            'LIVE_TRADING_ENABLED=NO\nOPENAI_API_KEY=\nOPENAI_MODEL=gpt-6.1-sol\n'
            'MAX_ORDER_DOLLARS=1500\n', encoding='utf-8')

    def tearDown(self):
        self.directory.cleanup()

    def test_save_and_reload_paper_only(self):
        self.assertFalse(config_is_ready(self.root))
        result = save_paper_keys(self.root, 'paper-test', 'paper-secret', 'api-test', '200')
        self.assertEqual(result.mode, 'paper')
        self.assertTrue(config_is_ready(self.root))
        self.assertEqual(dotenv_values(self.root / '.env')['MAX_ORDER_DOLLARS'], '200')

    def test_live_settings_are_untouched(self):
        (self.root / '.env').write_text(
            (self.root / '.env.example').read_text(encoding='utf-8').replace(
                'ALPACA_LIVE_KEY=', 'ALPACA_LIVE_KEY=special-live-key').replace(
                'LIVE_TRADING_ENABLED=NO', 'LIVE_TRADING_ENABLED=I_UNDERSTAND_REAL_MONEY_CAN_BE_LOST'),
            encoding='utf-8')
        save_paper_keys(self.root, 'paper1', 'paper2', 'openai1', '1500')
        values = dotenv_values(self.root / '.env')
        self.assertEqual(values['ALPACA_LIVE_KEY'], 'special-live-key')
        self.assertEqual(values['LIVE_TRADING_ENABLED'], 'I_UNDERSTAND_REAL_MONEY_CAN_BE_LOST')

    def test_missing_and_invalid_values_rejected(self):
        with self.assertRaisesRegex(ValueError, '3 API'):
            paper_inputs_valid('', 'some-secret', 'openai-key', '200')
        with self.assertRaisesRegex(ValueError, 'between'):
            paper_inputs_valid('a', 'b', 'c', '999999')
        with self.assertRaisesRegex(ValueError, 'single-line'):
            paper_inputs_valid('a\nX=Y', 'b', 'c', '100')


if __name__ == '__main__':
    unittest.main()
