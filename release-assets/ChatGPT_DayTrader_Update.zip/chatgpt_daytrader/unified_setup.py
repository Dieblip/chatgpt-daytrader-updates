"""Configuration for the one-window controller.

Live activation is deliberately NOT persisted: GUI injects the acknowledgement
only into the specifically confirmed child process environment.
"""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path
from typing import Mapping

from dotenv import dotenv_values, set_key
from settings import LIVE_ACK, resolve_settings

KEYS = ('ALPACA_PAPER_KEY', 'ALPACA_PAPER_SECRET', 'ALPACA_LIVE_KEY',
        'ALPACA_LIVE_SECRET', 'OPENAI_API_KEY', 'OPENAI_MODEL',
        'MAX_ORDER_DOLLARS')
DEFAULTS = {'OPENAI_MODEL': 'gpt-6.1-sol', 'MAX_ORDER_DOLLARS': '1500'}
MODEL_RE = re.compile(r'^[a-zA-Z0-9_.:-]{2,100}$')


def load_form(root: Path) -> dict[str, str]:
    values = dotenv_values(root / '.env') if (root / '.env').exists() else {}
    return {key: (values.get(key) or DEFAULTS.get(key, '')) for key in KEYS}


def validate_form(values: Mapping[str, str]) -> dict[str, str]:
    cleaned = {key: str(values.get(key, '')).strip() for key in KEYS}
    if any(('\n' in v or '\r' in v or '\x00' in v) for v in cleaned.values()):
        raise ValueError('Keys and settings cannot contain newlines or control characters.')
    if not MODEL_RE.fullmatch(cleaned['OPENAI_MODEL']):
        raise ValueError('Enter an OpenAI model ID such as gpt-6.1-sol or another available API model.')
    try:
        cap = float(cleaned['MAX_ORDER_DOLLARS'])
    except ValueError as exc:
        raise ValueError('The maximum order amount must be a number.') from exc
    if not 10 <= cap <= 5000:
        raise ValueError('Maximum dollars per order must be between $10 and $5,000.')
    cleaned['MAX_ORDER_DOLLARS'] = str(int(cap)) if cap.is_integer() else str(cap)
    return cleaned


def save_form(root: Path, values: Mapping[str, str]) -> None:
    cleaned = validate_form(values)
    env = root / '.env'
    if not env.exists():
        shutil.copy2(root / '.env.example', env)
    for key in KEYS:
        set_key(str(env), key, cleaned[key], quote_mode='always')
    # An old persistently armed acknowledgement is always reset by this GUI.
    set_key(str(env), 'LIVE_TRADING_ENABLED', 'NO', quote_mode='always')
    if os.name != 'nt':
        try:
            env.chmod(0o600)
        except OSError:
            pass


def validate_selected_mode(values: Mapping[str, str], mode: str) -> None:
    """Pre-flight validation; never sends network requests or places an order."""
    cleaned = validate_form(values)
    if mode not in {'paper', 'live'}:
        raise ValueError('Select Paper or Live mode.')
    broker = ('ALPACA_LIVE_KEY', 'ALPACA_LIVE_SECRET') if mode == 'live' else (
        'ALPACA_PAPER_KEY', 'ALPACA_PAPER_SECRET')
    if not all(cleaned[k] for k in (*broker, 'OPENAI_API_KEY')):
        raise ValueError(f'Fill in both {mode.upper()} Alpaca keys and your OpenAI API key first.')
    if mode == 'live':
        cleaned['LIVE_TRADING_ENABLED'] = LIVE_ACK
    try:
        resolve_settings(cleaned, live=(mode == 'live'), confirmed=(mode == 'live'))
    except RuntimeError as exc:
        raise ValueError(str(exc)) from exc


def child_environment(mode: str) -> dict[str, str]:
    """Only a specifically confirmed LIVE child receives ephemeral permission."""
    if mode not in {'paper', 'live'}:
        raise ValueError('Invalid trading mode.')
    env = os.environ.copy()
    env.pop('LIVE_TRADING_ENABLED', None)
    if mode == 'live':
        env['LIVE_TRADING_ENABLED'] = LIVE_ACK
    return env


def bot_argv(python: str, mode: str, dry_run: bool = False) -> list[str]:
    if mode not in {'paper', 'live'}:
        raise ValueError('Invalid trading mode.')
    command = [python, 'bot.py']
    if mode == 'live':
        command.extend(['--live', '--confirm-live'])
    if dry_run:
        command.append('--dry-run')
    return command
