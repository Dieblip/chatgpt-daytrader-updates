@echo off
setlocal
cd /d "%~dp0"
py -3 build_release.py
pause
