@echo off
cd /d "%~dp0"
call "%~dp0RUN_ALL.bat"
