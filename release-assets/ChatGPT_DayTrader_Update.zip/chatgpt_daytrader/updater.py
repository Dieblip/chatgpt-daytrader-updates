"""Verified GitHub Release updater for the Windows day-trading prototype.

Only public GitHub repositories are supported (no stored GitHub access token).
Updates never run while bot.py holds its .bot.lock.  Local credentials, runtime
state, and update settings are never accepted from a release ZIP.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

ROOT = Path(__file__).resolve().parent
ASSET_NAME = 'ChatGPT_DayTrader_Update.zip'
RELEASE_FOLDER = 'chatgpt_daytrader'
MAX_DOWNLOAD = 25 * 1024 * 1024
MAX_UNPACKED = 80 * 1024 * 1024
MAX_FILES = 250
MAX_JSON = 1024 * 1024
REPO_PATTERN = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9-]{0,38}/[a-zA-Z0-9_.-]{1,100}$')
VERSION_PATTERN = re.compile(r'^v?(\d+)\.(\d+)\.(\d+)$', re.I)
HEX_DIGEST = re.compile(r'^sha256:([a-fA-F0-9]{64})$')
SEGMENT_PATTERN = re.compile(r'^[A-Za-z0-9_. -]+$')
PROTECTED_ROOT_NAMES = {
    '.env', '.venv', '.git', '.bot.lock', '.practice.lock', 'STOP.txt', 'PRACTICE_STOP.txt',
    'activity.jsonl', 'state.json', 'state.tmp', 'practice_state.json', 'practice_state.json.tmp', '.streamlit',
    'update_config.json', 'update_history.jsonl', '.update_staging',
    '.update_backups', 'update-debug.log',
}
REQUIRED_FILES = {
    'bot.py', 'updater.py', 'RUN_ALL.bat', 'unified_control.py', 'unified_setup.py', 'requirements.txt', 'version.json'
}


class UpdateError(RuntimeError):
    """Any unsafe or unsuccessful update."""


@dataclass(frozen=True)
class Release:
    repo: str
    version: str
    download_url: str
    digest: str
    size: int


def current_version(root: Path = ROOT) -> str:
    value = json.loads((root / 'version.json').read_text(encoding='utf-8'))['version']
    parse_version(value)
    return value


def parse_version(tag: str) -> tuple[int, int, int]:
    match = VERSION_PATTERN.fullmatch(tag)
    if match is None:
        raise UpdateError('Version must be like 4.0.1 (tag v4.0.1).')
    return tuple(int(n) for n in match.groups())


def normalized_repo(value: str) -> str:
    value = value.strip()
    match = re.fullmatch(r'https://github\.com/([^/?#]+/[^/?#]+?)(?:\.git)?/?', value, re.I)
    if match:
        value = match.group(1)
    if not REPO_PATTERN.fullmatch(value) or '..' in value or value.endswith('.git'):
        raise UpdateError('Enter a GitHub repository as OWNER/REPO (or a github.com URL).')
    return value


def read_config(root: Path = ROOT) -> dict[str, Any]:
    path = root / 'update_config.json'
    if not path.exists():
        return {'repo': '', 'auto_install': True}
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data, dict):
            raise ValueError('Not an object')
        repo = normalized_repo(str(data['repo'])) if data.get('repo') else ''
        auto_install = data.get('auto_install', True)
        if not isinstance(auto_install, bool):
            raise ValueError('auto_install must be boolean')
        return {'repo': repo, 'auto_install': auto_install}
    except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise UpdateError('Invalid update_config.json. Open the GUI and save GitHub settings again.') from exc


def save_config(root: Path, repo: str, auto_install: bool) -> None:
    repo = normalized_repo(repo) if repo.strip() else ''
    if not isinstance(auto_install, bool):
        raise UpdateError('Automatic update setting must be a true/false value.')
    path = root / 'update_config.json'
    temp_path = root / 'update_config.json.tmp'
    try:
        temp_path.write_text(json.dumps({'repo': repo, 'auto_install': auto_install}, indent=2) + '\n', encoding='utf-8')
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)


def _github_json(url: str) -> dict[str, Any] | list[dict[str, Any]]:
    request = urllib.request.Request(url, headers={
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'ChatGPT-DayTrader-Updater',
        'X-GitHub-Api-Version': '2022-11-28',
    })
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            data = response.read(MAX_JSON + 1)
    except urllib.error.HTTPError as exc:
        if exc.code == 404 and url.endswith('/releases/latest'):
            raise UpdateError('No published update releases found for this repository yet.') from exc
        raise UpdateError(f'GitHub returned HTTP {exc.code}. Check repository and internet access.') from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise UpdateError('Could not reach GitHub Releases. Check internet and repository settings.') from exc
    if len(data) > MAX_JSON:
        raise UpdateError('GitHub release response exceeded the safety limit.')
    try:
        value = json.loads(data)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise UpdateError('Unexpected GitHub API response.') from exc
    if url.endswith('/releases?per_page=30'):
        if not isinstance(value, list) or len(value) > 30 or not all(isinstance(x, dict) for x in value):
            raise UpdateError('Unexpected GitHub releases list format.')
    elif not isinstance(value, dict):
        raise UpdateError('Unexpected GitHub release format.')
    return value


def fetch_latest(repo: str) -> Release:
    repo = normalized_repo(repo)
    obj = _github_json(f'https://api.github.com/repos/{repo}/releases/latest')
    version = str(obj.get('tag_name', ''))
    # Some users create a GitHub Release with a human-readable tag (v6, v6.0,
    # test-update). Rather than mistake that for a broken local install, look
    # for a correctly tagged, published release among the 30 most recent.
    # Never accept an unsupported tag or skip a valid release with a bad asset.
    if not VERSION_PATTERN.fullmatch(version):
        releases = _github_json(f'https://api.github.com/repos/{repo}/releases?per_page=30')
        supported = [item for item in releases
                     if isinstance(item, dict)
                     and VERSION_PATTERN.fullmatch(str(item.get('tag_name', '')))
                     and not item.get('draft') and not item.get('prerelease')]
        if not supported:
            raise UpdateError(
                f'GitHub newest release tag {version!r} is not a version number. '
                'Publish a release tagged v6.0.1 (three numbers) with '
                f'{ASSET_NAME} attached. No files were installed.')
        obj = max(supported, key=lambda item: parse_version(str(item['tag_name'])))
        version = str(obj['tag_name'])
    parse_version(version)
    if obj.get('draft') or obj.get('prerelease'):
        raise UpdateError('Draft/prerelease versions are not installed.')
    found = [x for x in obj.get('assets', [])
             if isinstance(x, dict) and x.get('name') == ASSET_NAME]
    if len(found) != 1:
        raise UpdateError(f'Latest GitHub release must contain exactly one {ASSET_NAME} asset.')
    asset = found[0]
    match = HEX_DIGEST.fullmatch(str(asset.get('digest', '')))
    if not match:
        raise UpdateError('GitHub asset is missing a SHA-256 digest. Update refused.')
    url = str(asset.get('browser_download_url', ''))
    expected_prefix = f'https://github.com/{repo}/releases/download/'
    if not url.lower().startswith(expected_prefix.lower()) or not url.endswith('/' + ASSET_NAME):
        raise UpdateError('Release asset URL is not from the configured GitHub repository.')
    size = asset.get('size')
    if type(size) is not int or not (1 <= size <= MAX_DOWNLOAD):
        raise UpdateError('Update ZIP has an invalid or oversized download size.')
    return Release(repo, version, url, match.group(1).lower(), size)


def available_update(root: Path = ROOT, repo: str | None = None) -> Release | None:
    repo = repo if repo is not None else read_config(root)['repo']
    if not repo:
        return None
    release = fetch_latest(repo)
    if parse_version(release.version) > parse_version(current_version(root)):
        return release
    return None


def _download(release: Release, dest: Path) -> None:
    request = urllib.request.Request(release.download_url, headers={
        'User-Agent': 'ChatGPT-DayTrader-Updater',
        'Accept': 'application/octet-stream',
    })
    hasher = hashlib.sha256()
    amount = 0
    try:
        with urllib.request.urlopen(request, timeout=40) as response, dest.open('wb') as out:
            while True:
                block = response.read(64 * 1024)
                if not block:
                    break
                amount += len(block)
                if amount > MAX_DOWNLOAD:
                    raise UpdateError('Update download exceeded 25 MB safety limit.')
                hasher.update(block)
                out.write(block)
    except (urllib.error.URLError, TimeoutError) as exc:
        raise UpdateError('Could not download the GitHub release ZIP.') from exc
    if amount != release.size or hasher.hexdigest() != release.digest:
        raise UpdateError('Release ZIP size or SHA-256 hash does not match GitHub. Update refused.')


def _safe_relative(filename: str) -> Path:
    if '\\' in filename or '\x00' in filename or ':' in filename:
        raise UpdateError('Update ZIP has an unsafe path.')
    path = PurePosixPath(filename)
    parts = path.parts
    if not parts or parts[0] != RELEASE_FOLDER or len(parts) == 1:
        raise UpdateError('Update ZIP must use the chatgpt_daytrader/ folder.')
    inside = parts[1:]
    for part in inside:
        upper = part.split('.')[0].upper()
        if part in ('', '.', '..') or part.endswith((' ', '.')) or not SEGMENT_PATTERN.fullmatch(part):
            raise UpdateError('Update ZIP contains an unsafe filename.')
        if upper in ('CON', 'PRN', 'AUX', 'NUL') or re.fullmatch(r'(COM|LPT)[1-9]', upper):
            raise UpdateError('Update ZIP contains a Windows reserved filename.')
    if (inside[0].lower().startswith(('activity_', 'state_', 'bot_console_', 'dashboard_console'))
            or inside[0].lower().endswith(('.log', '.jsonl'))):
        raise UpdateError('Update ZIP cannot replace runtime logs or account state.')
    if inside[0].lower() in {name.lower() for name in PROTECTED_ROOT_NAMES}:
        raise UpdateError('Update ZIP contains a protected user setting or runtime file.')
    # Do not allow the source archive to overwrite any hidden user folders/files,
    # other than the harmless .env.example / .gitignore templates.
    if inside[0].startswith('.') and inside[0] not in ('.env.example', '.gitignore'):
        raise UpdateError('Update ZIP contains an unapproved hidden file.')
    return Path(*inside)


def _stage_zip(zip_path: Path, stage_root: Path, release: Release) -> list[Path]:
    staged: list[Path] = []
    seen: set[str] = set()
    unpacked_bytes = 0
    try:
        with zipfile.ZipFile(zip_path) as archive:
            for info in archive.infolist():
                if info.is_dir() and info.filename.rstrip('/') == RELEASE_FOLDER:
                    continue
                relative = _safe_relative(info.filename.rstrip('/'))
                if info.is_dir():
                    continue
                if len(staged) >= MAX_FILES:
                    raise UpdateError('Update ZIP contains too many files.')
                unix_mode = (info.external_attr >> 16) & 0xFFFF
                file_kind = stat.S_IFMT(unix_mode)
                if file_kind not in (0, stat.S_IFREG):
                    raise UpdateError('ZIP cannot contain symbolic links or special files.')
                casefold = str(relative).lower()
                if casefold in seen:
                    raise UpdateError('Duplicate or case-conflicting path in ZIP.')
                seen.add(casefold)
                unpacked_bytes += info.file_size
                if unpacked_bytes > MAX_UNPACKED:
                    raise UpdateError('ZIP is too large when uncompressed.')
                output = stage_root / relative
                output.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as source, output.open('wb') as dest:
                    copied = shutil.copyfileobj(source, dest)
                staged.append(relative)
    except (zipfile.BadZipFile, OSError, EOFError) as exc:
        raise UpdateError('Release archive could not be validated or extracted.') from exc
    if not REQUIRED_FILES.issubset({p.as_posix() for p in staged}):
        raise UpdateError('Release ZIP is missing required bot files.')
    data = json.loads((stage_root / 'version.json').read_text(encoding='utf-8'))
    if parse_version(str(data.get('version', ''))) != parse_version(release.version):
        raise UpdateError('Release tag does not match version.json inside the ZIP.')
    return staged


def _bot_not_running(root: Path) -> None:
    if (root / '.practice.lock').exists():
        raise UpdateError('A practice simulator may still be running (.practice.lock exists). Stop it before updating.')
    if (root / '.bot.lock').exists():
        raise UpdateError('The trading bot may still be running (.bot.lock exists). '
                          'Stop it and verify in Alpaca before updating. Never delete the lock blindly.')


def _install_staged(root: Path, stage_root: Path, staged: list[Path]) -> None:
    # Transactional best effort: all old overwritten files are copied first.
    # Any failure attempts to restore exactly what was changed.
    with tempfile.TemporaryDirectory(prefix='daytrader-backup-') as backup_dir:
        backup_root = Path(backup_dir)
        for relative in staged:
            existing = root / relative
            if existing.is_symlink():
                raise UpdateError('Refusing to replace symlink in installation folder.')
            if existing.exists():
                if not existing.is_file():
                    raise UpdateError('An update target is not a regular file.')
                backup = backup_root / relative
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(existing, backup)
        changed: list[Path] = []
        try:
            _bot_not_running(root)
            for relative in staged:
                dest = root / relative
                if any(part.is_symlink() for part in (dest.parent, *dest.parents) if part != root.parent):
                    raise UpdateError('Unsafe symlink in installation path.')
                dest.parent.mkdir(parents=True, exist_ok=True)
                # Write the new file to the same drive as destination, then replace.
                handle, filename = tempfile.mkstemp(prefix='.update-', dir=dest.parent)
                os.close(handle)
                temp = Path(filename)
                try:
                    shutil.copy2(stage_root / relative, temp)
                    os.replace(temp, dest)
                    changed.append(relative)
                finally:
                    temp.unlink(missing_ok=True)
        except Exception as exc:
            rollback_errors = []
            for relative in reversed(changed):
                dest = root / relative
                backup = backup_root / relative
                try:
                    if backup.exists():
                        shutil.copy2(backup, dest)
                    else:
                        dest.unlink(missing_ok=True)
                except OSError as rollback_exc:
                    rollback_errors.append(str(rollback_exc))
            if rollback_errors:
                raise UpdateError('Update failed and automatic rollback was incomplete. '
                                  'Do not launch the bot; manually restore a backup ZIP.') from exc
            raise UpdateError('Update failed; previous program files restored.') from exc


def install_release(release: Release, root: Path = ROOT) -> None:
    _bot_not_running(root)
    with tempfile.TemporaryDirectory(prefix='daytrader-update-') as temp_dir:
        temp = Path(temp_dir)
        archive = temp / ASSET_NAME
        stage = temp / 'stage'
        stage.mkdir()
        _download(release, archive)
        staged = _stage_zip(archive, stage, release)
        _bot_not_running(root)
        _install_staged(root, stage, staged)
    try:
        with (root / 'update_history.jsonl').open('a', encoding='utf-8') as file:
            file.write(json.dumps({'installed_version': release.version, 'source': release.repo}) + '\n')
    except OSError:
        pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Verified GitHub Releases updater')
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--auto', action='store_true', help='Check/apply if enabled (on startup)')
    mode.add_argument('--check', action='store_true', help='Check only')
    mode.add_argument('--install', action='store_true', help='Check and install newest published release')
    args = parser.parse_args(argv)
    try:
        config = read_config(ROOT)
        if not config['repo']:
            print('Updater: GitHub repo not yet configured. Open START_HERE and set it in Updates.')
            return 0
        if args.auto and not config['auto_install']:
            print('Updater: automatic installation is turned off.')
            return 0
        print(f'Updater: checking {config["repo"]} (installed v{current_version()})...')
        release = available_update(ROOT, config['repo'])
        if not release:
            print('Updater: already on the latest published version.')
            return 0
        print(f'Updater: update {release.version} available.')
        if args.check:
            return 0
        _bot_not_running(ROOT)
        print('Updater: verifying download and installing with rollback protection...')
        install_release(release, ROOT)
        print(f'Updater: successfully installed {release.version}. Your API keys and history are unchanged.')
        return 0
    except UpdateError as exc:
        print(f'Updater: {exc}', file=sys.stderr)
        # Startup checks should not take down the old bot just because GitHub
        # is temporarily unavailable, but a partial/integrity error blocks startup.
        if args.auto and str(exc).startswith('Could not reach GitHub Releases.'):
            print('Updater: starting previous installed version without changing any files.')
            return 0
        return 2
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f'Updater: unexpected local installation/configuration error: {type(exc).__name__}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
